import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { academicApi } from '@/api/index';
import { toast } from 'sonner';
import ProgressSphere from '@/components/ProgressSphere';

interface WorkspaceCard {
  workspace_id: string;
  semester: number;
  semester_type: string;
  workflow_state: string;
  subject_count: number;
  submitted_count: number;
  pool_count: number;
  allocated_count: number;
  progress_percent: number;
  sections: { id: number; name: string }[];
}

export default function HODHome({ showAll = false }: { showAll?: boolean }) {
  const { session } = useAuth();
  const navigate = useNavigate();
  const [workspaces, setWorkspaces] = useState<WorkspaceCard[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const ctx = session?.context;

  useEffect(() => {
    if (!ctx) return;
    setIsLoading(true);
    academicApi.getWorkspacesByContext(ctx.programmeId, ctx.semesterType)
      .then(setWorkspaces)
      .catch(() => toast.error('Failed to load semester workspaces'))
      .finally(() => setIsLoading(false));
  }, [ctx?.programmeId, ctx?.semesterType]);

  if (!ctx) return null;

  const stateColor: Record<string, string> = {
    FINALIZED: 'chip-finalized',
    ALLOCATION: 'chip-in-progress',
    REVIEW: 'chip-in-progress',
    PREFERENCES: 'chip-submitted',
    NOT_STARTED: 'chip-not-started',
  };

  const stateLabel: Record<string, string> = {
    FINALIZED: '✅ Finalized',
    ALLOCATION: '🔄 Allocation In Progress',
    REVIEW: '📋 Under Review',
    PREFERENCES: '📝 Accepting Preferences',
    NOT_STARTED: '⭕ Not Started',
  };

  return (
    <div className="animate-fade-in">
      {/* Welcome Banner */}
      <div className="welcome-banner" style={{ marginBottom: '28px' }}>
        <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', marginBottom: '4px', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          {showAll ? 'All Semesters View' : 'Welcome Back'}
        </p>
        <h1 className="welcome-title" style={{ marginBottom: '6px' }}>
          {showAll ? `All ${ctx.semesterType} Semesters` : `Good morning, ${session?.name}!`}
        </h1>
        <p className="welcome-subtitle">
          {ctx.programmeName} · {ctx.programmeType} · {ctx.semesterType} Semester · AY {ctx.academicYear}
        </p>
        <div className="welcome-meta">
          <span className="welcome-chip">🏛️ {ctx.departmentName}</span>
          <span className="welcome-chip">📚 {ctx.programmeName}</span>
          <span className="welcome-chip">
            {ctx.semesterType === 'ODD' ? 'Odd Semesters: 1, 3' + (ctx.programmeType === 'UG' ? ', 5, 7' : '') : 'Even Semesters: 2, 4' + (ctx.programmeType === 'UG' ? ', 6, 8' : '')}
          </span>
        </div>
      </div>

      {/* Page Header */}
      <div className="page-header">
        <div>
          <h2 className="page-title">{ctx.semesterType} Semester Workspaces</h2>
          <p className="page-subtitle">Click any semester to open the workspace and manage preferences, allocations, and the class-wise matrix.</p>
        </div>
        <span style={{ fontSize: '13px', color: '#64748B', fontWeight: 600 }}>
          {workspaces.length} workspace{workspaces.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Semester Cards Grid */}
      {isLoading ? (
        <div className="grid-semesters">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="skeleton skeleton-card" style={{ height: 220 }} />
          ))}
        </div>
      ) : workspaces.length === 0 ? (
        <div className="empty-state card card-body">
          <div className="empty-state-icon">📭</div>
          <h3 className="empty-state-title">No Workspaces Found</h3>
          <p className="empty-state-desc">
            No {ctx.semesterType.toLowerCase()} semester workspaces have been set up yet for {ctx.programmeName}.
            Please contact the ERP administrator to initialize the academic workspaces.
          </p>
        </div>
      ) : (
        <div className="grid-semesters">
          {workspaces.map(ws => (
            <SemesterCard
              key={ws.workspace_id}
              ws={ws}
              stateLabel={stateLabel}
              stateColor={stateColor}
              onClick={() => navigate(`/hod/workspace/${ws.workspace_id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function SemesterCard({ ws, stateLabel, stateColor, onClick }: {
  ws: WorkspaceCard;
  stateLabel: Record<string, string>;
  stateColor: Record<string, string>;
  onClick: () => void;
}) {
  const state = ws.workflow_state;
  const pending = ws.pool_count - ws.allocated_count;

  return (
    <div
      className={`semester-card ${state === 'FINALIZED' ? 'finalized' : ''}`}
      onClick={onClick}
      style={{ cursor: 'pointer' }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
        <div>
          <div style={{ fontSize: '12px', fontWeight: 700, color: '#94A3B8', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '4px' }}>
            Semester
          </div>
          <div style={{ fontSize: '36px', fontWeight: 900, color: '#002147', lineHeight: 1, fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            {ws.semester}
          </div>
        </div>
        <ProgressSphere percent={ws.progress_percent} size={70} />
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '14px' }}>
        <span className={`chip ${stateColor[state] || 'chip-not-started'}`}>
          {stateLabel[state] || state}
        </span>
        {ws.sections.slice(0, 4).map(s => (
          <span key={s.id} className="chip" style={{ background: '#EFF6FF', color: '#1D4ED8' }}>
            Sec {s.name}
          </span>
        ))}
      </div>

      <div style={{ borderTop: '1px solid #F1F5F9', paddingTop: '12px', display: 'flex', gap: '16px' }}>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#002147' }}>{ws.subject_count}</div>
          <div style={{ fontSize: '10px', fontWeight: 600, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Subjects</div>
        </div>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{ fontSize: '20px', fontWeight: 800, color: '#10B981' }}>{ws.submitted_count}</div>
          <div style={{ fontSize: '10px', fontWeight: 600, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Submitted</div>
        </div>
        <div style={{ flex: 1, textAlign: 'center' }}>
          <div style={{ fontSize: '20px', fontWeight: 800, color: pending > 0 ? '#F59E0B' : '#10B981' }}>{pending}</div>
          <div style={{ fontSize: '10px', fontWeight: 600, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Pending</div>
        </div>
      </div>

      <div style={{ marginTop: '14px', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: '6px', color: '#002147', fontSize: '13px', fontWeight: 600 }}>
        Open Workspace →
      </div>
    </div>
  );
}
