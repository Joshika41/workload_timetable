from fastapi import APIRouter, Depends, HTTPException, status, Form
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.database.connection import get_db
from app.models.domain import User, RoleEnum, FacultyProfile, Department, Programme, AcademicYear, AcademicWorkspace
from app.auth.jwt import verify_password, create_access_token
from typing import Optional
from pydantic import BaseModel

router = APIRouter()

class DemoLoginRequest(BaseModel):
    role: str
    department_id: Optional[int] = None
    programme_id: Optional[int] = None
    semester_type: Optional[str] = "ODD"
    faculty_id: Optional[int] = None  # For faculty "who are you" step

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token = create_access_token(data={"sub": str(user.id), "role": user.role.value})
    name = user.faculty_profile.name if user.faculty_profile else user.email
    
    return {
        "access_token": access_token, 
        "token_type": "bearer",
        "role": user.role.value,
        "name": name,
        "department_id": user.department_id
    }

@router.post("/demo-login")
def demo_login(req: DemoLoginRequest, db: Session = Depends(get_db)):
    """
    Creates a real backend session for the seeded demo users.
    No credentials required - just role, department_id, programme_id, semester_type.
    Faculty: also accepts faculty_id to impersonate a specific faculty member.
    """
    try:
        requested_role = RoleEnum(req.role)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid role: {req.role}")
    
    user = None

    if requested_role == RoleEnum.FACULTY and req.faculty_id:
        # Faculty "who are you" - find the user for this faculty profile
        fp = db.query(FacultyProfile).filter(FacultyProfile.id == req.faculty_id).first()
        if fp:
            user = db.query(User).filter(User.id == fp.user_id).first()
    
    if not user and req.department_id:
        user = db.query(User).filter(
            User.role == requested_role,
            User.department_id == req.department_id
        ).first()
    
    if not user:
        user = db.query(User).filter(User.role == requested_role).first()
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail=f"No demo user found for role '{req.role}' in this department. Please check that seed data is loaded."
        )
    
    # Build the token with full context
    token_data = {
        "sub": str(user.id),
        "role": user.role.value,
        "dept_id": user.department_id,
        "prog_id": req.programme_id,
        "sem_type": req.semester_type or "ODD"
    }
    access_token = create_access_token(data=token_data)
    
    faculty_profile = db.query(FacultyProfile).filter(FacultyProfile.user_id == user.id).first()
    name = faculty_profile.name if faculty_profile else (user.email.split("@")[0].replace("_", " ").title())
    
    dept = db.query(Department).filter(Department.id == user.department_id).first()
    prog = db.query(Programme).filter(Programme.id == req.programme_id).first() if req.programme_id else None
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "role": user.role.value,
        "name": name,
        "user_id": user.id,
        "faculty_profile_id": faculty_profile.id if faculty_profile else None,
        "department_id": user.department_id,
        "department_name": dept.name if dept else None,
        "programme_id": req.programme_id,
        "programme_name": prog.name if prog else None,
        "programme_type": prog.programme_type if prog else None,
        "semester_type": req.semester_type or "ODD",
    }

@router.get("/me")
def get_current_user_info(db: Session = Depends(get_db)):
    """Returns info about the currently logged in user (token validated by middleware)."""
    from app.auth.dependencies import get_current_user
    from fastapi import Depends as FastDepends
    raise HTTPException(status_code=501, detail="Use /me with auth token")
