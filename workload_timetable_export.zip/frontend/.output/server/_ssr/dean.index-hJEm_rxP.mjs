import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useAuth, n as Button, r as api } from "./button-V9LDemPn.mjs";
import { A as FileSpreadsheet } from "../_libs/lucide-react.mjs";
import { r as deanNav, t as PortalShell } from "./portal-nav-DZYI--rN.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dean.index-hJEm_rxP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DAYS = [
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday"
];
var PERIODS = [
	1,
	2,
	3,
	4,
	5,
	6
];
function DeanDashboard() {
	const { session } = useAuth();
	const [departmentFilter, setDepartmentFilter] = (0, import_react.useState)("ALL");
	const { data: masterTimetable, isLoading } = useQuery({
		queryKey: ["master-timetable"],
		queryFn: async () => {
			try {
				return (await api.get("/api/workload/summary")).data;
			} catch (e) {
				return [];
			}
		}
	});
	const getSlot = (day, period) => {
		if (!masterTimetable) return [];
		return masterTimetable.filter((t) => t.day === day && t.period === period && (departmentFilter === "ALL" || t.department === departmentFilter));
	};
	const departments = masterTimetable ? Array.from(new Set(masterTimetable.map((t) => t.department))) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShell, {
		role: "dean",
		title: "Master Timetable Oversight",
		subtitle: "Universal layout mapping all assignments across departments",
		nav: deanNav,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-6 shadow-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-between items-center mb-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold text-foreground",
					children: "Institutional Matrix"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: async () => {
							try {
								const response = await api.get("/api/export/timetable", { responseType: "blob" });
								const url = window.URL.createObjectURL(new Blob([response.data]));
								const link = document.createElement("a");
								link.href = url;
								link.setAttribute("download", "master_timetable.xlsx");
								document.body.appendChild(link);
								link.click();
								link.parentNode?.removeChild(link);
							} catch (err) {
								toast.error("Export failed");
							}
						},
						className: "bg-green-500/10 text-green-600 hover:bg-green-500/20 hover:text-green-700 border-green-500/20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "mr-2 size-4" }), "Export to Excel"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: departmentFilter,
						onChange: (e) => setDepartmentFilter(e.target.value),
						className: "rounded border border-border bg-background px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "ALL",
							children: "All Departments"
						}), departments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: d,
							children: d
						}, d))]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto mb-6",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground text-center py-8",
					children: "Loading Master Timetable..."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full border-collapse",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "p-3 border font-medium text-sm text-muted-foreground bg-muted w-32",
						children: "Day"
					}), PERIODS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
						className: "p-3 border font-medium text-sm text-muted-foreground bg-muted",
						children: ["Period ", p]
					}, p))] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: DAYS.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "p-3 border font-medium text-sm bg-muted/30",
						children: day
					}), PERIODS.map((period) => {
						const slots = getSlot(day, period);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "p-2 border text-xs align-top",
							children: slots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground/50 italic",
								children: "Empty"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2 max-h-32 overflow-y-auto pr-1",
								children: slots.map((s, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-1.5 rounded bg-primary/10 border border-primary/20 text-primary-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-semibold text-primary truncate",
											children: s.subject_name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground truncate",
											children: s.faculty_name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between mt-1 text-[10px] text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.room_no }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.section })]
										})
									]
								}, idx))
							})
						}, period);
					})] }, day)) })]
				})
			})]
		})
	});
}
//#endregion
export { DeanDashboard as component };
