﻿from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.database.connection import get_db
from app.models.domain import (
    User, RoleEnum, AcademicWorkspace, WorkspaceWorkflowStateEnum,
    Subject, PreferenceSubmission, PreferenceStatusEnum
)
from app.auth.dependencies import require_role, get_current_user
from app.schemas.preferences import (
    PreferenceSubmitRequest, PreferenceSubmissionResponse,
    PreferenceDecisionRequest, SubmissionReviewRequest
)
from app.services.preference_service import PreferenceService
from app.auth.workspace_auth import verify_workspace_access
from app.core.workspace import WorkspaceContext, decode_workspace_id

router = APIRouter()
pref_service = PreferenceService()

def _serialize_submission(s) -> dict:
    items = []
    for i in s.items:
        items.append({
            "id": i.id,
            "subject_id": i.subject_id,
            "subject_code": i.subject.course_code,
            "subject_name": i.subject.course_name,
            "category": i.subject.category,
            "rank": i.rank,
            "decision": i.decision.value,
        })
    return {
        "id": s.id,
        "faculty_id": s.faculty_id,
        "faculty_name": s.faculty.name,
        "workspace_id": s.workspace_id,
        "status": s.status.value,
        "review_status": s.review_status.value if hasattr(s, "review_status") and s.review_status else "PENDING",
        "submitted_at": s.submitted_at,
        "items": sorted(items, key=lambda x: x["rank"]),
    }

# ── Faculty: GET my preferences
@router.get("/faculty/preferences", response_model=List[PreferenceSubmissionResponse])
def get_my_preferences(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.FACULTY.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    submissions = pref_service.get_my_preferences(db, current_user, workspace_id)
    return [_serialize_submission(s) for s in submissions]

# ── Faculty: POST submit preferences (Core+Elective enforced here + finalization lock)
@router.post("/faculty/preferences")
def submit_preferences(
    req: PreferenceSubmitRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.FACULTY.value]))
):
    try:
        context = decode_workspace_id(req.workspace_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid workspace ID")

    if current_user.department_id != context.department_id:
        raise HTTPException(status_code=403, detail="Not authorized for this workspace")

    # Check finalization lock
    workspace = db.query(AcademicWorkspace).filter(AcademicWorkspace.id == req.workspace_id).first()
    if workspace and workspace.workflow_state == WorkspaceWorkflowStateEnum.FINALIZED:
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail="This workspace is finalized. Preferences cannot be modified."
        )

    # Enforce Core + Elective rule
    subject_ids = [p.subject_id for p in req.preferences]
    if len(subject_ids) != len(set(subject_ids)):
        raise HTTPException(status_code=400, detail="Duplicate subjects found in preferences")

    subjects = db.query(Subject).filter(Subject.id.in_(subject_ids)).all()
    categories = {s.id: s.category for s in subjects}

    has_core = any(categories.get(sid, "") == "CORE" for sid in subject_ids)
    has_elective = any(categories.get(sid, "") == "ELECTIVE" for sid in subject_ids)

    if not has_core:
        raise HTTPException(
            status_code=422,
            detail="Submission must include at least one CORE subject."
        )
    if not has_elective:
        raise HTTPException(
            status_code=422,
            detail="Submission must include at least one ELECTIVE subject."
        )

    sub = pref_service.submit_preferences(db, current_user, req, context)
    return {"message": "Preferences submitted successfully", "id": sub.id}

# ── HOD/Coordinator: GET all preferences for workspace
@router.get("/coordinator/preferences", response_model=List[PreferenceSubmissionResponse])
def get_all_preferences(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    submissions = pref_service.get_all_preferences(db, current_user, workspace_id)
    return [_serialize_submission(s) for s in submissions]

# ── HOD: PATCH review a whole submission (approve/pending/deny the submission)
@router.patch("/coordinator/preferences/submissions/{submission_id}/review")
def review_submission(
    submission_id: int,
    req: SubmissionReviewRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value]))
):
    submission = db.query(PreferenceSubmission).filter(PreferenceSubmission.id == submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    # Authorization: verify department
    if submission.faculty.user.department_id != current_user.department_id:
        raise HTTPException(status_code=403, detail="Not authorized")

    # Check finalization lock
    workspace = db.query(AcademicWorkspace).filter(AcademicWorkspace.id == submission.workspace_id).first()
    if workspace and workspace.workflow_state == WorkspaceWorkflowStateEnum.FINALIZED:
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail="This workspace is finalized. Review decisions cannot be modified."
        )

    try:
        review_enum = PreferenceStatusEnum(req.review_status)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid review status")

    if review_enum not in [PreferenceStatusEnum.APPROVED, PreferenceStatusEnum.PENDING, PreferenceStatusEnum.DENIED]:
        raise HTTPException(status_code=400, detail="Review status must be APPROVED, PENDING, or DENIED")

    submission.review_status = review_enum
    db.commit()
    return {"message": "Review updated", "review_status": review_enum.value}

# ── HOD: PATCH item-level decision (kept for backward compatibility)
@router.patch("/coordinator/preferences/{item_id}")
def decide_preference(
    item_id: int,
    req: PreferenceDecisionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value]))
):
    pref_service.decide_preference(db, item_id, req.decision)
    return {"message": "Decision updated successfully"}
