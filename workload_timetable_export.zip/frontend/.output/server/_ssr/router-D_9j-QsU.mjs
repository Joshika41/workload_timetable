import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as Button, t as AuthProvider } from "./button-V9LDemPn.mjs";
import { t as WorkspaceProvider } from "./WorkspaceContext-CpWbC3cp.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as House, m as RefreshCw, z as CircleAlert } from "../_libs/lucide-react.mjs";
import { n as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-D_9j-QsU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-C4zMMjji.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var ErrorBoundary = class extends import_react.Component {
	state = {
		hasError: false,
		error: null
	};
	static getDerivedStateFromError(error) {
		return {
			hasError: true,
			error
		};
	}
	componentDidCatch(error, errorInfo) {
		console.error("Uncaught error:", error, errorInfo);
	}
	render() {
		if (this.state.hasError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-screen bg-slate-50 flex items-center justify-center p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-md w-full bg-white rounded-2xl shadow-xl border border-slate-100 p-8 text-center space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "w-8 h-8 text-red-500" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold tracking-tight text-slate-900",
						children: "System Recovering"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-slate-500 mt-2 text-sm leading-relaxed",
						children: "An unexpected rendering error occurred. The application has caught the exception to protect your data."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pt-4 flex flex-col sm:flex-row items-center justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							className: "w-full sm:w-auto gap-2",
							onClick: () => window.location.reload(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "w-4 h-4" }), "Reload Page"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "w-full sm:w-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "w-full gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, { className: "w-4 h-4" }), "Return Home"]
							})
						})]
					})
				]
			})
		});
		return this.props.children;
	}
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$14 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "SRM Timetable & Workload ERP" },
			{
				name: "description",
				content: "Institutional ERP for university timetable scheduling, faculty workload allocation and departmental oversight."
			},
			{
				name: "author",
				content: "SRM University"
			},
			{
				property: "og:title",
				content: "SRM Timetable & Workload ERP"
			},
			{
				property: "og:description",
				content: "Institutional ERP for university timetable scheduling, faculty workload allocation and departmental oversight."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@Lovable"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "icon",
			href: "/favicon.ico",
			type: "image/x-icon"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$14.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkspaceProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBoundary, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "top-right" })] }) })
	});
}
var $$splitComponentImporter$13 = () => import("./routes-CEiI5yIs.mjs");
var Route$13 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Sign In · SRM Faculty Preference & Workload ERP" }, {
		name: "description",
		content: "Sign in to the SRM University Faculty Preference and Workload Management Portal."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./admin.index-BbXQGszb.mjs");
var Route$12 = createFileRoute("/admin/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./admin.allocation-rw7TocEd.mjs");
var Route$11 = createFileRoute("/admin/allocation")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./admin.audit-BHdjKurv.mjs");
var Route$10 = createFileRoute("/admin/audit")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./admin.faculty-CAhcKoot.mjs");
var Route$9 = createFileRoute("/admin/faculty")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./admin.preferences-DRWBoKHC.mjs");
var Route$8 = createFileRoute("/admin/preferences")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./admin.setup-CijS3XCu.mjs");
var Route$7 = createFileRoute("/admin/setup")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./admin.timetables-tDE5gavS.mjs");
var Route$6 = createFileRoute("/admin/timetables")({
	head: () => ({ meta: [
		{ title: "Master Class Timetables · Admin · SRM ERP" },
		{
			name: "description",
			content: "Review published six-period master timetables for every MCA section with venue and lab allocations."
		},
		{
			property: "og:title",
			content: "Master Class Timetables · Admin · SRM ERP"
		},
		{
			property: "og:description",
			content: "Six-period master timetables for every section with venue and lab allocations."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./admin.workload-BBlYsiCt.mjs");
var Route$5 = createFileRoute("/admin/workload")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./dean.index-hJEm_rxP.mjs");
var Route$4 = createFileRoute("/dean/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./dean.timetables-BUpfeS_J.mjs");
var Route$3 = createFileRoute("/dean/timetables")({
	head: () => ({ meta: [
		{ title: "Universal Timetables · Dean · SRM ERP" },
		{
			name: "description",
			content: "View published six-period timetables for every institutional section in a read-only oversight mode."
		},
		{
			property: "og:title",
			content: "Universal Timetables · Dean · SRM ERP"
		},
		{
			property: "og:description",
			content: "Read-only institutional timetables across all sections."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./faculty.index-URxe34Uy.mjs");
var Route$2 = createFileRoute("/faculty/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./faculty.dashboard-Dc7ncUjn.mjs");
var Route$1 = createFileRoute("/faculty/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./faculty.timetable-C4ISTgcS.mjs");
var Route = createFileRoute("/faculty/timetable")({
	head: () => ({ meta: [
		{ title: "My Timetable · Faculty · SRM ERP" },
		{
			name: "description",
			content: "Personal five-day, six-period teaching schedule with section and venue details, plus class schedule views."
		},
		{
			property: "og:title",
			content: "My Timetable · Faculty · SRM ERP"
		},
		{
			property: "og:description",
			content: "Personal weekly teaching schedule with sections and venues."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$14
});
var AdminIndexRoute = Route$12.update({
	id: "/admin/",
	path: "/admin/",
	getParentRoute: () => Route$14
});
var AdminAllocationRoute = Route$11.update({
	id: "/admin/allocation",
	path: "/admin/allocation",
	getParentRoute: () => Route$14
});
var AdminAuditRoute = Route$10.update({
	id: "/admin/audit",
	path: "/admin/audit",
	getParentRoute: () => Route$14
});
var AdminFacultyRoute = Route$9.update({
	id: "/admin/faculty",
	path: "/admin/faculty",
	getParentRoute: () => Route$14
});
var AdminPreferencesRoute = Route$8.update({
	id: "/admin/preferences",
	path: "/admin/preferences",
	getParentRoute: () => Route$14
});
var AdminSetupRoute = Route$7.update({
	id: "/admin/setup",
	path: "/admin/setup",
	getParentRoute: () => Route$14
});
var AdminTimetablesRoute = Route$6.update({
	id: "/admin/timetables",
	path: "/admin/timetables",
	getParentRoute: () => Route$14
});
var AdminWorkloadRoute = Route$5.update({
	id: "/admin/workload",
	path: "/admin/workload",
	getParentRoute: () => Route$14
});
var DeanIndexRoute = Route$4.update({
	id: "/dean/",
	path: "/dean/",
	getParentRoute: () => Route$14
});
var DeanTimetablesRoute = Route$3.update({
	id: "/dean/timetables",
	path: "/dean/timetables",
	getParentRoute: () => Route$14
});
var FacultyIndexRoute = Route$2.update({
	id: "/faculty/",
	path: "/faculty/",
	getParentRoute: () => Route$14
});
var rootRouteChildren = {
	IndexRoute,
	AdminAllocationRoute,
	AdminAuditRoute,
	AdminFacultyRoute,
	AdminPreferencesRoute,
	AdminSetupRoute,
	AdminTimetablesRoute,
	AdminWorkloadRoute,
	DeanTimetablesRoute,
	FacultyDashboardRoute: Route$1.update({
		id: "/faculty/dashboard",
		path: "/faculty/dashboard",
		getParentRoute: () => Route$14
	}),
	FacultyTimetableRoute: Route.update({
		id: "/faculty/timetable",
		path: "/faculty/timetable",
		getParentRoute: () => Route$14
	}),
	AdminIndexRoute,
	DeanIndexRoute,
	FacultyIndexRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
