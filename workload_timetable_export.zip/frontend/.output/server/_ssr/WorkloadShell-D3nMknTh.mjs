import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as axios } from "../_libs/axios+[...].mjs";
import { a as useAuth, i as cn, n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { n as useWorkspace } from "./WorkspaceContext-CpWbC3cp.mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as ChevronRight, F as ClipboardList, H as Check, I as Circle, K as Building, Q as ArrowRightLeft, U as ChartColumn, V as ChevronDown, Y as BookOpen, c as SlidersHorizontal, i as UserCheck, k as GraduationCap, n as Users, p as RotateCcw, t as X, v as Menu, w as LayoutDashboard, y as LogOut } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Label2, c as Root2, d as SubTrigger2, f as Trigger, i as ItemIndicator2, l as Separator2, n as Content2, o as Portal2, r as Item2, s as RadioItem2, t as CheckboxItem2, u as SubContent2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/WorkloadShell-D3nMknTh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var apiClient = axios.create({
	baseURL: "http://localhost:8000/api",
	headers: { "Content-Type": "application/json" }
});
apiClient.interceptors.request.use((config) => {
	const token = localStorage.getItem("token");
	if (token) config.headers.Authorization = `Bearer ${token}`;
	return config;
});
apiClient.interceptors.response.use((response) => response, (error) => {
	if (error.response?.status === 401) {
		localStorage.removeItem("token");
		localStorage.removeItem("user");
		window.location.href = "/";
	}
	return Promise.reject(error);
});
var academicApi = {
	getDepartments: async () => {
		return (await apiClient.get("/departments")).data;
	},
	getWorkspaces: async () => {
		return (await apiClient.get("/academic-workspaces")).data;
	}
};
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function WorkloadShell({ role, title, subtitle, children, actions }) {
	const { session, signOut } = useAuth();
	const navigate = useNavigate();
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const [switchUserModalOpen, setSwitchUserModalOpen] = (0, import_react.useState)(false);
	const [workspaces, setWorkspaces] = (0, import_react.useState)([]);
	const { activeDepartmentId, setActiveDepartmentId, activeDepartmentName, setActiveDepartmentName } = useWorkspace();
	import("../_libs/@floating-ui/react-dom+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.u())).then(({ useEffect }) => {
		useEffect(() => {
			if (role === "admin") academicApi.getWorkspaces().then((data) => {
				setWorkspaces(data);
				if (data.length > 0 && !activeDepartmentId) {
					setActiveDepartmentId(data[0].department_id);
					setActiveDepartmentName(data[0].department_name);
				}
			}).catch(console.error);
		}, [role, activeDepartmentId]);
	});
	const { facultyList, currentFacultyId, currentFaculty, setCurrentFacultyId, resetAllToMockData, dashboardMetrics } = useWorkloadData();
	const isHod = role === "admin";
	const hodNavGroups = [
		{ items: [{
			to: "/admin",
			label: "HOD Dashboard",
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" })
		}] },
		{
			groupTitle: "Academic Setup",
			items: [{
				to: "/admin/setup",
				label: "Course & Class Setup",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" })
			}]
		},
		{
			groupTitle: "Faculty Management",
			items: [{
				to: "/admin/faculty",
				label: "Faculty Master & Limits",
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4" }),
				badge: facultyList.length
			}]
		},
		{
			groupTitle: "Workload Management",
			items: [
				{
					to: "/admin/preferences",
					label: "Faculty Preferences",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" }),
					badge: dashboardMetrics.pendingPreferences > 0 ? `${dashboardMetrics.pendingPreferences} Pending` : void 0
				},
				{
					to: "/admin/allocation",
					label: "Course Allocation",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4" })
				},
				{
					to: "/admin/workload",
					label: "Workload Sheets & Export",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "size-4" })
				}
			]
		}
	];
	const activeNavGroups = isHod ? hodNavGroups : [{ items: [{
		to: "/faculty/dashboard",
		label: "Faculty Dashboard",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "size-4" })
	}, {
		to: "/faculty/dashboard",
		label: "Subject Preference Cart",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4" })
	}] }];
	const handleSwitchFaculty = (facId) => {
		setCurrentFacultyId(facId);
		const target = facultyList.find((f) => f.id === facId);
		toast.success(`Switched active faculty to ${target?.name}`);
		setSwitchUserModalOpen(false);
		if (!isHod) navigate({ to: "/faculty/dashboard" });
	};
	const handleResetData = () => {
		if (window.confirm("Reset all faculty allocations, preferences, and default hours to original Excel spreadsheet data?")) {
			resetAllToMockData();
			toast.success("Workload system reset to official mock data");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-slate-50 flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 bg-[#002147] text-white shadow-md border-b border-blue-900/60",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setMobileMenuOpen(!mobileMenuOpen),
							className: "lg:hidden p-1.5 rounded-md hover:bg-white/10 text-white",
							"aria-label": "Toggle Navigation",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-9 rounded-lg bg-white/10 ring-1 ring-white/20 flex items-center justify-center font-serif text-teal-300 font-bold text-lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-5 text-teal-300" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold tracking-wide text-xs sm:text-sm text-white uppercase",
									children: "SRM Institute of Science and Technology"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden md:inline-block px-2 py-0.5 text-[10px] font-semibold bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded",
									children: "MCA ERP"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-blue-200/80 hidden sm:block",
								children: "Faculty Preference & Workload Management System · 2026-2027"
							})] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 sm:gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "outline",
									className: "h-8 border-blue-400/30 bg-white/10 text-white hover:bg-white/20 hover:text-white text-xs gap-1.5 rounded-lg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { className: "size-3.5 text-teal-300" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "Switch Role / User"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3 text-blue-300 opacity-70" })
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
								align: "end",
								className: "w-64",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
										className: "text-xs uppercase text-muted-foreground",
										children: "Switch Portal View"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
										onClick: () => {
											navigate({ to: "/admin" });
										},
										className: "gap-2 font-medium cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4 text-blue-600" }), "HOD / Administrator Console"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
										onClick: () => {
											navigate({ to: "/faculty/dashboard" });
										},
										className: "gap-2 font-medium cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "size-4 text-emerald-600" }), "Faculty Preference Portal"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, {
										className: "text-xs uppercase text-muted-foreground",
										children: "Switch Active Faculty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "max-h-48 overflow-y-auto",
										children: facultyList.slice(0, 10).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
											onClick: () => handleSwitchFaculty(f.id),
											className: cn("text-xs cursor-pointer", currentFacultyId === f.id && "font-bold bg-blue-50 text-blue-700"),
											children: [
												f.name,
												" (",
												f.programme,
												")"
											]
										}, f.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
										onClick: () => setSwitchUserModalOpen(true),
										className: "text-xs text-primary font-medium cursor-pointer",
										children: "View All 18 Faculty Members..."
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: handleResetData,
								title: "Reset state to official mock data",
								className: "h-8 px-2 text-blue-200 hover:text-white hover:bg-white/10 text-xs hidden md:flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5 text-amber-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Reset Data" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden lg:flex items-center gap-2 pl-2 border-l border-blue-800/80 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold text-white leading-tight",
										children: isHod ? "Dr. HOD (MCA)" : currentFaculty?.name || "Faculty Member"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-teal-300 font-mono",
										children: isHod ? "Head of Department" : `${currentFaculty?.designation} · ${currentFaculty?.id}`
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "size-8 rounded-full bg-teal-500/20 text-teal-300 border border-teal-400/40 flex items-center justify-center font-bold text-xs",
									children: isHod ? "HOD" : currentFaculty?.name.charAt(3) || "F"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => {
									signOut();
									navigate({ to: "/" });
								},
								className: "h-8 px-2.5 text-blue-200 hover:text-white hover:bg-white/10 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3.5 mr-1" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Sign Out"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: cn("fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-200 ease-in-out lg:static lg:translate-x-0 pt-16 lg:pt-0", mobileMenuOpen ? "translate-x-0" : "-translate-x-full"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "lg:hidden flex items-center justify-between p-4 border-b",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-slate-500 uppercase tracking-wider",
									children: "Navigation Menu"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setMobileMenuOpen(false),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5 text-slate-600" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-4 border-b border-slate-100 bg-slate-50/80",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider",
										children: "Department Scope"
									}),
									isHod ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										className: "w-full mt-1 border-slate-300 rounded text-xs font-bold text-slate-800 p-1 truncate bg-white",
										value: activeDepartmentId || "",
										onChange: (e) => {
											const ws = workspaces.find((w) => w.department_id === parseInt(e.target.value));
											if (ws) {
												setActiveDepartmentId(ws.department_id);
												setActiveDepartmentName(ws.department_name);
											}
										},
										children: workspaces.map((ws) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: ws.department_id,
											children: ws.department_name
										}, ws.department_id))
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-bold text-slate-800 mt-0.5 truncate",
										children: currentFaculty?.department || "PG Dept. of Computer Applications"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 mt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-2 rounded-full bg-emerald-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[11px] font-medium text-slate-600",
											children: isHod && workspaces.find((w) => w.department_id === activeDepartmentId) ? `${workspaces.find((w) => w.department_id === activeDepartmentId)?.semester_type === "ODD" ? "Odd" : "Even"} Sem ${workspaces.find((w) => w.department_id === activeDepartmentId)?.academic_year_name}` : "Odd Semester 2026-2027"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
								className: "flex-1 overflow-y-auto p-3 space-y-4",
								children: activeNavGroups.map((group, gIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [group.groupTitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-3 pt-2 pb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400",
										children: group.groupTitle
									}), group.items.map((item, itemIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: item.to,
										onClick: () => setMobileMenuOpen(false),
										className: "flex items-center justify-between gap-3 px-3 py-2 text-xs font-medium rounded-lg text-slate-700 hover:bg-blue-50 hover:text-[#002147] transition-colors data-[status=active]:bg-[#002147] data-[status=active]:text-white",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5 truncate",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "shrink-0",
												children: item.icon
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate",
												children: item.label
											})]
										}), item.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-teal-100 text-teal-800",
											children: item.badge
										})]
									}, itemIdx))]
								}, gIdx))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-3 border-t border-slate-100 bg-slate-50/50",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border border-slate-200 bg-white p-2.5 text-xs space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-[11px] text-slate-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Active Profile:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-800",
												children: isHod ? "HOD" : "Faculty"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-[11px] text-slate-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Allocated Hours:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold text-teal-700",
												children: [dashboardMetrics.allocatedHours, " hrs"]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center text-[11px] text-slate-500",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Unallocated:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold text-amber-700",
												children: [dashboardMetrics.unallocatedHours, " hrs"]
											})]
										})
									]
								})
							})
						]
					}),
					mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						onClick: () => setMobileMenuOpen(false),
						className: "fixed inset-0 z-20 bg-slate-900/50 lg:hidden"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "flex-1 flex flex-col min-w-0 bg-slate-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white border-b border-slate-200 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl sm:text-2xl font-bold text-slate-900 tracking-tight",
								children: title
							}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-slate-500 mt-0.5",
								children: subtitle
							})] }), actions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-2.5 flex-wrap",
								children: actions
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto space-y-6",
							children
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: switchUserModalOpen,
				onOpenChange: setSwitchUserModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5 text-blue-600" }), " Switch Faculty Profile"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Select any of the 18 faculty members to preview their personal dashboard, subject cart, and workload calculations." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 max-h-96 overflow-y-auto py-2",
						children: facultyList.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleSwitchFaculty(f.id),
							className: cn("flex items-center justify-between p-3 rounded-lg border text-left transition-all hover:border-blue-500 hover:bg-blue-50/50", currentFacultyId === f.id ? "border-blue-600 bg-blue-50/80 ring-1 ring-blue-600" : "border-slate-200 bg-white"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-semibold text-slate-900",
								children: f.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-slate-500",
								children: [
									f.designation,
									" · ",
									f.programme,
									" · ",
									f.email
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700",
									children: [
										"Default: ",
										f.defaultWorkloadHours,
										"h"
									]
								})
							})]
						}, f.id))
					})]
				})
			})
		]
	});
}
//#endregion
export { DialogTitle as a, DialogHeader as i, DialogContent as n, WorkloadShell as o, DialogDescription as r, apiClient as s, Dialog as t };
