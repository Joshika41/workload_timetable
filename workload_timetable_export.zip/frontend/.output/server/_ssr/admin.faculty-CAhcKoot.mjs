import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { $ as ArrowLeft, _ as Pen, d as Search, g as Plus, n as Users, o as Trash2 } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.faculty-CAhcKoot.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminFacultyMasterPage() {
	const { facultyList, allWorkloads, updateFacultyMember, addFacultyMember, deleteFacultyMember } = useWorkloadData();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [editingFaculty, setEditingFaculty] = (0, import_react.useState)(null);
	const [isAddModalOpen, setIsAddModalOpen] = (0, import_react.useState)(false);
	const [newFaculty, setNewFaculty] = (0, import_react.useState)({
		id: `FAC0${facultyList.length + 1}`,
		name: "",
		designation: "Assistant Professor",
		department: "MCA",
		programme: "MCA",
		facultyType: "Regular",
		defaultWorkloadHours: 18,
		email: "",
		status: "ACTIVE"
	});
	const filteredFaculty = facultyList.filter((f) => {
		const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase()) || f.id.toLowerCase().includes(searchTerm.toLowerCase()) || f.email.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesProg = programmeFilter === "ALL" || f.programme === programmeFilter;
		return matchesSearch && matchesProg;
	});
	const handleSaveEdit = () => {
		if (!editingFaculty) return;
		updateFacultyMember(editingFaculty);
		toast.success(`Updated details for ${editingFaculty.name}`);
		setEditingFaculty(null);
	};
	const handleCreateFaculty = () => {
		if (!newFaculty.name || !newFaculty.email) {
			toast.error("Please provide faculty name and email address.");
			return;
		}
		const created = {
			id: newFaculty.id || `FAC${Date.now().toString().slice(-3)}`,
			name: newFaculty.name,
			designation: newFaculty.designation || "Assistant Professor",
			department: "MCA",
			programme: newFaculty.programme || "MCA",
			facultyType: newFaculty.facultyType || "Regular",
			defaultWorkloadHours: newFaculty.defaultWorkloadHours || 18,
			email: newFaculty.email,
			status: "ACTIVE"
		};
		addFacultyMember(created);
		toast.success(`Added faculty member ${created.name}`);
		setIsAddModalOpen(false);
		setNewFaculty({
			id: `FAC0${facultyList.length + 2}`,
			name: "",
			designation: "Assistant Professor",
			department: "MCA",
			programme: "MCA",
			facultyType: "Regular",
			defaultWorkloadHours: 18,
			email: "",
			status: "ACTIVE"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "Faculty Master & Workload Configuration",
		subtitle: "Maintain staff profiles, designations, departmental programmes, and default workload limits",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => window.history.back(),
				className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: () => setIsAddModalOpen(true),
				className: "h-8 gap-1.5 text-xs bg-[#002147] hover:bg-[#001833] text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Add Faculty Member" })]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-[#002147]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "text-xs font-bold uppercase tracking-wider text-slate-800",
						children: [
							"Registered Faculty (",
							facultyList.length,
							" members)"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 w-full sm:w-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 sm:w-64",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: "Search staff name or ID...",
							value: searchTerm,
							onChange: (e) => setSearchTerm(e.target.value),
							className: "h-8 pl-7 text-xs bg-slate-50"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: programmeFilter,
						onChange: (e) => setProgrammeFilter(e.target.value),
						className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "ALL",
								children: "All Programmes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "MCA",
								children: "MCA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "MCA GEN AI",
								children: "MCA GEN AI"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border-collapse min-w-[850px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Faculty ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Faculty Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Designation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Programme"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Faculty Type"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Default Target"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Allocated (T+P)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Remaining Balance"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200",
							children: filteredFaculty.map((f) => {
								const w = allWorkloads.find((x) => x.facultyId === f.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-blue-50/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-mono font-bold text-slate-600",
											children: f.id
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 font-bold text-slate-900",
											children: [f.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-[10px] text-slate-400 font-normal font-mono",
												children: f.email
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-slate-700 font-medium",
											children: f.designation
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-800",
												children: f.programme
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[10px] text-slate-400 block font-mono",
												children: ["Dept: ", f.department]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 border text-slate-700",
												children: f.facultyType
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-black text-xs text-blue-900 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded",
												children: [f.defaultWorkloadHours, " hrs"]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold text-slate-800",
												children: [w?.allocatedHours || 0, " hrs"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-[10px] text-slate-400 font-mono",
												children: [
													"(T:",
													w?.theoryHours || 0,
													"h / P:",
													w?.practicalHours || 0,
													"h)"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `font-mono font-bold text-xs px-2 py-0.5 rounded border ${(w?.remainingHours ?? 0) === 0 && (w?.allocatedHours ?? 0) > 0 ? "bg-emerald-50 text-emerald-800 border-emerald-300" : (w?.remainingHours ?? 0) > 0 ? "bg-blue-50 text-blue-800 border-blue-200" : "bg-rose-50 text-rose-800 border-rose-300"}`,
												children: w ? `${w.remainingHours} hrs` : `${f.defaultWorkloadHours} hrs`
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${w?.status === "BALANCED" ? "bg-emerald-100 text-emerald-800 border border-emerald-300" : w?.status === "OVERLOADED" ? "bg-rose-100 text-rose-800 border border-rose-300" : "bg-blue-100 text-blue-800 border border-blue-200"}`,
												children: w?.status || "BALANCED"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-end gap-1.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
													size: "sm",
													variant: "ghost",
													onClick: () => setEditingFaculty(f),
													className: "h-7 px-2 text-xs text-blue-700 hover:bg-blue-50",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-3.5 mr-1" }), "Edit"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "sm",
													variant: "ghost",
													onClick: () => {
														if (window.confirm(`Delete faculty member ${f.name}?`)) {
															deleteFacultyMember(f.id);
															toast.success(`Removed ${f.name}`);
														}
													},
													className: "h-7 px-2 text-xs text-rose-600 hover:bg-rose-50",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})]
											})
										})
									]
								}, f.id);
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!editingFaculty,
				onOpenChange: (open) => !open && setEditingFaculty(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "size-4 text-blue-600" }), "Edit Faculty Profile"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Modify staff details and default weekly workload hour limits." })] }), editingFaculty && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Faculty Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: editingFaculty.name,
								onChange: (e) => setEditingFaculty({
									...editingFaculty,
									name: e.target.value
								}),
								className: "h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Designation"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: editingFaculty.designation,
									onChange: (e) => setEditingFaculty({
										...editingFaculty,
										designation: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Professor & HOD",
											children: "Professor & HOD"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Professor",
											children: "Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Associate Professor",
											children: "Associate Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Assistant Professor",
											children: "Assistant Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Full-Time Scholar (FTS)",
											children: "Full-Time Scholar (FTS)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Assistant Professor (AP/BSc)",
											children: "Assistant Professor (AP/BSc)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Adjunct Faculty",
											children: "Adjunct Faculty"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Programme"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: editingFaculty.programme,
									onChange: (e) => setEditingFaculty({
										...editingFaculty,
										programme: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA",
										children: "MCA"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA GEN AI",
										children: "MCA GEN AI"
									})]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Faculty Type"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: editingFaculty.facultyType,
									onChange: (e) => setEditingFaculty({
										...editingFaculty,
										facultyType: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Regular",
											children: "Regular"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Adjunct",
											children: "Adjunct"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "FTS",
											children: "FTS (Full-Time Scholar)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Visiting",
											children: "Visiting"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-blue-900 mb-1",
									children: "Default Workload (Hours)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: editingFaculty.defaultWorkloadHours,
									onChange: (e) => setEditingFaculty({
										...editingFaculty,
										defaultWorkloadHours: Number(e.target.value)
									}),
									className: "h-8 text-xs font-bold text-blue-900 border-blue-300 bg-blue-50/50"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Email Address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: editingFaculty.email,
								onChange: (e) => setEditingFaculty({
									...editingFaculty,
									email: e.target.value
								}),
								className: "h-8 text-xs font-mono"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setEditingFaculty(null),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: handleSaveEdit,
									className: "bg-[#002147] text-white",
									children: "Save Changes"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAddModalOpen,
				onOpenChange: setIsAddModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-teal-600" }), "Add Faculty Profile"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Create a new faculty profile with custom workload configuration limits." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Faculty Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "e.g. Dr. A. Sharma",
								value: newFaculty.name,
								onChange: (e) => setNewFaculty({
									...newFaculty,
									name: e.target.value
								}),
								className: "h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Designation"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: newFaculty.designation,
									onChange: (e) => setNewFaculty({
										...newFaculty,
										designation: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Professor & HOD",
											children: "Professor & HOD"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Professor",
											children: "Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Associate Professor",
											children: "Associate Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Assistant Professor",
											children: "Assistant Professor"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Full-Time Scholar (FTS)",
											children: "Full-Time Scholar (FTS)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Assistant Professor (AP/BSc)",
											children: "Assistant Professor (AP/BSc)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Adjunct Faculty",
											children: "Adjunct Faculty"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Programme"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: newFaculty.programme,
									onChange: (e) => setNewFaculty({
										...newFaculty,
										programme: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA",
										children: "MCA"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA GEN AI",
										children: "MCA GEN AI"
									})]
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Faculty Type"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: newFaculty.facultyType,
									onChange: (e) => setNewFaculty({
										...newFaculty,
										facultyType: e.target.value
									}),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Regular",
											children: "Regular"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Adjunct",
											children: "Adjunct"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "FTS",
											children: "FTS (Full-Time Scholar)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "Visiting",
											children: "Visiting"
										})
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-blue-900 mb-1",
									children: "Default Workload (Hours)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: newFaculty.defaultWorkloadHours,
									onChange: (e) => setNewFaculty({
										...newFaculty,
										defaultWorkloadHours: Number(e.target.value)
									}),
									className: "h-8 text-xs font-bold text-blue-900 border-blue-300 bg-blue-50/50"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Email Address"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "faculty@srm.edu",
								value: newFaculty.email,
								onChange: (e) => setNewFaculty({
									...newFaculty,
									email: e.target.value
								}),
								className: "h-8 text-xs font-mono"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setIsAddModalOpen(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: handleCreateFaculty,
									className: "bg-[#002147] text-white",
									children: "Create Faculty"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminFacultyMasterPage as component };
