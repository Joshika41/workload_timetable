import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { $ as ArrowLeft, F as ClipboardList, d as Search, j as Eye } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as WorkloadStatusBadge } from "./WorkloadStatusBadge-BmjEjhsL.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
import { t as COURSE_CATEGORIES } from "./workload-types-BTjWZ-Y7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.preferences-DRWBoKHC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPreferencesReviewPage() {
	const { allWorkloads, preferences, courseList } = useWorkloadData();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("ALL");
	const [selectedFacultyId, setSelectedFacultyId] = (0, import_react.useState)(null);
	const selectedFacultyWorkload = allWorkloads.find((w) => w.facultyId === selectedFacultyId);
	const selectedSubmission = selectedFacultyId ? preferences[selectedFacultyId] : null;
	const totalFaculty = allWorkloads.length;
	const submittedCount = allWorkloads.filter((w) => w.preferencesStatus === "SUBMITTED").length;
	const pendingCount = allWorkloads.filter((w) => w.preferencesStatus === "PENDING").length;
	const allocatedCount = allWorkloads.filter((w) => w.allocatedCoursesCount > 0).length;
	const filteredRows = allWorkloads.filter((w) => {
		const matchesSearch = w.facultyName.toLowerCase().includes(searchTerm.toLowerCase()) || w.facultyId.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesProg = programmeFilter === "ALL" || w.programme === programmeFilter;
		const matchesStatus = statusFilter === "ALL" || statusFilter === "SUBMITTED" && w.preferencesStatus === "SUBMITTED" || statusFilter === "PENDING" && w.preferencesStatus === "PENDING";
		return matchesSearch && matchesProg && matchesStatus;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "Faculty Preference Review",
		subtitle: "Examine faculty subject willingness, ranked course selections, and submission statuses",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => window.history.back(),
				className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
			})
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-500",
								children: "Total Faculty"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-slate-900 mt-1",
								children: totalFaculty
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-400 mt-0.5",
								children: "MCA Department"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-blue-700",
								children: "Submitted"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-blue-700 mt-1",
								children: submittedCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-blue-600/80 mt-0.5",
								children: "Preferences Received"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-amber-700",
								children: "Pending"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-amber-600 mt-1",
								children: pendingCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-amber-600/80 mt-0.5",
								children: "Awaiting Submission"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-emerald-700",
								children: "Allocated"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-emerald-600 mt-1",
								children: allocatedCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-emerald-600/80 mt-0.5",
								children: "Assigned Teaching"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row items-start md:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "size-4 text-[#002147]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-bold text-slate-800 uppercase tracking-wider",
							children: "Faculty Preference Carts & Allocation Status"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 w-full md:w-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex-1 md:w-56",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Search faculty name...",
									value: searchTerm,
									onChange: (e) => setSearchTerm(e.target.value),
									className: "h-8 pl-8 text-xs bg-white rounded-md"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: programmeFilter,
								onChange: (e) => setProgrammeFilter(e.target.value),
								className: "h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "All Programmes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA",
										children: "MCA"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA GEN AI",
										children: "MCA GEN AI"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: statusFilter,
								onChange: (e) => setStatusFilter(e.target.value),
								className: "h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "All Submission Statuses"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "SUBMITTED",
										children: "Submitted"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "PENDING",
										children: "Pending"
									})
								]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border-collapse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Faculty"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Programme"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Submitted Preferences"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Default Hrs"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Allocated"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Remaining"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Action"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200",
							children: filteredRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "py-8 text-center text-slate-500",
								children: "No faculty records found."
							}) }) : filteredRows.map((w) => {
								const sub = preferences[w.facultyId];
								const hasPrefs = sub && sub.preferences.length > 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-blue-50/40 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 font-semibold text-slate-900",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-slate-900",
												children: w.facultyName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-500 font-mono",
												children: [
													w.designation,
													" · ",
													w.facultyId
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-medium text-slate-700",
											children: w.programme
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 max-w-xs",
											children: hasPrefs ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap gap-1",
												children: [sub.preferences.slice(0, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-blue-50 border border-blue-200 text-blue-900 font-mono text-[10px]",
													title: p.courseTitle,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
														className: "text-blue-700 font-bold",
														children: ["#", p.rank]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.courseCode })]
												}, p.courseCode)), sub.preferences.length > 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "text-[10px] text-slate-400 font-semibold self-center",
													children: [
														"+",
														sub.preferences.length - 3,
														" more"
													]
												})]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-400 italic text-[11px]",
												children: "No preferences submitted"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
												status: w.preferencesStatus,
												size: "sm"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-bold text-slate-700",
											children: [w.defaultHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-bold text-blue-700",
											children: [w.allocatedHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-bold text-amber-700",
											children: [w.remainingHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-right",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												variant: "outline",
												onClick: () => setSelectedFacultyId(w.facultyId),
												className: "h-7 px-2.5 text-xs text-[#002147] border-blue-200 bg-white hover:bg-blue-50 gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VIEW" })]
											})
										})
									]
								}, w.facultyId);
							})
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedFacultyId,
				onOpenChange: (open) => !open && setSelectedFacultyId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [selectedFacultyWorkload?.facultyName, " — Preferences"] }), selectedFacultyWorkload && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, { status: selectedFacultyWorkload.preferencesStatus })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						selectedFacultyWorkload?.designation,
						" · ",
						selectedFacultyWorkload?.programme,
						" · Submitted:",
						" ",
						selectedSubmission?.submittedAt || "Pending"
					] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 bg-slate-50 border border-slate-200 rounded-lg flex justify-between items-center text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-400 uppercase font-bold",
									children: "Workload Status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold text-slate-800 text-sm",
									children: [
										selectedFacultyWorkload?.allocatedHours,
										"h / ",
										selectedFacultyWorkload?.defaultHours,
										"h (Allocated / Default)"
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, { status: selectedFacultyWorkload?.status || "UNDERLOADED" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold uppercase tracking-wider text-slate-500 text-[11px]",
									children: "Ranked Subject Preferences"
								}), !selectedSubmission || selectedSubmission.preferences.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "p-4 rounded bg-slate-100 text-slate-500 text-center",
									children: "This faculty has not selected any preferences yet."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "divide-y divide-slate-100 border rounded-lg overflow-hidden",
									children: selectedSubmission.preferences.map((pref) => {
										const course = courseList.find((c) => c.code === pref.courseCode);
										const catInfo = course ? COURSE_CATEGORIES[course.category] : null;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-3 flex items-center justify-between hover:bg-slate-50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "size-6 rounded-full bg-[#002147] text-white font-bold text-xs flex items-center justify-center shrink-0",
													children: pref.rank
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded text-[10px]",
														children: pref.courseCode
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "font-bold text-slate-900",
														children: pref.courseTitle
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-[11px] text-slate-500 mt-0.5",
													children: [
														catInfo?.name,
														" · Credits: ",
														pref.credits,
														" · Theory: ",
														pref.theoryHours,
														"h · Lab: ",
														pref.practicalHours,
														"h"
													]
												})] })]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-xs text-slate-700",
												children: ["Rank #", pref.rank]
											})]
										}, pref.courseCode);
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pt-2 flex justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => setSelectedFacultyId(null),
									className: "text-xs",
									children: "Close View"
								})
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminPreferencesReviewPage as component };
