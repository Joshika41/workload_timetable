//#region node_modules/.nitro/vite/services/ssr/assets/workload-types-BTjWZ-Y7.js
var COURSE_CATEGORIES = {
	C: {
		code: "C",
		name: "Professional Core",
		badgeColor: "bg-blue-600 text-white",
		bgLight: "bg-blue-50/60",
		borderLight: "border-blue-200",
		textColor: "text-blue-700"
	},
	D: {
		code: "D",
		name: "Discipline Elective",
		badgeColor: "bg-indigo-600 text-white",
		bgLight: "bg-indigo-50/60",
		borderLight: "border-indigo-200",
		textColor: "text-indigo-700"
	},
	G: {
		code: "G",
		name: "Generic Elective",
		badgeColor: "bg-emerald-600 text-white",
		bgLight: "bg-emerald-50/60",
		borderLight: "border-emerald-200",
		textColor: "text-emerald-700"
	},
	S: {
		code: "S",
		name: "Skill Enhancement",
		badgeColor: "bg-amber-600 text-white",
		bgLight: "bg-amber-50/60",
		borderLight: "border-amber-200",
		textColor: "text-amber-700"
	},
	P: {
		code: "P",
		name: "Project / Internship",
		badgeColor: "bg-purple-600 text-white",
		bgLight: "bg-purple-50/60",
		borderLight: "border-purple-200",
		textColor: "text-purple-700"
	},
	AE: {
		code: "AE",
		name: "Ability Enhancement",
		badgeColor: "bg-rose-600 text-white",
		bgLight: "bg-rose-50/60",
		borderLight: "border-rose-200",
		textColor: "text-rose-700"
	}
};
//#endregion
export { COURSE_CATEGORIES as t };
