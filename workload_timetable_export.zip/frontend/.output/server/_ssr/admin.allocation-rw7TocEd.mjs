import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { $ as ArrowLeft, A as FileSpreadsheet, K as Building, Y as BookOpen, c as SlidersHorizontal, g as Plus, n as Users } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, s as apiClient, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as WorkloadStatusBadge } from "./WorkloadStatusBadge-BmjEjhsL.mjs";
import { t as exportCourseAllocationToExcel } from "./excel-export-BRKgErUs.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.allocation-rw7TocEd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var workloadApi = {
	getFacultyWorkloads: async () => {
		return (await apiClient.get("/workload/faculty")).data;
	},
	getClassMatrix: async (sectionId) => {
		return (await apiClient.get("/workload/class-matrix", { params: { section_id: sectionId } })).data;
	}
};
function FacultyInlineSelect({ alloc, type, disabled, getFacultyForCourseDropdown, facultyList, updateAllocation }) {
	const { preferred, remaining } = getFacultyForCourseDropdown(alloc.courseCode);
	const value = type === "main" ? alloc.mainFacultyId : alloc.asstFacultyId;
	const handleChange = (e) => {
		const selectedId = e.target.value || null;
		const fac = facultyList.find((f) => f.id === selectedId);
		const updated = { ...alloc };
		if (type === "main") {
			updated.mainFacultyId = selectedId;
			updated.mainFacultyName = fac?.name;
			updated.mainTheoryHours = alloc.theoryHours;
			updated.mainPracticalHours = alloc.practicalHours;
			updated.status = selectedId ? "ALLOCATED" : "UNALLOCATED";
		} else {
			updated.asstFacultyId = selectedId;
			updated.asstFacultyName = fac?.name;
			updated.asstTheoryHours = 0;
			updated.asstPracticalHours = alloc.practicalHours > 0 ? alloc.practicalHours : 0;
		}
		updateAllocation(updated);
		toast.success(`Assigned ${type === "main" ? "Main" : "Assistant"} Faculty for ${alloc.courseCode}`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value: value || "",
		onChange: handleChange,
		disabled,
		className: `w-full min-w-[140px] max-w-[200px] h-7 rounded border px-1 text-[11px] font-bold ${type === "main" ? "border-blue-300 bg-blue-50/50 text-blue-900" : "border-teal-300 bg-teal-50/50 text-teal-900"} disabled:opacity-50 disabled:bg-slate-100 disabled:border-slate-200 cursor-pointer`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "-- Select --"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
				label: "⭐ PREFERRED",
				children: preferred.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: p.faculty.id,
					children: [
						"⭐ ",
						p.faculty.name,
						" (",
						p.remainingHours,
						"h cap)"
					]
				}, p.faculty.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
				label: "OTHER ELIGIBLE",
				children: remaining.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: r.faculty.id,
					children: [
						r.faculty.name,
						" (",
						r.remainingHours,
						"h cap)"
					]
				}, r.faculty.id))
			})
		]
	});
}
function AdminAllocationPage() {
	const { allocations, facultyList, courseList, sectionList, preferences, allWorkloads, updateAllocation, createAllocation, deleteAllocation, getFacultyForCourseDropdown } = useWorkloadData();
	const [activeTab, setActiveTab] = (0, import_react.useState)("management");
	const [classMatrixData, setClassMatrixData] = (0, import_react.useState)([]);
	import("../_libs/@floating-ui/react-dom+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.u())).then(({ useEffect }) => {
		useEffect(() => {
			if (activeTab === "class-matrix") workloadApi.getClassMatrix(1).then((data) => setClassMatrixData(data)).catch(console.error);
		}, [activeTab]);
	});
	const [contextProgramme, setContextProgramme] = (0, import_react.useState)("MCA GEN AI");
	const [contextSemester, setContextSemester] = (0, import_react.useState)("I");
	const [contextSection, setContextSection] = (0, import_react.useState)("I MCA GEN AI A");
	const [finalizingAllocId, setFinalizingAllocId] = (0, import_react.useState)(null);
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [semesterFilter, setSemesterFilter] = (0, import_react.useState)("ALL");
	const [sectionFilter, setSectionFilter] = (0, import_react.useState)("ALL");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("ALL");
	const [selectedFacultyFilter, setSelectedFacultyFilter] = (0, import_react.useState)("ALL");
	const [otherFacultySearch, setOtherFacultySearch] = (0, import_react.useState)("");
	const [editingAlloc, setEditingAlloc] = (0, import_react.useState)(null);
	const [isNewAllocModalOpen, setIsNewAllocModalOpen] = (0, import_react.useState)(false);
	const [newCourseCode, setNewCourseCode] = (0, import_react.useState)(courseList[0]?.code || "PCA25C01J");
	const [newSection, setNewSection] = (0, import_react.useState)(sectionList[0]?.name || "I MCA GEN AI A");
	const [newStudents, setNewStudents] = (0, import_react.useState)(55);
	const [newTheoryHours, setNewTheoryHours] = (0, import_react.useState)(3);
	const [newPracticalHours, setNewPracticalHours] = (0, import_react.useState)(2);
	const [newMainFacultyId, setNewMainFacultyId] = (0, import_react.useState)("");
	const [newAsstFacultyId, setNewAsstFacultyId] = (0, import_react.useState)("");
	const targetAlloc = allocations.find((a) => a.id === finalizingAllocId) || allocations[0];
	const [selectedMainId, setSelectedMainId] = (0, import_react.useState)(targetAlloc?.mainFacultyId || null);
	const [selectedAsstId, setSelectedAsstId] = (0, import_react.useState)(targetAlloc?.asstFacultyId || null);
	const [mainTh, setMainTh] = (0, import_react.useState)(targetAlloc?.mainTheoryHours ?? targetAlloc?.theoryHours ?? 3);
	const [mainPr, setMainPr] = (0, import_react.useState)(targetAlloc?.mainPracticalHours ?? targetAlloc?.practicalHours ?? 2);
	const [asstTh, setAsstTh] = (0, import_react.useState)(targetAlloc?.asstTheoryHours ?? 0);
	const [asstPr, setAsstPr] = (0, import_react.useState)(targetAlloc?.asstPracticalHours ?? (targetAlloc?.practicalHours ? 2 : 0));
	const filteredAllocations = allocations.filter((alloc) => {
		const matchesSearch = alloc.courseCode.toLowerCase().includes(searchTerm.toLowerCase()) || alloc.courseTitle.toLowerCase().includes(searchTerm.toLowerCase()) || alloc.mainFacultyName && alloc.mainFacultyName.toLowerCase().includes(searchTerm.toLowerCase()) || alloc.asstFacultyName && alloc.asstFacultyName.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesProg = programmeFilter === "ALL" || alloc.programme === programmeFilter;
		const matchesSem = semesterFilter === "ALL" || alloc.semester === semesterFilter;
		const matchesSec = sectionFilter === "ALL" || alloc.section === sectionFilter;
		const matchesStatus = statusFilter === "ALL" || statusFilter === "ALLOCATED" && alloc.mainFacultyId !== null || statusFilter === "UNALLOCATED" && alloc.mainFacultyId === null;
		const matchesFaculty = selectedFacultyFilter === "ALL" || alloc.mainFacultyId === selectedFacultyFilter || alloc.asstFacultyId === selectedFacultyFilter;
		return matchesSearch && matchesProg && matchesSem && matchesSec && matchesStatus && matchesFaculty;
	});
	const handleExport = () => {
		exportCourseAllocationToExcel(allocations);
		toast.success("Course allocation spreadsheet exported successfully!");
	};
	const handleCreateNewAllocation = () => {
		const course = courseList.find((c) => c.code === newCourseCode);
		const mainFac = facultyList.find((f) => f.id === newMainFacultyId);
		const asstFac = facultyList.find((f) => f.id === newAsstFacultyId);
		const newAlloc = {
			id: `ALLOC_${Date.now()}`,
			courseCode: newCourseCode,
			courseTitle: course?.title || newCourseCode,
			programme: course?.programme || "MCA GEN AI",
			semester: course?.semester || "I",
			section: newSection,
			studentCount: newStudents,
			theoryHours: newTheoryHours,
			practicalHours: newPracticalHours,
			labBatches: newPracticalHours > 0 ? 2 : 0,
			mainFacultyId: newMainFacultyId || null,
			mainFacultyName: mainFac?.name,
			asstFacultyId: newAsstFacultyId || null,
			asstFacultyName: asstFac?.name,
			totalHours: newTheoryHours + newPracticalHours,
			status: newMainFacultyId ? "ALLOCATED" : "UNALLOCATED"
		};
		createAllocation(newAlloc);
		toast.success(`Created allocation for ${newCourseCode} (${newSection})`);
		setIsNewAllocModalOpen(false);
	};
	const { preferred, remaining } = getFacultyForCourseDropdown(targetAlloc?.courseCode || "PCA25C01J");
	remaining.filter((item) => item.faculty.name.toLowerCase().includes(otherFacultySearch.toLowerCase()) || item.faculty.designation.toLowerCase().includes(otherFacultySearch.toLowerCase()));
	(targetAlloc?.theoryHours || 0) + (targetAlloc?.practicalHours || 0);
	(selectedMainId ? mainTh : 0) + (selectedAsstId ? asstTh : 0) + ((selectedMainId ? mainPr : 0) + (selectedAsstId ? asstPr : 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "HOD Subject Allocation & Finalization Portal",
		subtitle: "Configure main/assistant faculty, credited theory/lab hours, and class-wise curriculum allocations",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => window.history.back(),
					className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: activeTab === "management" ? "default" : "outline",
					onClick: () => setActiveTab("management"),
					className: `h-8 gap-1.5 text-xs ${activeTab === "management" ? "bg-[#002147] text-white" : "bg-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subject Allocations List" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: activeTab === "class-matrix" ? "default" : "outline",
					onClick: () => setActiveTab("class-matrix"),
					className: `h-8 gap-1.5 text-xs ${activeTab === "class-matrix" ? "bg-[#002147] text-white" : "bg-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Class-Wise Matrix" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: handleExport,
					className: "h-8 gap-1.5 text-xs border-slate-300 bg-white hover:bg-slate-100 text-slate-800",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-3.5 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Export Excel" })]
				})
			]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-blue-900/40 bg-[#002147] text-white p-4 shadow-md space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-blue-800/80 pb-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "size-4 text-teal-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs font-bold uppercase tracking-wider text-white",
								children: "Academic Context Selector"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] bg-teal-500/20 text-teal-300 border border-teal-400/30 px-2 py-0.5 rounded font-mono",
								children: "ODD Semester 2026-2027"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-blue-200",
						children: "Selected Context Scope Controls Displayed Subjects & Allocations"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-[10px] font-bold text-blue-200 uppercase mb-1",
							children: "Academic Year"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 rounded bg-white/10 border border-white/20 px-2.5 flex items-center font-bold text-white",
							children: "2026–2027"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-[10px] font-bold text-blue-200 uppercase mb-1",
							children: "Semester"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 rounded bg-white/10 border border-white/20 px-2.5 flex items-center font-bold text-teal-300",
							children: "ODD SEMESTER"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-[10px] font-bold text-blue-200 uppercase mb-1",
							children: "Programme"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: contextProgramme,
							onChange: (e) => setContextProgramme(e.target.value),
							className: "w-full h-8 rounded bg-blue-950 border border-blue-400/40 px-2 font-bold text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "MCA GEN AI",
								children: "MCA GEN AI"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "MCA",
								children: "MCA"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-[10px] font-bold text-blue-200 uppercase mb-1",
							children: "Semester / Year"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: contextSemester,
							onChange: (e) => setContextSemester(e.target.value),
							className: "w-full h-8 rounded bg-blue-950 border border-blue-400/40 px-2 font-bold text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "I",
								children: "I Year (Semester I)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "III",
								children: "II Year (Semester III)"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-[10px] font-bold text-blue-200 uppercase mb-1",
							children: "Section"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: contextSection,
							onChange: (e) => setContextSection(e.target.value),
							className: "w-full h-8 rounded bg-blue-950 border border-blue-400/40 px-2 font-bold text-white",
							children: sectionList.map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: sec.name,
								children: sec.name
							}, sec.id))
						})] })
					]
				})]
			}),
			activeTab === "management" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-[#002147]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-900",
								children: "Faculty Workload Capacity Tracker"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] text-slate-500 font-mono",
							children: "Click any faculty to filter their assignments"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2.5 overflow-x-auto pb-2 scrollbar-thin",
						children: allWorkloads.map((w) => {
							const isSelected = selectedFacultyFilter === w.facultyId;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								onClick: () => setSelectedFacultyFilter(isSelected ? "ALL" : w.facultyId),
								className: `shrink-0 w-44 rounded-lg p-2.5 cursor-pointer border transition-all ${isSelected ? "border-[#002147] bg-blue-50 ring-2 ring-[#002147]/20 shadow-sm" : "border-slate-200 bg-slate-50/70 hover:bg-white hover:border-slate-300"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-bold text-xs text-slate-900 truncate",
											title: w.facultyName,
											children: w.facultyName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
											status: w.status,
											size: "sm"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-slate-500 truncate",
										children: w.designation
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 pt-1 border-t border-slate-200 flex justify-between text-[11px] font-mono",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Target: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [w.defaultHours, "h"] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-blue-700 font-bold",
											children: [
												"Total: ",
												w.allocatedHours,
												"h"
											]
										})]
									})
								]
							}, w.facultyId);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row items-start md:items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-bold text-slate-800 uppercase tracking-wider",
							children: "Subject Allocation Management"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-slate-500",
							children: [
								"Select any subject and click ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-blue-800",
									children: "[ Finalize ]"
								}),
								" to perform detailed faculty mapping."
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								onClick: () => setIsNewAllocModalOpen(true),
								className: "h-8 gap-1.5 text-xs bg-[#002147] text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Add New Offering" })]
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-xs text-left border-collapse min-w-[1000px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5",
										children: "Subject Code"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5",
										children: "Subject Title"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5",
										children: "Programme & Section"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5 text-center",
										children: "L (Th)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5 text-center",
										children: "P (Lab)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5 text-center",
										children: "Total Req"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5",
										children: "Main Faculty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5",
										children: "Assistant / IN-2"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3.5 py-2.5 text-center",
										children: "Status"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-slate-200",
								children: filteredAllocations.map((alloc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-blue-50/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 font-mono font-bold text-blue-700",
											children: alloc.courseCode
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 font-semibold text-slate-900 max-w-xs truncate",
											title: alloc.courseTitle,
											children: alloc.courseTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3.5 py-2.5 font-medium text-slate-700 font-mono",
											children: [
												alloc.section,
												" (",
												alloc.programme,
												")"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3.5 py-2.5 text-center font-mono text-slate-800",
											children: [alloc.theoryHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3.5 py-2.5 text-center font-mono text-slate-800",
											children: [alloc.practicalHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3.5 py-2.5 text-center font-mono font-bold text-slate-900 bg-slate-50",
											children: [alloc.totalHours, "h"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 font-semibold text-slate-900",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacultyInlineSelect, {
												alloc,
												type: "main",
												facultyList,
												updateAllocation,
												getFacultyForCourseDropdown
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 text-slate-600",
											children: alloc.practicalHours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacultyInlineSelect, {
												alloc,
												type: "asst",
												facultyList,
												updateAllocation,
												getFacultyForCourseDropdown
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-slate-400 italic text-[11px] px-2 block text-center border border-dashed rounded bg-slate-50 py-1",
												children: "No Lab Component"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3.5 py-2.5 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-2 py-0.5 rounded text-[10px] font-bold ${alloc.status === "FINALIZED" || alloc.status === "RECONCILED" ? "bg-emerald-100 text-emerald-800 border border-emerald-300" : alloc.mainFacultyId ? "bg-blue-100 text-blue-800 border border-blue-300" : "bg-rose-100 text-rose-800 border border-rose-300"}`,
												children: alloc.status
											})
										})
									]
								}, alloc.id))
							})]
						})
					})]
				})]
			}),
			activeTab === "class-matrix" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 bg-white p-6 shadow-sm space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center space-y-1 border-b pb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-bold text-sm text-slate-800 tracking-wider uppercase",
								children: "SRM INSTITUTE OF SCIENCE AND TECHNOLOGY"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-extrabold text-base text-[#002147]",
								children: "CLASS-WISE CURRICULUM ALLOCATION MATRIX"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-slate-500 font-medium",
								children: [
									contextProgramme,
									" · Semester ",
									contextSemester,
									" · Digital Replica of Official Allocation Master Sheet"
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-xs text-left border border-slate-300 border-collapse min-w-[950px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-slate-100 text-[11px] font-bold text-slate-800 border-b border-slate-300 uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2 text-center w-12",
										children: "S.No"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2",
										children: "Subject Code"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2",
										children: "Subject Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2 text-center",
										children: "L (Th)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2 text-center",
										children: "P (Lab)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2 text-center",
										children: "Total"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2",
										children: "Main Faculty"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2",
										children: "Assistant Faculty (IN2 Lab)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "border border-slate-300 px-3 py-2 text-center",
										children: "Status"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-slate-200",
								children: classMatrixData.map((alloc, idx) => {
									const hasLab = alloc.practical_hours > 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "hover:bg-slate-50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 text-center font-bold text-slate-700",
												children: idx + 1
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 font-mono font-bold text-blue-700",
												children: alloc.course_code
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 font-semibold text-slate-900",
												children: alloc.course_title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 text-center font-mono font-semibold text-slate-800",
												children: alloc.theory_hours
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 text-center font-mono font-semibold text-slate-800",
												children: alloc.practical_hours
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "border border-slate-300 px-3 py-2 text-center font-mono font-bold text-blue-900 bg-blue-50/50",
												children: [alloc.total_hours, " hrs"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-slate-900",
													children: alloc.main_faculty_name || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-rose-600 italic",
														children: "Unassigned"
													})
												})
											}),
											hasLab ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 text-slate-700 font-medium",
												children: alloc.asst_faculty_name || /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-amber-600 italic",
													children: "Pending Asst"
												})
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-900 bg-[#0f172a] text-slate-400 font-mono text-[10px] text-center uppercase tracking-wider py-2",
												children: "— NO LAB / NO ASST —"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "border border-slate-300 px-3 py-2 text-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `px-2 py-0.5 rounded text-[10px] font-bold ${alloc.status === "FINALIZED" ? "bg-emerald-100 text-emerald-800" : alloc.main_faculty_name ? "bg-blue-100 text-blue-800" : "bg-rose-100 text-rose-800"}`,
													children: alloc.status
												})
											})
										]
									}, alloc.course_code);
								})
							})]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isNewAllocModalOpen,
				onOpenChange: setIsNewAllocModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4 text-teal-600" }), "Add Class Allocation"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Create a new course offering and assign faculty members with live deduction tracking." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Select Course"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: newCourseCode,
								onChange: (e) => {
									setNewCourseCode(e.target.value);
									const c = courseList.find((x) => x.code === e.target.value);
									if (c) {
										setNewTheoryHours(c.theoryHours_L);
										setNewPracticalHours(c.practicalHours_P);
									}
								},
								className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
								children: courseList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: c.code,
									children: [
										c.code,
										" - ",
										c.title,
										" (",
										c.programme,
										" Sem ",
										c.semester,
										")"
									]
								}, c.code))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Section"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: newSection,
									onChange: (e) => setNewSection(e.target.value),
									className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
									children: sectionList.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: s.name,
										children: s.name
									}, s.id))
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Students"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: newStudents,
									onChange: (e) => setNewStudents(Number(e.target.value)),
									className: "h-8 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Theory (Hrs)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: newTheoryHours,
									onChange: (e) => setNewTheoryHours(Number(e.target.value)),
									className: "h-8 text-xs"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-[11px] font-bold text-slate-600 mb-1",
									children: "Practical (Hrs)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "number",
									value: newPracticalHours,
									onChange: (e) => setNewPracticalHours(Number(e.target.value)),
									className: "h-8 text-xs"
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-600 mb-1",
								children: "Main Faculty (Theory & Lab)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: newMainFacultyId,
								onChange: (e) => setNewMainFacultyId(e.target.value),
								className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "-- Select Main Faculty --"
								}), facultyList.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: f.id,
									children: f.name
								}, f.id))]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setIsNewAllocModalOpen(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: handleCreateNewAllocation,
									className: "bg-[#002147] text-white",
									children: "Create Allocation"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminAllocationPage as component };
