import { createFileRoute, useNavigate } from '@tanstack/react-router';
import { WorkloadShell } from '@/components/WorkloadShell';
import { useWorkspace } from '@/context/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { BookOpen, ArrowLeft } from 'lucide-react';

export const Route = createFileRoute('/faculty/subjects')({
  component: FacultySubjectsPage,
});

function FacultySubjectsPage() {
  const navigate = useNavigate();
  const { activeWorkspace } = useWorkspace();

  if (!activeWorkspace) return null;

  return (
    <WorkloadShell
      role="faculty"
      title="My Subjects"
      subtitle="Your officially assigned subjects and roles"
      actions={
        <Button
          size="sm"
          variant="outline"
          onClick={() => window.history.back()}
          className="h-8 gap-1 text-xs border-slate-200 bg-white"
        >
          <ArrowLeft className="size-3.5" /> Back
        </Button>
      }
    >
      <div className="flex flex-col items-center justify-center max-w-2xl mx-auto mt-16 text-center bg-white p-12 rounded-2xl shadow-sm border border-slate-200">
        <div className="size-20 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center mb-6">
          <BookOpen className="size-10" />
        </div>
        
        <h2 className="text-2xl font-extrabold text-slate-900 mb-4">Official Subject Allocations</h2>
        <p className="text-slate-600 text-sm mb-8 max-w-md mx-auto">
          Your subjects will appear here once the HOD finalizes the allocations for this academic context.
        </p>

        <Button 
          onClick={() => navigate({ to: '/faculty/dashboard' })}
          className="h-10 px-8 bg-[#002147] hover:bg-[#001833] text-white font-bold"
        >
          Back to Dashboard
        </Button>
      </div>
    </WorkloadShell>
  );
}
