import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { Building2, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { academicApi } from '@/api/academicApi';
import { DepartmentResponse } from '@/types/academic';

export default function Login() {
  const navigate = useNavigate();
  const { user, demoSignIn, isLoading: isAuthLoading } = useAuth();
  
  const [departments, setDepartments] = useState<DepartmentResponse[]>([]);
  const [selectedDeptId, setSelectedDeptId] = useState<number | undefined>(undefined);
  const [selectedProgrammeType, setSelectedProgrammeType] = useState<string>('');
  const [selectedSemesterType, setSelectedSemesterType] = useState<'ODD' | 'EVEN'>('ODD');
  const [isLoadingDepts, setIsLoadingDepts] = useState(true);

  useEffect(() => {
    academicApi.getDepartments().then(data => {
      setDepartments(data);
      if (data.length > 0) {
        const mca = data.find(d => d.name.includes('MCA'));
        const defaultDept = mca || data[0];
        setSelectedDeptId(defaultDept.id);
      }
      setIsLoadingDepts(false);
    }).catch(err => {
      console.error(err);
      setIsLoadingDepts(false);
    });
  }, []);

  const selectedDepartment = departments.find(d => d.id === selectedDeptId);
  const uniqueProgrammeTypes = selectedDepartment 
    ? Array.from(new Set(selectedDepartment.programmes.map(p => p.programme_type))) 
    : [];

  useEffect(() => {
    if (uniqueProgrammeTypes.length > 0 && !uniqueProgrammeTypes.includes(selectedProgrammeType)) {
      setSelectedProgrammeType(uniqueProgrammeTypes[0]);
    }
  }, [uniqueProgrammeTypes, selectedProgrammeType]);

  useEffect(() => {
    if (!isAuthLoading && user) {
      if (user.role === 'HOD' || user.role === 'ERP_COORDINATOR') {
        navigate('/admin', { replace: true });
      } else if (user.role === 'FACULTY') {
        navigate('/faculty', { replace: true });
      }
    }
  }, [user, isAuthLoading, navigate]);

  const handleRoleSelect = async (role: 'HOD' | 'FACULTY') => {
    if (!selectedDeptId || !selectedProgrammeType) return;
    try {
      await demoSignIn(role, selectedDeptId, {
        programmeType: selectedProgrammeType,
        semesterType: selectedSemesterType
      });
    } catch (e) {
      console.error(e);
    }
  };

  if (isAuthLoading) return null;

  return (
    <div 
      className="min-h-screen relative flex items-center justify-center p-4 bg-slate-900"
      style={{
        backgroundImage: 'url(/srm-bg.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 bg-[#001433]/70 backdrop-blur-sm z-0"></div>

      <div className="relative z-10 w-full max-w-[1000px] flex flex-col md:flex-row overflow-hidden rounded-2xl shadow-2xl shadow-[#000000]/50 border border-white/10 bg-white">
        
        {/* Left Side: Branding */}
        <div className="w-full md:w-5/12 p-10 flex flex-col items-center justify-center bg-[#002147] border-r border-white/10 text-center">
          <div className="size-24 rounded-2xl bg-white p-2 shadow-lg mb-6 overflow-hidden">
            <img 
              src="/srm-logo.jpeg" 
              alt="SRM Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white mb-2">
            SRM University
          </h1>
          <p className="text-sm font-medium text-blue-200">
            Workload and Timetable Portal
          </p>
          <div className="mt-8 px-4 py-2 bg-blue-900/40 rounded-full border border-blue-400/20 text-xs font-bold text-blue-300 uppercase tracking-widest">
            Phase A Demo
          </div>
        </div>

        {/* Right Side: Context Selection */}
        <div className="w-full md:w-7/12 p-8 md:p-12 flex flex-col justify-center bg-white">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Context Selection</h2>
            <p className="text-slate-500 text-sm mt-1">
              Select your department and workspace context before entering.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 mb-8">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">1. Department</label>
              <select 
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#002147] font-medium"
                value={selectedDeptId || ''}
                onChange={e => setSelectedDeptId(Number(e.target.value))}
                disabled={isLoadingDepts}
              >
                {isLoadingDepts ? <option>Loading...</option> : null}
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">2. Program Type</label>
                <select 
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#002147] font-medium"
                  value={selectedProgrammeType}
                  onChange={e => setSelectedProgrammeType(e.target.value)}
                  disabled={uniqueProgrammeTypes.length === 0}
                >
                  {uniqueProgrammeTypes.map(pt => (
                    <option key={pt} value={pt}>{pt}</option>
                  ))}
                  {uniqueProgrammeTypes.length === 0 && <option value="">No programs</option>}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">3. Semester Type</label>
                <select 
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#002147] font-medium"
                  value={selectedSemesterType}
                  onChange={e => setSelectedSemesterType(e.target.value as 'ODD'|'EVEN')}
                >
                  <option value="ODD">Odd Semester</option>
                  <option value="EVEN">Even Semester</option>
                </select>
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-100">
            <label className="block text-sm font-bold text-slate-900 mb-4">4. Enter Workspace As:</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => handleRoleSelect('HOD')}
                disabled={!selectedDeptId || !selectedProgrammeType}
                className="group relative flex flex-col items-center justify-center p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-[#002147] hover:bg-blue-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="size-10 mb-2 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center group-hover:bg-[#002147] group-hover:text-white transition-colors">
                  <Building2 className="size-5" />
                </div>
                <p className="text-sm font-bold text-slate-900 group-hover:text-[#002147]">HOD</p>
              </button>

              <button
                onClick={() => handleRoleSelect('FACULTY')}
                disabled={!selectedDeptId || !selectedProgrammeType}
                className="group relative flex flex-col items-center justify-center p-4 rounded-xl border-2 border-slate-200 bg-white hover:border-[#002147] hover:bg-blue-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="size-10 mb-2 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-[#002147] group-hover:text-white transition-colors">
                  <Users className="size-5" />
                </div>
                <p className="text-sm font-bold text-slate-900 group-hover:text-[#002147]">Faculty</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
