//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B-YkBupd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/__root.tsx",
		children: [
			"/",
			"/admin/allocation",
			"/admin/audit",
			"/admin/faculty",
			"/admin/preferences",
			"/admin/setup",
			"/admin/timetables",
			"/admin/workload",
			"/dean/timetables",
			"/faculty/dashboard",
			"/faculty/timetable",
			"/admin/",
			"/dean/",
			"/faculty/"
		],
		preloads: [
			"/assets/index-Cp8oBMXl.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/button-CBtzkYNI.js",
			"/assets/link-CY6S0354.js",
			"/assets/useNavigate-CWacDeMi.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cp8oBMXl.js"
		} }]
	},
	"/": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-OxOVgJGL.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/graduation-cap-r3cHAjJa.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/admin/allocation": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.allocation.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.allocation-BwP3lMWf.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/WorkloadStatusBadge-CF5sWcdA.js",
			"/assets/x-CZhX95FD.js",
			"/assets/file-spreadsheet-CvfURi7Y.js",
			"/assets/plus-CwhMPfYQ.js",
			"/assets/excel-export-BHehY5DQ.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/admin/audit": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.audit.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.audit-6J9X5fX9.js",
			"/assets/portal-nav-DWH8XEqU.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/clock-lyUEcHCY.js",
			"/assets/search-CoRx-a96.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/admin/faculty": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.faculty.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.faculty-DscEyOue.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/x-CZhX95FD.js",
			"/assets/plus-CwhMPfYQ.js",
			"/assets/search-CoRx-a96.js",
			"/assets/trash-2-BZH7FTDs.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/admin/preferences": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.preferences.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.preferences-BgqdIP9j.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/WorkloadStatusBadge-CF5sWcdA.js",
			"/assets/x-CZhX95FD.js",
			"/assets/eye-WXzu2m69.js",
			"/assets/search-CoRx-a96.js",
			"/assets/input-DRvSsMoU.js",
			"/assets/workload-types-Bp4Jozc4.js"
		]
	},
	"/admin/setup": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.setup.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.setup-kzliCgtd.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/graduation-cap-r3cHAjJa.js",
			"/assets/plus-CwhMPfYQ.js",
			"/assets/search-CoRx-a96.js",
			"/assets/input-DRvSsMoU.js",
			"/assets/workload-types-Bp4Jozc4.js"
		]
	},
	"/admin/timetables": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.timetables.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.timetables-DlmNEDDA.js",
			"/assets/portal-nav-DWH8XEqU.js",
			"/assets/useQuery-CmdOaZNd.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/TimetableGrid-BGPIQld0.js"
		]
	},
	"/admin/workload": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.workload.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.workload--7yglz1w.js",
			"/assets/arrow-left-CiuxCXcY.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/WorkloadStatusBadge-CF5sWcdA.js",
			"/assets/x-CZhX95FD.js",
			"/assets/eye-WXzu2m69.js",
			"/assets/plus-CwhMPfYQ.js",
			"/assets/search-CoRx-a96.js",
			"/assets/trash-2-BZH7FTDs.js",
			"/assets/excel-export-BHehY5DQ.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/dean/timetables": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/dean.timetables.tsx",
		children: void 0,
		preloads: [
			"/assets/dean.timetables-Cqd5tfeU.js",
			"/assets/portal-nav-DWH8XEqU.js",
			"/assets/useQuery-CmdOaZNd.js",
			"/assets/TimetableGrid-BGPIQld0.js"
		]
	},
	"/faculty/dashboard": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/faculty.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/faculty.dashboard-D0eESK6U.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/WorkloadStatusBadge-CF5sWcdA.js",
			"/assets/graduation-cap-r3cHAjJa.js",
			"/assets/plus-CwhMPfYQ.js",
			"/assets/search-CoRx-a96.js",
			"/assets/trash-2-BZH7FTDs.js",
			"/assets/input-DRvSsMoU.js",
			"/assets/workload-types-Bp4Jozc4.js"
		]
	},
	"/faculty/timetable": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/faculty.timetable.tsx",
		children: void 0,
		preloads: [
			"/assets/faculty.timetable-_0psoZmO.js",
			"/assets/portal-nav-DWH8XEqU.js",
			"/assets/useQuery-CmdOaZNd.js",
			"/assets/TimetableGrid-BGPIQld0.js"
		]
	},
	"/admin/": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-__HOVrOh.js",
			"/assets/WorkloadShell-DCp76Uzi.js",
			"/assets/dist-BfK_8mEH.js",
			"/assets/WorkloadStatusBadge-CF5sWcdA.js",
			"/assets/x-CZhX95FD.js",
			"/assets/clock-lyUEcHCY.js",
			"/assets/eye-WXzu2m69.js",
			"/assets/file-spreadsheet-CvfURi7Y.js",
			"/assets/search-CoRx-a96.js",
			"/assets/excel-export-BHehY5DQ.js",
			"/assets/input-DRvSsMoU.js"
		]
	},
	"/dean/": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/dean.index.tsx",
		children: void 0,
		preloads: [
			"/assets/dean.index-DY9HrZZs.js",
			"/assets/portal-nav-DWH8XEqU.js",
			"/assets/useQuery-CmdOaZNd.js",
			"/assets/file-spreadsheet-CvfURi7Y.js"
		]
	},
	"/faculty/": {
		filePath: "D:/Joshi/workload_timetable/frontend/src/routes/faculty.index.tsx",
		children: void 0,
		preloads: ["/assets/faculty.index-YuA77UDp.js"]
	}
} });
//#endregion
export { tsrStartManifest };
