import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { academicApi } from '@/api/index';
import { toast } from 'sonner';

interface Department { id: number; name: string; programmes: Programme[]; }
interface Programme { id: number; name: string; programme_type: string; }

type Step = 'dept' | 'programme' | 'semtype' | 'role';

export default function ContextSelection() {
  const { session, isLoading: authLoading, demoLogin } = useAuth();
  const navigate = useNavigate();

  const [departments, setDepartments] = useState<Department[]>([]);
  const [facultyList, setFacultyList] = useState<any[]>([]);
  const [isLoadingDepts, setIsLoadingDepts] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [step, setStep] = useState<Step>('dept');
  const [selectedDept, setSelectedDept] = useState<Department | null>(null);
  const [selectedProg, setSelectedProg] = useState<Programme | null>(null);
  const [selectedSemType, setSelectedSemType] = useState<'ODD' | 'EVEN'>('ODD');
  const [selectedRole, setSelectedRole] = useState<'HOD' | 'FACULTY' | null>(null);
  const [selectedFacultyId, setSelectedFacultyId] = useState<number | undefined>(undefined);

  useEffect(() => {
    if (!authLoading && session) {
      if (session.role === 'HOD' || session.role === 'ERP_COORDINATOR') navigate('/hod');
      else navigate('/faculty');
    }
  }, [session, authLoading, navigate]);

  useEffect(() => {
    academicApi.getDepartments()
      .then(data => { setDepartments(data); setIsLoadingDepts(false); })
      .catch(() => { toast.error('Failed to load departments. Please check the backend is running.'); setIsLoadingDepts(false); });
  }, []);

  useEffect(() => {
    if (selectedDept && step === 'role') {
      academicApi.getFacultyList(selectedDept.id)
        .then(setFacultyList)
        .catch(() => setFacultyList([]));
    }
  }, [selectedDept, step]);

  const allProgrammes = selectedDept?.programmes || [];
  const ugProgs = allProgrammes.filter(p => p.programme_type === 'UG' || p.programme_type === 'Undergraduate');
  const pgProgs = allProgrammes.filter(p => p.programme_type === 'PG' || p.programme_type === 'Postgraduate');

  const handleEnter = async (role: 'HOD' | 'FACULTY') => {
    if (!selectedDept || !selectedProg) return;

    setIsSubmitting(true);
    try {
      await demoLogin({
        role,
        departmentId: selectedDept.id,
        departmentName: selectedDept.name,
        programmeId: selectedProg.id,
        programmeName: selectedProg.name,
        programmeType: selectedProg.programme_type,
        semesterType: selectedSemType,
        facultyId: role === 'FACULTY' ? selectedFacultyId : undefined,
      });
    } catch {
      // Error shown by demoLogin
    } finally {
      setIsSubmitting(false);
    }
  };

  if (authLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-[#001530]">
      <div style={{ color: 'white', fontSize: '16px', fontWeight: 600 }}>Loading...</div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
      style={{
        background: 'linear-gradient(135deg, #001530 0%, #002147 50%, #003580 100%)',
        minHeight: '100vh',
      }}
    >
      {/* Background Pattern */}
      <div style={{
        position: 'fixed', inset: 0, zIndex: 0,
        backgroundImage: 'radial-gradient(circle at 20% 80%, rgba(201,168,76,0.07) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(0,71,171,0.15) 0%, transparent 50%)',
      }} />

      <div style={{
        position: 'relative', zIndex: 1, width: '100%', maxWidth: '920px', minHeight: '640px',
        display: 'flex', gap: 0, background: 'white',
        borderRadius: '24px', overflow: 'hidden',
        boxShadow: '0 30px 80px rgba(0,0,0,0.4), 0 8px 24px rgba(0,0,0,0.2)',
      }}>

        {/* LEFT PANEL — Branding */}
        <div style={{
          width: '360px', flexShrink: 0,
          background: 'linear-gradient(160deg, #002147 0%, #003580 60%, #001a36 100%)',
          padding: '48px 36px',
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
          color: 'white', position: 'relative', overflow: 'hidden',
        }}>
          {/* Decorative circles */}
          <div style={{ position: 'absolute', width: 300, height: 300, borderRadius: '50%', background: 'rgba(201,168,76,0.06)', top: -100, right: -80 }} />
          <div style={{ position: 'absolute', width: 200, height: 200, borderRadius: '50%', background: 'rgba(255,255,255,0.03)', bottom: -60, left: -40 }} />

          <div style={{ position: 'relative', zIndex: 1 }}>
            <div style={{
              width: 72, height: 72, background: 'white', borderRadius: '16px',
              padding: '8px', marginBottom: '24px', overflow: 'hidden',
              boxShadow: '0 4px 16px rgba(0,0,0,0.3)',
            }}>
              <img src="/srm-logo.jpeg" alt="SRM Logo" style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>

            <h1 style={{ fontSize: '22px', fontWeight: 900, color: 'white', marginBottom: '8px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              SRM Ramapuram
            </h1>
            <p style={{ fontSize: '13px', color: 'rgba(255,255,255,0.55)', lineHeight: 1.6, marginBottom: '32px' }}>
              Faculty of Science and Humanities<br />
              Workload & Timetable Portal
            </p>

            <div style={{
              background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.35)',
              borderRadius: '12px', padding: '16px 18px',
            }}>
              <p style={{ fontSize: '11px', fontWeight: 700, color: '#E8C96B', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: '6px' }}>
                Phase 1 — Workload
              </p>
              <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.6)', lineHeight: 1.6 }}>
                Subject preferences, workload allocation, and class-wise matrix generation.
              </p>
            </div>
          </div>

          <div style={{ position: 'relative', zIndex: 1 }}>
            <p style={{ fontSize: '11px', color: 'rgba(255,255,255,0.3)' }}>
              Academic Year: 2026–27 · Demo Mode
            </p>
          </div>
        </div>

        {/* RIGHT PANEL — Context Selection */}
        <div style={{ flex: 1, padding: '48px 40px', overflowY: 'auto' }}>
          <h2 style={{ fontSize: '20px', fontWeight: 800, color: '#0F172A', marginBottom: '6px', fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            Context Selection
          </h2>
          <p style={{ fontSize: '13px', color: '#64748B', marginBottom: '32px' }}>
            Select your department, programme, and semester type to enter your workspace.
          </p>

          {/* Step 1: Department */}
          <div style={{ marginBottom: '22px' }}>
            <label className="form-label" style={{ marginBottom: '10px', display: 'block' }}>
              1. Department
            </label>
            {isLoadingDepts ? (
              <div className="skeleton skeleton-text" style={{ height: 46 }} />
            ) : (
              <select
                className="form-control"
                value={selectedDept?.id || ''}
                onChange={e => {
                  const d = departments.find(d => d.id === Number(e.target.value)) || null;
                  setSelectedDept(d);
                  setSelectedProg(null);
                  setStep('programme');
                }}
              >
                <option value="">— Select Department —</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            )}
          </div>

          {/* Step 2: Programme */}
          {selectedDept && (
            <div style={{ marginBottom: '22px' }} className="animate-slide-up">
              <label className="form-label" style={{ marginBottom: '10px', display: 'block' }}>
                2. Programme
              </label>
              {ugProgs.length > 0 && (
                <>
                  <p style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '8px' }}>
                    Undergraduate
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '12px' }}>
                    {ugProgs.map(p => (
                      <ProgOption key={p.id} prog={p} selected={selectedProg?.id === p.id}
                        onSelect={() => { setSelectedProg(p); setStep('semtype'); }} />
                    ))}
                  </div>
                </>
              )}
              {pgProgs.length > 0 && (
                <>
                  <p style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '8px' }}>
                    Postgraduate
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    {pgProgs.map(p => (
                      <ProgOption key={p.id} prog={p} selected={selectedProg?.id === p.id}
                        onSelect={() => { setSelectedProg(p); setStep('semtype'); }} />
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Step 3: Semester Type */}
          {selectedProg && (
            <div style={{ marginBottom: '22px' }} className="animate-slide-up">
              <label className="form-label" style={{ marginBottom: '10px', display: 'block' }}>
                3. Semester Type
              </label>
              <div style={{ display: 'flex', gap: '10px' }}>
                {(['ODD', 'EVEN'] as const).map(st => (
                  <button key={st} onClick={() => { setSelectedSemType(st); setStep('role'); }}
                    style={{
                      flex: 1, padding: '12px', borderRadius: '12px', cursor: 'pointer',
                      border: selectedSemType === st ? '2px solid #002147' : '2px solid #E2E8F0',
                      background: selectedSemType === st ? '#EFF6FF' : 'white',
                      color: selectedSemType === st ? '#002147' : '#475569',
                      fontWeight: 700, fontSize: '13px', transition: 'all 0.15s',
                      fontFamily: 'inherit',
                    }}>
                    <div style={{ fontSize: '16px', marginBottom: '4px' }}>{st === 'ODD' ? '📚' : '📖'}</div>
                    {st} Semester
                    <div style={{ fontSize: '11px', fontWeight: 500, marginTop: '2px', opacity: 0.7 }}>
                      {st === 'ODD'
                        ? (selectedProg.programme_type === 'PG' ? 'Sem 1, 3' : 'Sem 1, 3, 5, 7')
                        : (selectedProg.programme_type === 'PG' ? 'Sem 2, 4' : 'Sem 2, 4, 6, 8')}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Role */}
          {selectedProg && selectedSemType && (
            <div className="animate-slide-up">
              <label className="form-label" style={{ marginBottom: '10px', display: 'block' }}>
                4. Enter Workspace As
              </label>
              <div style={{ display: 'flex', gap: '12px', marginBottom: '16px' }}>
                <RoleCard
                  role="HOD"
                  icon="🏛️"
                  title="HOD"
                  description="Review preferences, allocate workload, finalize"
                  selected={selectedRole === 'HOD'}
                  onSelect={() => setSelectedRole('HOD')}
                />
                <RoleCard
                  role="FACULTY"
                  icon="👨‍🏫"
                  title="Faculty"
                  description="Submit subject preferences, view allocations"
                  selected={selectedRole === 'FACULTY'}
                  onSelect={() => setSelectedRole('FACULTY')}
                />
              </div>

              {/* Removed Faculty dropdown for seamless entry */}

              {/* Enter Button */}
              {selectedRole && (
                <button
                  className="btn btn-primary btn-lg animate-slide-up"
                  style={{ width: '100%' }}
                  disabled={isSubmitting}
                  onClick={() => handleEnter(selectedRole)}
                >
                  {isSubmitting ? 'Entering...' : `Enter as ${selectedRole} →`}
                </button>
              )}

              {/* Context Summary */}
              <div style={{
                marginTop: '20px', padding: '12px 16px',
                background: '#F8FAFC', borderRadius: '10px', border: '1px solid #E2E8F0',
              }}>
                <p style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: '8px' }}>
                  Your Context
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {selectedDept && <span className="chip chip-submitted">{selectedDept.name}</span>}
                  {selectedProg && <span className="chip chip-allocated">{selectedProg.name} ({selectedProg.programme_type})</span>}
                  {selectedSemType && <span className="chip chip-pending">{selectedSemType} Semesters</span>}
                  <span className="chip chip-not-started">AY 2026-27</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ProgOption({ prog, selected, onSelect }: { prog: Programme; selected: boolean; onSelect: () => void }) {
  return (
    <button onClick={onSelect} style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '10px 14px', borderRadius: '10px', cursor: 'pointer',
      border: selected ? '2px solid #002147' : '1.5px solid #E2E8F0',
      background: selected ? '#EFF6FF' : 'white',
      color: selected ? '#002147' : '#374151',
      fontWeight: 600, fontSize: '13px', transition: 'all 0.15s', textAlign: 'left',
      fontFamily: 'inherit', width: '100%',
    }}>
      <span>{prog.name}</span>
      {selected && <span style={{ fontSize: '16px' }}>✓</span>}
    </button>
  );
}

function RoleCard({ role, icon, title, description, selected, onSelect }: any) {
  return (
    <button onClick={onSelect} style={{
      flex: 1, padding: '16px', borderRadius: '12px', cursor: 'pointer', textAlign: 'center',
      border: selected ? '2px solid #002147' : '2px solid #E2E8F0',
      background: selected ? '#EFF6FF' : 'white',
      color: selected ? '#002147' : '#475569',
      transition: 'all 0.2s', fontFamily: 'inherit',
    }}>
      <div style={{ fontSize: '24px', marginBottom: '8px' }}>{icon}</div>
      <p style={{ fontWeight: 800, fontSize: '14px', marginBottom: '4px', color: selected ? '#002147' : '#1E293B' }}>{title}</p>
      <p style={{ fontSize: '11px', color: selected ? '#3B82F6' : '#94A3B8', lineHeight: 1.5 }}>{description}</p>
    </button>
  );
}
