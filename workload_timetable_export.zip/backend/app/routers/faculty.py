from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database.connection import get_db
from app.models.domain import User, FacultyProfile, Department
from app.auth.dependencies import get_current_user

router = APIRouter()

@router.get("")
def get_faculty_list(
    department_id: Optional[int] = Query(None),
    workspace_id: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Return faculty profiles, optionally filtered by department_id."""
    query = db.query(FacultyProfile).join(User, FacultyProfile.user_id == User.id)

    if department_id:
        query = query.filter(User.department_id == department_id)
    else:
        # Default: same dept as requester
        query = query.filter(User.department_id == current_user.department_id)

    profiles = query.all()
    result = []
    
    from app.models.domain import FacultyCycleState
    cycle_states = {}
    if workspace_id:
        states = db.query(FacultyCycleState).filter(FacultyCycleState.workspace_id == workspace_id).all()
        cycle_states = {s.faculty_id: s.state for s in states}

    for p in profiles:
        result.append({
            "id": p.id,
            "name": p.name,
            "erp_id": p.erp_id,
            "designation": p.designation,
            "user_id": p.user_id,
            "cycle_state": cycle_states.get(p.id, "PENDING")
        })
    return result

@router.post("/{faculty_id}/cycle-state")
def update_faculty_cycle_state(
    faculty_id: int,
    workspace_id: str,
    state: str,
    reason: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from app.models.domain import FacultyCycleState
    cycle_state = db.query(FacultyCycleState).filter(
        FacultyCycleState.workspace_id == workspace_id,
        FacultyCycleState.faculty_id == faculty_id
    ).first()
    
    if cycle_state:
        cycle_state.state = state
        cycle_state.reason = reason
    else:
        cycle_state = FacultyCycleState(
            workspace_id=workspace_id,
            faculty_id=faculty_id,
            state=state,
            reason=reason
        )
        db.add(cycle_state)
    db.commit()
    return {"message": "State updated"}
