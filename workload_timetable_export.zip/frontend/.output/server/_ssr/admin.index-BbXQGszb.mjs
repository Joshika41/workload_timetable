import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as FileSpreadsheet, P as Clock, c as SlidersHorizontal, d as Search, j as Eye, n as Users } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as WorkloadStatusBadge } from "./WorkloadStatusBadge-BmjEjhsL.mjs";
import { n as exportFacultyWorkloadToExcel } from "./excel-export-BRKgErUs.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-BbXQGszb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HodDashboardPage() {
	const navigate = useNavigate();
	const { facultyList, courseList, sectionList, allocations, allWorkloads, dashboardMetrics, updateFacultyDefaultHours } = useWorkloadData();
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("ALL");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [selectedFacultyId, setSelectedFacultyId] = (0, import_react.useState)(null);
	const selectedWorkload = allWorkloads.find((w) => w.facultyId === selectedFacultyId);
	const [editingDefaultHours, setEditingDefaultHours] = (0, import_react.useState)(null);
	const filteredWorkloads = allWorkloads.filter((w) => {
		const matchesSearch = w.facultyName.toLowerCase().includes(searchTerm.toLowerCase()) || w.designation.toLowerCase().includes(searchTerm.toLowerCase()) || w.facultyId.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesStatus = statusFilter === "ALL" || w.status === statusFilter;
		const matchesProg = programmeFilter === "ALL" || w.programme === programmeFilter;
		return matchesSearch && matchesStatus && matchesProg;
	});
	const handleExportFaculty = () => {
		exportFacultyWorkloadToExcel(allWorkloads);
		toast.success("Faculty Workload Excel exported successfully!");
	};
	const handleSaveDefaultHours = () => {
		if (selectedFacultyId && editingDefaultHours !== null) {
			updateFacultyDefaultHours(selectedFacultyId, editingDefaultHours);
			toast.success("Default workload hours updated successfully");
			setEditingDefaultHours(null);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "HOD Reviewer Console",
		subtitle: "Faculty Subject Preference Review, Workload Configuration & Real-Time Allocation Management",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			variant: "outline",
			onClick: handleExportFaculty,
			className: "h-8 gap-1.5 text-xs border-slate-300 bg-white hover:bg-slate-100 text-slate-800",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { className: "size-3.5 text-emerald-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Export Faculty Workload" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			size: "sm",
			onClick: () => navigate({ to: "/admin/allocation" }),
			className: "h-8 gap-1.5 text-xs bg-[#002147] hover:bg-[#001833] text-white",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Open Course Allocation" })]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-[#002147] text-white p-6 shadow-md border border-blue-900/60 relative overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2 py-0.5 text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded uppercase tracking-wider",
									children: "Department of Computer Applications"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-blue-200",
									children: "· MCA & MCA GEN AI"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-2xl font-bold tracking-tight text-white",
								children: "Academic Workload & Preference Management"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-blue-200/90 max-w-2xl leading-relaxed",
								children: "Real-time oversight of faculty subject preferences, section allocations, and dynamic workload calculations according to SRM 2025 Syllabus standards."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 bg-white/10 backdrop-blur-sm p-3.5 rounded-lg border border-white/10 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center px-3 border-r border-white/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase font-bold text-teal-300",
								children: "Coverage"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-2xl font-extrabold text-white",
								children: [dashboardMetrics.allocationCoveragePercentage, "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-blue-100 flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-emerald-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: [dashboardMetrics.allocatedHours, " hrs"]
									}),
									" allocated"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-blue-200 flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-amber-400" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: [dashboardMetrics.unallocatedHours, " hrs"]
									}),
									" unallocated"
								]
							})]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-slate-500",
									children: "Total Faculty"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-slate-900 mt-1",
									children: dashboardMetrics.totalFaculty
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-400 mt-0.5 font-mono",
									children: "18 Seeded Staff"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-slate-500",
									children: "Total Subjects"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-blue-700 mt-1",
									children: dashboardMetrics.totalCourses
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-400 mt-0.5 font-mono",
									children: "2025 Syllabus"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-slate-500",
									children: "Total Sections"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-slate-900 mt-1",
									children: dashboardMetrics.totalSections
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-slate-400 mt-0.5 font-mono",
									children: "MCA & Gen AI"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-emerald-700",
									children: "Pref Submitted"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-emerald-600 mt-1",
									children: dashboardMetrics.submittedPreferences
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-emerald-600/70 mt-0.5 font-mono",
									children: "Willingness Cart"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-amber-700",
									children: "Pref Pending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-amber-600 mt-1",
									children: dashboardMetrics.pendingPreferences
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-amber-600/70 mt-0.5 font-mono",
									children: "Awaiting Cart"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-blue-700",
									children: "Allocated Subjects"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-blue-600 mt-1",
									children: allocations.filter((a) => a.mainFacultyId).length
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-blue-600/70 mt-0.5 font-mono",
									children: "Main Assigned"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-rose-700",
									children: "Unallocated"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-rose-600 mt-1",
									children: allocations.filter((a) => !a.mainFacultyId).length
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-rose-600/70 mt-0.5 font-mono",
									children: "Pending Faculty"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase tracking-wider text-teal-700",
									children: "Reconciled"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xl font-black text-teal-600 mt-1",
									children: allocations.filter((a) => a.status === "FINALIZED" || a.status === "RECONCILED").length
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] text-teal-600/70 mt-0.5 font-mono",
									children: "Finalized Offerings"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-wider text-amber-700",
								children: "UNDERLOADED"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-black text-amber-600",
								children: [dashboardMetrics.underloadedCount, " Faculty"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-mono text-slate-400",
								children: "< Target limit"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-wider text-emerald-700",
								children: "BALANCED"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-black text-emerald-600",
								children: [dashboardMetrics.balancedCount, " Faculty"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-mono text-slate-400",
								children: "100% Target Match"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-wider text-rose-700",
								children: "OVERLOADED"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-black text-rose-600",
								children: [dashboardMetrics.overloadedCount, " Faculty"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-mono text-slate-400",
								children: "> Target limit"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-slate-200 bg-white p-3 shadow-xs flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-bold uppercase tracking-wider text-teal-700",
								children: "CAMPUS WORK"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-lg font-black text-teal-700",
								children: [
									allWorkloads.filter((w) => w.campusWorkHours > 0).length,
									" Faculty (",
									allWorkloads.reduce((sum, w) => sum + w.campusWorkHours, 0),
									"h)"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] font-mono text-slate-400",
								children: "Admin Duties"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 border-b border-slate-200 bg-slate-50/70 flex flex-col md:flex-row items-start md:items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-4 text-[#002147]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-bold text-slate-800 uppercase tracking-wider",
								children: "Faculty Workload Status & Preferences Overview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-slate-500 font-mono",
								children: [
									"(",
									filteredWorkloads.length,
									" faculty)"
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2.5 w-full md:w-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex-1 md:w-56",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Search staff name or ID...",
									value: searchTerm,
									onChange: (e) => setSearchTerm(e.target.value),
									className: "h-8 pl-8 text-xs bg-white rounded-md"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: programmeFilter,
								onChange: (e) => setProgrammeFilter(e.target.value),
								className: "h-8 rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "All Programmes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA",
										children: "MCA"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "MCA GEN AI",
										children: "MCA GEN AI"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: statusFilter,
								onChange: (e) => setStatusFilter(e.target.value),
								className: "h-8 rounded-md border border-slate-200 bg-white px-2.5 text-xs text-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "All Statuses"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "UNDERLOADED",
										children: "Underloaded"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "BALANCED",
										children: "Balanced"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "OVERLOADED",
										children: "Overloaded"
									})
								]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border-collapse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5",
									children: "Faculty Member"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5",
									children: "Designation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5",
									children: "Programme"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Default Hrs"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Allocated Hrs"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Remaining"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Subjects"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Workload Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Preferences"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200",
							children: filteredWorkloads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 10,
								className: "py-12 text-center text-slate-500",
								children: "No faculty found matching the filter criteria."
							}) }) : filteredWorkloads.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "hover:bg-blue-50/40 transition-colors cursor-pointer",
								onClick: () => setSelectedFacultyId(w.facultyId),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "size-6 rounded-full bg-slate-200 text-slate-700 font-bold flex items-center justify-center text-[10px]",
												children: w.facultyName.charAt(3) || "F"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold text-slate-900 leading-tight",
												children: w.facultyName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-[10px] text-slate-500",
												children: w.facultyId
											})] })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-slate-600",
										children: w.designation
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-slate-700",
											children: w.programme
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-bold text-slate-700",
										children: [w.defaultHours, "h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-block px-2 py-0.5 rounded font-mono font-bold text-slate-900 bg-slate-100",
											children: [w.allocatedHours, "h"]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center font-mono",
										children: w.remainingHours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-amber-700 font-bold",
											children: [w.remainingHours, "h remaining"]
										}) : w.overloadHours > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-rose-700 font-bold",
											children: [
												"+",
												w.overloadHours,
												"h overload"
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-emerald-700 font-bold",
											children: "Exact (0h)"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center font-semibold text-slate-700",
										children: w.allocatedCoursesCount
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
											status: w.status,
											size: "sm"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
											status: w.preferencesStatus,
											size: "sm"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: (e) => {
												e.stopPropagation();
												setSelectedFacultyId(w.facultyId);
											},
											className: "h-7 px-2 text-xs text-[#002147] hover:bg-blue-100 hover:text-blue-900 gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "View" })]
										})
									})
								]
							}, w.facultyId))
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedFacultyId,
				onOpenChange: (open) => !open && setSelectedFacultyId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base font-bold text-slate-900",
							children: selectedWorkload?.facultyName
						}), selectedWorkload && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, { status: selectedWorkload.status })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						selectedWorkload?.designation,
						" · ",
						selectedWorkload?.programme,
						" · Faculty ID: ",
						selectedWorkload?.facultyId
					] })] }), selectedWorkload && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Default Limit"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-slate-800",
										children: [selectedWorkload.defaultHours, " hrs"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Allocated"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-blue-700",
										children: [selectedWorkload.allocatedHours, " hrs"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Theory / Lab"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm font-bold text-slate-700 mt-1",
										children: [
											selectedWorkload.theoryHours,
											"h (T) + ",
											selectedWorkload.practicalHours,
											"h (L)"
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Remaining"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-amber-700",
										children: [selectedWorkload.remainingHours, " hrs"]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 bg-blue-50/60 border border-blue-200 rounded-lg flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold text-blue-900",
									children: "Configurable Default Workload Limit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] text-blue-700",
									children: "Adjust official default weekly hours for this faculty profile."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: editingDefaultHours ?? selectedWorkload.defaultHours,
										onChange: (e) => setEditingDefaultHours(Number(e.target.value)),
										className: "h-8 rounded border border-blue-300 bg-white px-2 text-xs font-bold text-blue-900",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 18,
												children: "18 Hours (Prof / AP Regular)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 16,
												children: "16 Hours (Adjunct)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 14,
												children: "14 Hours (Lead)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 10,
												children: "10 Hours (FTS)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 4,
												children: "4 Hours (AP/BSc. CS)"
											})
										]
									}), editingDefaultHours !== null && editingDefaultHours !== selectedWorkload.defaultHours && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: handleSaveDefaultHours,
										className: "h-8 px-2.5 text-xs bg-blue-700",
										children: "Save"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-bold uppercase tracking-wider text-slate-500 text-[11px]",
									children: [
										"Allocated Courses (",
										selectedWorkload.allocatedSubjects.length,
										")"
									]
								}), selectedWorkload.allocatedSubjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "p-3 bg-slate-100 rounded text-slate-500 text-center",
									children: "No teaching courses currently assigned."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100",
									children: selectedWorkload.allocatedSubjects.map((sub, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-2.5 flex items-center justify-between hover:bg-slate-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded text-[10px]",
												children: sub.courseCode
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-900",
												children: sub.courseTitle
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-[11px] text-slate-500 mt-0.5",
											children: [
												"Section: ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-slate-700",
													children: sub.section
												}),
												" · Students: ",
												sub.studentCount,
												" · Role: ",
												sub.role
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold text-slate-900 text-xs",
												children: [
													sub.theoryHours,
													"h Th + ",
													sub.practicalHours,
													"h Lab"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-400 font-mono",
												children: [
													"Total: ",
													sub.totalHours,
													" hrs"
												]
											})]
										})]
									}, i))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 pt-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold uppercase tracking-wider text-slate-500 text-[11px]",
									children: "Faculty Preferences Submitted"
								}), selectedWorkload.preferencesStatus === "PENDING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 rounded bg-amber-50 border border-amber-200 text-amber-800 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-amber-600 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "This faculty member has not submitted their subject preferences yet." })]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [selectedWorkload.allocatedSubjects.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[11px] text-slate-500 italic",
										children: "Preferences submitted by faculty during the willingness collection window:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid gap-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "p-2 rounded bg-slate-50 border border-slate-200 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-800",
												children: "1. Preferred Subjects Cart"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
												status: "SUBMITTED",
												size: "sm"
											})]
										})
									})]
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { HodDashboardPage as component };
