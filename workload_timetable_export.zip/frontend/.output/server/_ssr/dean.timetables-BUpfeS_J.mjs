import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as cn, r as api } from "./button-V9LDemPn.mjs";
import { b as Lock } from "../_libs/lucide-react.mjs";
import { r as deanNav, t as PortalShell } from "./portal-nav-DZYI--rN.mjs";
import { t as TimetableGrid } from "./TimetableGrid-NyEJ1Bpe.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dean.timetables-BUpfeS_J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DeanTimetables() {
	const { data: metadata } = useQuery({
		queryKey: ["metadata"],
		queryFn: async () => {
			return (await api.get("/api/timetable/metadata")).data;
		}
	});
	const sections = metadata?.sections || [];
	const [section, setSection] = (0, import_react.useState)("");
	(0, import_react.useMemo)(() => {
		if (sections.length > 0 && !section) setSection(sections[0]);
	}, [sections, section]);
	const { data: allBlocks } = useQuery({
		queryKey: ["admin-timetable"],
		queryFn: async () => {
			return (await api.get("/api/admin/timetable")).data;
		}
	});
	const grid = (0, import_react.useMemo)(() => {
		const defaultGrid = Array(5).fill(null).map(() => Array(6).fill(null));
		if (!allBlocks || !section) return defaultGrid;
		allBlocks.forEach((block) => {
			if (block.section === section) {
				if (block.day >= 0 && block.day < 5 && block.period >= 0 && block.period < 6 && defaultGrid[block.day]) defaultGrid[block.day][block.period] = {
					subject: block.subject,
					venue: "",
					faculty: block.faculty_id,
					section: block.section
				};
			}
		});
		return defaultGrid;
	}, [allBlocks, section]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShell, {
		role: "dean",
		title: "Universal Institutional Timetables",
		subtitle: "Read-only · all sections, Monday to Friday, 6 periods",
		nav: deanNav,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 rounded-xl border border-border bg-card p-3 shadow-[var(--shadow-card)]",
				children: [sections.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground p-2",
					children: "No sections generated yet. Generate the timetable first."
				}), sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setSection(s),
					className: cn("rounded-md px-3.5 py-2 text-sm font-medium transition-colors", s === section ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"),
					children: s
				}, s))]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold text-foreground",
						children: section
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5 rounded-md bg-muted px-3 py-1.5 text-xs font-semibold text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-3.5" }), " View only"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimetableGrid, {
					grid,
					showFaculty: true
				})]
			})]
		})
	});
}
//#endregion
export { DeanTimetables as component };
