import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAuth, i as cn, r as api } from "./button-V9LDemPn.mjs";
import { i as facultyNav, t as PortalShell } from "./portal-nav-DZYI--rN.mjs";
import { t as TimetableGrid } from "./TimetableGrid-NyEJ1Bpe.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faculty.timetable-C4ISTgcS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FacultyTimetable() {
	const { session } = useAuth();
	const [view, setView] = (0, import_react.useState)("mine");
	const name = session?.name ?? "";
	const { data: metadata } = useQuery({
		queryKey: ["metadata"],
		queryFn: async () => {
			return (await api.get("/api/timetable/metadata")).data;
		}
	});
	const sections = metadata?.sections || [];
	const [section, setSection] = (0, import_react.useState)("");
	(0, import_react.useMemo)(() => {
		if (sections.length > 0 && !section) setSection(sections[0]);
	}, [sections, section]);
	const { data: allBlocks } = useQuery({
		queryKey: ["admin-timetable"],
		queryFn: async () => {
			return (await api.get("/api/admin/timetable")).data;
		}
	});
	const mine = (0, import_react.useMemo)(() => {
		const defaultGrid = Array(5).fill(null).map(() => Array(6).fill(null));
		if (!allBlocks || !name) return defaultGrid;
		allBlocks.forEach((block) => {
			if (block.faculty_id === name || block.faculty_id.includes(name)) {
				if (block.day >= 0 && block.day < 5 && block.period >= 0 && block.period < 6 && defaultGrid[block.day]) defaultGrid[block.day][block.period] = {
					subject: block.subject,
					venue: "",
					faculty: block.faculty_id,
					section: block.section
				};
			}
		});
		return defaultGrid;
	}, [allBlocks, name]);
	const classGrid = (0, import_react.useMemo)(() => {
		const defaultGrid = Array(5).fill(null).map(() => Array(6).fill(null));
		if (!allBlocks || !section) return defaultGrid;
		allBlocks.forEach((block) => {
			if (block.section === section) {
				if (block.day >= 0 && block.day < 5 && block.period >= 0 && block.period < 6 && defaultGrid[block.day]) defaultGrid[block.day][block.period] = {
					subject: block.subject,
					venue: "",
					faculty: block.faculty_id,
					section: block.section
				};
			}
		});
		return defaultGrid;
	}, [allBlocks, section]);
	const totalHours = mine.flat().filter(Boolean).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShell, {
		role: "faculty",
		title: "Faculty Timetable",
		subtitle: `${name} · ${totalHours} contact hours per week`,
		nav: facultyNav,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "inline-flex rounded-lg border border-border bg-card p-1 shadow-[var(--shadow-card)]",
					children: [["mine", "My Schedule"], ["class", "Class Schedules"]].map(([key, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setView(key),
						className: cn("rounded-md px-4 py-2 text-sm font-medium transition-colors", view === key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"),
						children: label
					}, key))
				}),
				view === "class" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 rounded-xl border border-border bg-card p-3 shadow-[var(--shadow-card)]",
					children: [sections.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground p-2",
						children: "No sections generated yet."
					}), sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSection(s),
						className: cn("rounded-md px-3 py-1.5 text-sm font-medium transition-colors", s === section ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"),
						children: s
					}, s))]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-4 text-lg font-semibold text-foreground",
						children: view === "mine" ? "My Weekly Schedule" : `${section} — Class Schedule`
					}), view === "mine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimetableGrid, {
						grid: mine,
						showSection: true
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimetableGrid, {
						grid: classGrid,
						showFaculty: true
					})]
				})
			]
		})
	});
}
//#endregion
export { FacultyTimetable as component };
