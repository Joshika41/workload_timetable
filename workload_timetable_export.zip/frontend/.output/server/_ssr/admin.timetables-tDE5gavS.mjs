import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useAuth, i as cn, n as Button, r as api } from "./button-V9LDemPn.mjs";
import { $ as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as adminNav, t as PortalShell } from "./portal-nav-DZYI--rN.mjs";
import { t as TimetableGrid } from "./TimetableGrid-NyEJ1Bpe.mjs";
import { t as useQuery } from "../_libs/tanstack__react-query.mjs";
import { t as require_html2pdf } from "../_libs/html2pdf.js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.timetables-tDE5gavS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_html2pdf = /* @__PURE__ */ __toESM(require_html2pdf());
function MasterTimetables() {
	const { session } = useAuth();
	const { data: metadata } = useQuery({
		queryKey: ["metadata"],
		queryFn: async () => {
			return (await api.get("/api/timetable/metadata")).data;
		}
	});
	const sections = metadata?.sections || [];
	const [section, setSection] = (0, import_react.useState)("");
	(0, import_react.useMemo)(() => {
		if (sections.length > 0 && !section) setSection(sections[0]);
	}, [sections, section]);
	const { data: allBlocks, isLoading } = useQuery({
		queryKey: ["admin-timetable"],
		queryFn: async () => {
			return (await api.get("/api/admin/timetable")).data;
		}
	});
	const grid = (0, import_react.useMemo)(() => {
		const defaultGrid = Array(5).fill(null).map(() => Array(6).fill(null));
		if (!allBlocks || !section) return defaultGrid;
		allBlocks.forEach((block) => {
			if (block.section === section) {
				if (block.day >= 0 && block.day < 5 && block.period >= 0 && block.period < 6 && defaultGrid[block.day]) defaultGrid[block.day][block.period] = {
					subject: block.subject,
					venue: "",
					faculty: block.faculty_id,
					section: block.section
				};
			}
		});
		return defaultGrid;
	}, [allBlocks, section]);
	const exportPDF = () => {
		const element = document.getElementById("timetable-export-container");
		if (!element) return;
		const opt = {
			margin: .5,
			filename: `timetable_${section}.pdf`,
			image: {
				type: "jpeg",
				quality: .98
			},
			html2canvas: { scale: 2 },
			jsPDF: {
				unit: "in",
				format: "a4",
				orientation: "landscape"
			}
		};
		(0, import_html2pdf.default)().set(opt).from(element).save();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShell, {
		role: "admin",
		title: "Master Class Timetables",
		subtitle: session?.department ?? "All institutional sections",
		nav: adminNav,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => window.history.back(),
						className: "h-8 gap-1 text-xs text-muted-foreground hover:text-foreground border border-border bg-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2 rounded-xl border border-border bg-card p-3 shadow-[var(--shadow-card)]",
					children: [sections.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted-foreground p-2",
						children: "No sections generated yet. Generate the timetable first."
					}), sections.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setSection(s),
						className: cn("rounded-md px-3.5 py-2 text-sm font-medium transition-colors", s === section ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"),
						children: s
					}, s))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-foreground",
							children: section
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Monday to Friday · exactly 6 periods per day · labs de-duplicated"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: exportPDF,
								children: "Export PDF"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-accent-foreground",
								children: "Published"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "timetable-export-container",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimetableGrid, {
							grid,
							showFaculty: true
						})
					})]
				})
			]
		})
	});
}
//#endregion
export { MasterTimetables as component };
