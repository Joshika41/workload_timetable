import { apiClient } from './client';
import type { FacultyWorkloadResponse, ClassMatrixRow } from '../types/workload';

export const workloadApi = {
  getFacultyWorkloads: async (workspaceId: string): Promise<FacultyWorkloadResponse[]> => {
    const response = await apiClient.get<FacultyWorkloadResponse[]>('/workload/faculty', {
      params: { workspace_id: workspaceId }
    });
    return response.data;
  },
  
  getClassMatrix: async (workspaceId: string): Promise<ClassMatrixRow[]> => {
    const response = await apiClient.get<ClassMatrixRow[]>('/workload/class-matrix', {
      params: { workspace_id: workspaceId }
    });
    return response.data;
  }
};
