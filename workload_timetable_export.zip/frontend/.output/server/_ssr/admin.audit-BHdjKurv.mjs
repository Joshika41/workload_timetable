import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as Button, r as api } from "./button-V9LDemPn.mjs";
import { $ as ArrowLeft, O as History, P as Clock, d as Search, m as RefreshCw, r as User, x as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
import { n as adminNav, t as PortalShell } from "./portal-nav-DZYI--rN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.audit-BHdjKurv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AuditTrail() {
	const [logs, setLogs] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const fetchLogs = async () => {
		setLoading(true);
		try {
			const res = await api.get("/api/admin/audit-logs");
			setLogs(res.data || []);
		} catch (err) {
			console.error("Failed to fetch audit logs:", err);
			setLogs([]);
		} finally {
			setLoading(false);
		}
	};
	(0, import_react.useEffect)(() => {
		fetchLogs();
	}, []);
	const filteredLogs = logs.filter((log) => {
		if (!searchTerm) return true;
		const term = searchTerm.toLowerCase();
		return log.action?.toLowerCase().includes(term) || log.user_email?.toLowerCase().includes(term) || log.entity_type?.toLowerCase().includes(term) || log.details?.toLowerCase().includes(term);
	});
	const formatTimestamp = (ts) => {
		try {
			return new Date(ts).toLocaleString("en-IN", {
				year: "numeric",
				month: "short",
				day: "2-digit",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit"
			});
		} catch {
			return ts;
		}
	};
	const getActionColor = (action) => {
		const a = action?.toUpperCase() || "";
		if (a.includes("DELETE") || a.includes("WIPE")) return "text-red-700 bg-red-100 border-red-200";
		if (a.includes("CREATE") || a.includes("UPLOAD")) return "text-emerald-700 bg-emerald-100 border-emerald-200";
		if (a.includes("LOCK") || a.includes("PUBLISH")) return "text-indigo-700 bg-indigo-100 border-indigo-200";
		if (a.includes("UPDATE") || a.includes("ASSIGN")) return "text-amber-700 bg-amber-100 border-amber-200";
		return "text-slate-700 bg-slate-100 border-slate-200";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalShell, {
		role: "admin",
		title: "Audit Trail",
		subtitle: "Complete historical log of all system actions and allocation overrides",
		nav: adminNav,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col sm:flex-row items-center justify-between gap-4 rounded-2xl border border-border bg-card p-4 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Search by action, user, entity...",
						value: searchTerm,
						onChange: (e) => setSearchTerm(e.target.value),
						className: "pl-9 rounded-xl"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => window.history.back(),
						className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: fetchLogs,
						disabled: loading,
						className: "gap-1.5 rounded-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `size-3.5 ${loading ? "animate-spin" : ""}` }),
							" ",
							"Refresh"
						]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card shadow-sm overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm text-left border-collapse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-xs text-muted-foreground bg-muted/50 uppercase sticky top-0 z-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[18%]",
									children: "Timestamp"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[14%]",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[16%]",
									children: "User"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[12%]",
									children: "Entity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[18%]",
									children: "Previous Value"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-6 py-4 font-bold tracking-wider w-[4%]" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-6 py-4 font-bold tracking-wider w-[18%]",
									children: "New Value"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								colSpan: 7,
								className: "px-6 py-16 text-center text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto size-8 animate-spin text-primary opacity-60 mb-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: "Loading audit trail..."
								})]
							}) }) : filteredLogs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "px-6 py-16 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center justify-center opacity-60",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(History, { className: "size-12 mb-3 text-muted-foreground" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-semibold text-lg",
											children: logs.length === 0 ? "No Audit Logs Yet" : "No Matching Results"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm mt-1",
											children: logs.length === 0 ? "Actions will appear here as administrators and faculty interact with the system." : "Try adjusting your search term."
										})
									]
								})
							}) }) : filteredLogs.map((log, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: `group hover:bg-muted/30 transition-colors ${idx % 2 === 0 ? "bg-muted/10" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2 text-xs text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono",
												children: formatTimestamp(log.timestamp)
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `inline-flex items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider border shadow-sm ${getActionColor(log.action)}`,
											children: log.action
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-3.5 text-muted-foreground shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-medium text-foreground truncate max-w-[140px]",
												children: log.user_email || "System"
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded border border-border",
											children: [log.entity_type || "-", log.entity_id ? ` #${log.entity_id}` : ""]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs text-muted-foreground font-mono truncate block max-w-[160px]",
											children: log.previous_value || "-"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4 text-center",
										children: log.new_value && log.previous_value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-primary mx-auto" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-6 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs font-medium text-foreground font-mono truncate block max-w-[160px]",
											children: log.new_value || log.details || "-"
										})
									})
								]
							}, log.id || idx))
						})]
					})
				}), filteredLogs.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-t border-border bg-muted/20 px-6 py-3 text-xs text-muted-foreground",
					children: [
						"Showing ",
						filteredLogs.length,
						" of ",
						logs.length,
						" total audit entries"
					]
				})]
			})]
		})
	});
}
//#endregion
export { AuditTrail as component };
