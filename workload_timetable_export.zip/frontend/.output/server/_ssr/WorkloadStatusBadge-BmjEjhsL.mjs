import "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { i as cn } from "./button-V9LDemPn.mjs";
import { L as CircleMinus, P as Clock, R as CircleCheck, a as TriangleAlert, z as CircleAlert } from "../_libs/lucide-react.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground shadow hover:bg-primary/80",
		secondary: "border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80",
		destructive: "border-transparent bg-destructive text-destructive-foreground shadow hover:bg-destructive/80",
		outline: "text-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function WorkloadStatusBadge({ status, className = "", size = "default" }) {
	const sizeClasses = size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs";
	switch (status) {
		case "UNDERLOADED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-amber-300 bg-amber-50 text-amber-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleMinus, { className: "size-3 text-amber-600" }), "UNDERLOADED"]
		});
		case "BALANCED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-emerald-300 bg-emerald-50 text-emerald-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-emerald-600" }), "BALANCED"]
		});
		case "OVERLOADED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-rose-300 bg-rose-50 text-rose-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3 text-rose-600" }), "OVERLOADED"]
		});
		case "SUBMITTED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-blue-300 bg-blue-50 text-blue-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-blue-600" }), "SUBMITTED"]
		});
		case "PENDING": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-slate-300 bg-slate-100 text-slate-700 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-slate-500" }), "PENDING"]
		});
		case "ALLOCATED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-teal-300 bg-teal-50 text-teal-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3 text-teal-600" }), "ALLOCATED"]
		});
		case "PARTIALLY_ALLOCATED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-sky-300 bg-sky-50 text-sky-800 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3 text-sky-600" }), "PARTIAL"]
		});
		case "UNALLOCATED": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: `inline-flex items-center gap-1 font-semibold rounded-md border border-red-200 bg-red-50 text-red-700 ${sizeClasses} ${className}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3 text-red-600" }), "UNALLOCATED"]
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "outline",
			className: sizeClasses,
			children: status
		});
	}
}
//#endregion
export { WorkloadStatusBadge as t };
