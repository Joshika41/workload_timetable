import { n as writeFileSync, t as utils } from "../_libs/xlsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/excel-export-BRKgErUs.js
/**
* Exports Faculty-wise Workload Sheet reproducing "Untitled spreadsheet.xlsx"
* Structure:
* S.No | Staff Name | Designation | Subject Code | Course Name | Class & Section | No of Stu | Theory | Practical | Total Hours | Default Hours | Remaining Hours | Status
*/
function exportFacultyWorkloadToExcel(workloads, fileName = "Faculty_Workload_Plan_SRM.xlsx") {
	const rows = [];
	rows.push(["SRM INSTITUTE OF SCIENCE AND TECHNOLOGY"]);
	rows.push(["DEPARTMENT OF COMPUTER APPLICATIONS - MCA & MCA GEN AI"]);
	rows.push(["FACULTY WORKLOAD ALLOCATION & STATUS REPORT - ACADEMIC YEAR 2026-2027"]);
	rows.push([]);
	rows.push([
		"S.No",
		"Staff Name",
		"Designation",
		"Programme",
		"Subject Code",
		"Course Name",
		"Class & Section",
		"No of Stu",
		"Role",
		"Theory (Hrs)",
		"Practical (Hrs)",
		"Allocated Hours",
		"Default Hours",
		"Remaining Hours",
		"Workload Status"
	]);
	let serial = 1;
	workloads.forEach((w) => {
		if (w.allocatedSubjects.length === 0) rows.push([
			serial++,
			w.facultyName,
			w.designation,
			w.programme,
			"-",
			"No subjects currently allocated",
			"-",
			0,
			"-",
			0,
			0,
			0,
			w.defaultHours,
			w.remainingHours,
			w.status
		]);
		else {
			w.allocatedSubjects.forEach((sub, subIdx) => {
				rows.push([
					subIdx === 0 ? serial++ : "",
					subIdx === 0 ? w.facultyName : "",
					subIdx === 0 ? w.designation : "",
					subIdx === 0 ? w.programme : "",
					sub.courseCode,
					sub.courseTitle,
					sub.section,
					sub.studentCount,
					sub.role,
					sub.theoryHours,
					sub.practicalHours,
					sub.totalHours,
					subIdx === 0 ? w.defaultHours : "",
					subIdx === 0 ? w.remainingHours : "",
					subIdx === 0 ? w.status : ""
				]);
			});
			rows.push([
				"",
				`Total for ${w.facultyName}:`,
				"",
				"",
				"",
				"",
				"",
				"",
				"",
				w.theoryHours,
				w.practicalHours,
				w.allocatedHours,
				w.defaultHours,
				w.remainingHours,
				w.status
			]);
			rows.push([]);
		}
	});
	rows.push([]);
	rows.push(["DEPARTMENT SUMMARY METRICS"]);
	const totalAllocated = workloads.reduce((sum, w) => sum + w.allocatedHours, 0);
	const totalDefault = workloads.reduce((sum, w) => sum + w.defaultHours, 0);
	const underloaded = workloads.filter((w) => w.status === "UNDERLOADED").length;
	const balanced = workloads.filter((w) => w.status === "BALANCED").length;
	const overloaded = workloads.filter((w) => w.status === "OVERLOADED").length;
	rows.push(["Total Faculty:", workloads.length]);
	rows.push(["Total Department Default Hours:", totalDefault]);
	rows.push(["Total Department Allocated Hours:", totalAllocated]);
	rows.push(["Faculty Underloaded:", underloaded]);
	rows.push(["Faculty Balanced:", balanced]);
	rows.push(["Faculty Overloaded:", overloaded]);
	const ws = utils.aoa_to_sheet(rows);
	ws["!cols"] = [
		{ wch: 6 },
		{ wch: 26 },
		{ wch: 22 },
		{ wch: 14 },
		{ wch: 14 },
		{ wch: 38 },
		{ wch: 18 },
		{ wch: 10 },
		{ wch: 12 },
		{ wch: 13 },
		{ wch: 14 },
		{ wch: 15 },
		{ wch: 14 },
		{ wch: 16 },
		{ wch: 16 }
	];
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Faculty Workload Sheet");
	writeFileSync(wb, fileName);
}
/**
* Exports Course-wise Allocation Sheet reproducing "Untitled spreadsheet (1).xlsx"
* Structure:
* Course Code | Course Name | Programme | Semester | Section | Main Faculty | Assistant Faculty | Students | Theory | Practical | Total Hours
*/
function exportCourseAllocationToExcel(allocations, fileName = "Course_Wise_Allocation_SRM.xlsx") {
	const rows = [];
	rows.push(["SRM INSTITUTE OF SCIENCE AND TECHNOLOGY"]);
	rows.push(["DEPARTMENT OF COMPUTER APPLICATIONS - MCA & MCA GEN AI"]);
	rows.push(["COURSE-WISE FACULTY ALLOCATION MATRIX - ACADEMIC YEAR 2026-2027"]);
	rows.push([]);
	rows.push([
		"S.No",
		"Course Code",
		"Course Name",
		"Programme",
		"Semester",
		"Section",
		"Main Faculty",
		"Assistant Faculty (Lab Support)",
		"Students",
		"Theory (Hrs)",
		"Practical (Hrs)",
		"Total Hours",
		"Allocation Status"
	]);
	let serial = 1;
	let totalTheory = 0;
	let totalPractical = 0;
	let grandTotal = 0;
	allocations.forEach((alloc) => {
		totalTheory += alloc.theoryHours;
		totalPractical += alloc.practicalHours;
		grandTotal += alloc.totalHours;
		rows.push([
			serial++,
			alloc.courseCode,
			alloc.courseTitle,
			alloc.programme,
			alloc.semester,
			alloc.section,
			alloc.mainFacultyName || "Unassigned",
			alloc.asstFacultyName || "-",
			alloc.studentCount,
			alloc.theoryHours,
			alloc.practicalHours,
			alloc.totalHours,
			alloc.status
		]);
	});
	rows.push([]);
	rows.push([
		"",
		"TOTALS:",
		"",
		"",
		"",
		"",
		"",
		"",
		"",
		totalTheory,
		totalPractical,
		grandTotal,
		""
	]);
	const ws = utils.aoa_to_sheet(rows);
	ws["!cols"] = [
		{ wch: 6 },
		{ wch: 14 },
		{ wch: 38 },
		{ wch: 14 },
		{ wch: 10 },
		{ wch: 18 },
		{ wch: 26 },
		{ wch: 26 },
		{ wch: 10 },
		{ wch: 13 },
		{ wch: 14 },
		{ wch: 13 },
		{ wch: 18 }
	];
	const wb = utils.book_new();
	utils.book_append_sheet(wb, ws, "Course Allocation Sheet");
	writeFileSync(wb, fileName);
}
//#endregion
export { exportFacultyWorkloadToExcel as n, exportCourseAllocationToExcel as t };
