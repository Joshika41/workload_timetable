import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { $ as ArrowLeft, T as Layers, Y as BookOpen, d as Search, g as Plus, k as GraduationCap } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
import { t as COURSE_CATEGORIES } from "./workload-types-BTjWZ-Y7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.setup-CijS3XCu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminAcademicSetupPage() {
	const { courseList, sectionList, addCourse } = useWorkloadData();
	const [activeTab, setActiveTab] = (0, import_react.useState)("courses");
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("ALL");
	const [isAddCourseModalOpen, setIsAddCourseModalOpen] = (0, import_react.useState)(false);
	const [newCourseCode, setNewCourseCode] = (0, import_react.useState)("");
	const [newCourseTitle, setNewCourseTitle] = (0, import_react.useState)("");
	const [newCourseCategory, setNewCourseCategory] = (0, import_react.useState)("C");
	const [newCourseProgramme, setNewCourseProgramme] = (0, import_react.useState)("MCA");
	const [newCourseSemester, setNewCourseSemester] = (0, import_react.useState)("I");
	const [newTheoryHours, setNewTheoryHours] = (0, import_react.useState)(0);
	const [newTutorialHours, setNewTutorialHours] = (0, import_react.useState)(0);
	const [newPracticalHours, setNewPracticalHours] = (0, import_react.useState)(0);
	const [newCredits, setNewCredits] = (0, import_react.useState)(0);
	const handleAddCourse = () => {
		if (!newCourseCode || !newCourseTitle) {
			toast.error("Please enter course code and title");
			return;
		}
		addCourse({
			code: newCourseCode,
			title: newCourseTitle,
			category: newCourseCategory,
			programme: newCourseProgramme,
			semester: newCourseSemester,
			theoryHours_L: newTheoryHours,
			tutorialHours_T: newTutorialHours,
			practicalHours_P: newPracticalHours,
			credits_C: newCredits
		});
		toast.success("Course added successfully");
		setIsAddCourseModalOpen(false);
		setNewCourseCode("");
		setNewCourseTitle("");
		setNewTheoryHours(0);
		setNewTutorialHours(0);
		setNewPracticalHours(0);
		setNewCredits(0);
	};
	const filteredCourses = courseList.filter((c) => {
		const matchesSearch = c.code.toLowerCase().includes(searchTerm.toLowerCase()) || c.title.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesProg = programmeFilter === "ALL" || c.programme === programmeFilter;
		const matchesCat = categoryFilter === "ALL" || c.category === categoryFilter;
		return matchesSearch && matchesProg && matchesCat;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "Academic Setup & Course Master",
		subtitle: "Configure 2025 SRM MCA & MCA GEN AI curriculum, syllabus categories, and class sections",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => window.history.back(),
				className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
			})
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setActiveTab("courses"),
							className: `px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 ${activeTab === "courses" ? "bg-[#002147] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-3.5" }),
								"Course Master (",
								courseList.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setActiveTab("sections"),
							className: `px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 ${activeTab === "sections" ? "bg-[#002147] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, { className: "size-3.5" }),
								"Section / Class Master (",
								sectionList.length,
								")"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setActiveTab("programmes"),
							className: `px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 ${activeTab === "programmes" ? "bg-[#002147] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5" }), "Programmes & Semesters"]
						})
					]
				}), activeTab === "courses" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 w-full sm:w-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex-1 sm:w-48",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Search code or title...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "h-8 pl-7 text-xs bg-slate-50"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: programmeFilter,
							onChange: (e) => setProgrammeFilter(e.target.value),
							className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ALL",
									children: "All Programmes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "MCA",
									children: "MCA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "MCA GEN AI",
									children: "MCA GEN AI"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: categoryFilter,
							onChange: (e) => setCategoryFilter(e.target.value),
							className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ALL",
									children: "All Categories"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "C",
									children: "Professional Core (C)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "D",
									children: "Discipline Elective (D)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "G",
									children: "Generic Elective (G)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "S",
									children: "Skill Enhancement (S)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "AE",
									children: "Ability Enhancement (AE)"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: () => setIsAddCourseModalOpen(true),
							className: "h-8 gap-1.5 text-xs bg-[#002147] hover:bg-[#001833] text-white shrink-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: "Add Course"
							})]
						})
					]
				})]
			}),
			activeTab === "courses" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border-collapse min-w-[850px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Course Code"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Course Title"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Category"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Programme"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Semester"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Theory (L)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Tutorial (T)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Practical (P)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-center",
									children: "Credits (C)"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200",
							children: filteredCourses.map((c) => {
								const catInfo = COURSE_CATEGORIES[c.category];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-blue-50/30 transition-colors",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-mono font-bold text-blue-700",
											children: c.code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-bold text-slate-900",
											children: c.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `px-2 py-0.5 rounded text-[10px] font-bold ${catInfo?.badgeColor || "bg-slate-200 text-slate-800"}`,
												children: catInfo?.name || c.category
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-semibold text-slate-700",
											children: c.programme
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-semibold",
											children: ["Sem ", c.semester]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center font-mono font-bold text-slate-800",
											children: c.theoryHours_L
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center font-mono text-slate-600",
											children: c.tutorialHours_T
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center font-mono font-bold text-slate-800",
											children: c.practicalHours_P
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center font-mono font-black text-blue-900 bg-blue-50/50",
											children: c.credits_C
										})
									]
								}, c.code);
							})
						})]
					})
				})
			}),
			activeTab === "sections" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden p-6 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-bold text-slate-800 uppercase tracking-wider",
					children: "Class Section Configuration"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-slate-500",
					children: "Configure student counts, laboratory batching, and cohort settings per section."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
					children: sectionList.map((sec) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:border-blue-300 transition-all space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-sm text-slate-900 font-mono",
								children: sec.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800",
								children: ["Sem ", sec.semester]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5 text-xs text-slate-600",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Programme:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
										className: "text-slate-800",
										children: sec.programme
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total Students:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "font-mono text-slate-900",
										children: [sec.studentCount, " students"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lab Batches:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "font-mono text-blue-700",
										children: [sec.labBatches, " Batches"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Students / Batch:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", {
										className: "font-mono text-slate-700",
										children: ["~", sec.studentsPerBatch || Math.round(sec.studentCount / sec.labBatches)]
									})]
								})
							]
						})]
					}, sec.id))
				})]
			}),
			activeTab === "programmes" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 rounded-xl border border-slate-200 bg-white shadow-sm space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold",
							children: "MCA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-bold text-base text-slate-900",
							children: "Master of Computer Applications"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500",
							children: "2-Year PG Programme · 2025 Regulations"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 text-xs text-slate-600",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Active Semesters:" }), " Semester I (Odd), Semester II (Even)"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Core Courses:" }), " 10 Professional Core (PCA25C01J to PCA25C10L)"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Electives:" }), " 9 Discipline Electives, 6 Generic Electives"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total Sections:" }), " 4 Sections (I MCA A, I MCA B, II MCA A, II MCA B)"] })
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6 rounded-xl border border-slate-200 bg-white shadow-sm space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "size-10 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold",
							children: "AI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "font-bold text-base text-slate-900",
							children: "MCA in Generative Artificial Intelligence"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500",
							children: "2-Year Specialised PG Programme · 2025 Regulations"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 text-xs text-slate-600",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Active Semesters:" }), " Semester I (Odd), Semester II (Even)"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Specialised Courses:" }), " Foundations of Gen AI, Large Language Models, Diffusion Models"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total Sections:" }), " 4 Sections (I MCA GEN AI A, I MCA GEN AI B, II MCA GEN AI A, II MCA GEN AI B)"] })
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isAddCourseModalOpen,
				onOpenChange: setIsAddCourseModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-teal-600" }), "Add New Course"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Enter the course details to add a new subject to the curriculum master." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-4 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Code"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newCourseCode,
										onChange: (e) => setNewCourseCode(e.target.value.toUpperCase()),
										placeholder: "e.g. CAC25101",
										className: "h-8 text-xs font-mono"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "col-span-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Title"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: newCourseTitle,
										onChange: (e) => setNewCourseTitle(e.target.value),
										placeholder: "e.g. Advanced Data Structures",
										className: "h-8 text-xs"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Category"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: newCourseCategory,
										onChange: (e) => setNewCourseCategory(e.target.value),
										className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "C",
												children: "Core (C)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "D",
												children: "Elective (D)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "G",
												children: "Generic (G)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "S",
												children: "Skill (S)"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "AE",
												children: "Ability (AE)"
											})
										]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Programme"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: newCourseProgramme,
										onChange: (e) => setNewCourseProgramme(e.target.value),
										className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "MCA",
											children: "MCA"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "MCA GEN AI",
											children: "MCA GEN AI"
										})]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Semester"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: newCourseSemester,
										onChange: (e) => setNewCourseSemester(e.target.value),
										className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "I",
												children: "Semester I"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "II",
												children: "Semester II"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "III",
												children: "Semester III"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "IV",
												children: "Semester IV"
											})
										]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-4 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Theory (L)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: newTheoryHours,
										onChange: (e) => setNewTheoryHours(Number(e.target.value)),
										className: "h-8 text-xs font-mono"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Tutorial (T)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: newTutorialHours,
										onChange: (e) => setNewTutorialHours(Number(e.target.value)),
										className: "h-8 text-xs font-mono"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Practical (P)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: newPracticalHours,
										onChange: (e) => setNewPracticalHours(Number(e.target.value)),
										className: "h-8 text-xs font-mono"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "block text-[11px] font-bold text-slate-600 mb-1",
										children: "Credits (C)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										value: newCredits,
										onChange: (e) => setNewCredits(Number(e.target.value)),
										className: "h-8 text-xs font-mono"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setIsAddCourseModalOpen(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: handleAddCourse,
									className: "bg-[#002147] text-white",
									children: "Add Course"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminAcademicSetupPage as component };
