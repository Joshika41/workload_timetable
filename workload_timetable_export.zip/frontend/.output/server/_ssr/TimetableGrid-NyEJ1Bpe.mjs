import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TimetableGrid-NyEJ1Bpe.js
var import_jsx_runtime = require_jsx_runtime();
var DAYS = [
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday"
];
var PERIODS = [
	"P1 · 08:45",
	"P2 · 09:40",
	"P3 · 10:50",
	"P4 · 11:45",
	"P5 · 01:30",
	"P6 · 02:25"
];
/** Strict 5 day x exactly 6 period grid. */
function TimetableGrid({ grid, showSection = false, showFaculty = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-lg border border-border bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[820px] border-collapse text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "bg-primary text-primary-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "w-28 border-r border-primary-foreground/15 px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wide",
					children: "Day"
				}), PERIODS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "border-r border-primary-foreground/15 px-3 py-2.5 text-center text-xs font-semibold last:border-r-0",
					children: p
				}, p))]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: DAYS.map((day, d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border even:bg-muted/40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "border-r border-border px-3 py-2.5 text-left text-xs font-semibold text-foreground",
					children: day
				}), Array.from({ length: 6 }).map((_, p) => {
					const slot = grid[d]?.[p] ?? null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "h-20 border-r border-border px-2 py-2 align-top text-center last:border-r-0",
						children: slot ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full flex-col items-center justify-center gap-0.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[13px] font-semibold leading-tight text-foreground",
									children: slot.subject
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded bg-accent px-1.5 py-0.5 text-[11px] font-medium text-accent-foreground",
									children: slot.venue
								}),
								showSection ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: slot.section
								}) : null,
								showFaculty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: slot.faculty
								}) : null
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "-"
						})
					}, p);
				})]
			}, day)) })]
		})
	});
}
//#endregion
export { TimetableGrid as t };
