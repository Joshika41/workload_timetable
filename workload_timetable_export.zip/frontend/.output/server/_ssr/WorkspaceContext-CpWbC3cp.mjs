import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/WorkspaceContext-CpWbC3cp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WorkspaceContext = (0, import_react.createContext)(void 0);
function WorkspaceProvider({ children }) {
	const [activeDepartmentId, setActiveDepartmentIdState] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return null;
		const saved = localStorage.getItem("workspace_dept_id");
		return saved ? parseInt(saved, 10) : null;
	});
	const [activeDepartmentName, setActiveDepartmentNameState] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return null;
		return localStorage.getItem("workspace_dept_name") || null;
	});
	const [programType, setProgramTypeState] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return "UG";
		return localStorage.getItem("workspace_prog") || "UG";
	});
	const [semesterType, setSemesterTypeState] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return "Odd";
		return localStorage.getItem("workspace_sem") || "Odd";
	});
	const [isAllocationLocked, setIsAllocationLockedState] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return false;
		return localStorage.getItem("workspace_locked") === "true";
	});
	const setActiveDepartmentId = (id) => {
		setActiveDepartmentIdState(id);
		if (typeof window !== "undefined") if (id) localStorage.setItem("workspace_dept_id", id.toString());
		else localStorage.removeItem("workspace_dept_id");
	};
	const setActiveDepartmentName = (name) => {
		setActiveDepartmentNameState(name);
		if (typeof window !== "undefined") if (name) localStorage.setItem("workspace_dept_name", name);
		else localStorage.removeItem("workspace_dept_name");
	};
	const setProgramType = (type) => {
		setProgramTypeState(type);
		if (typeof window !== "undefined") localStorage.setItem("workspace_prog", type);
	};
	const setSemesterType = (type) => {
		setSemesterTypeState(type);
		if (typeof window !== "undefined") localStorage.setItem("workspace_sem", type);
	};
	const setIsAllocationLocked = (locked) => {
		setIsAllocationLockedState(locked);
		if (typeof window !== "undefined") localStorage.setItem("workspace_locked", locked.toString());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceContext.Provider, {
		value: {
			activeDepartmentId,
			setActiveDepartmentId,
			activeDepartmentName,
			setActiveDepartmentName,
			programType,
			setProgramType,
			semesterType,
			setSemesterType,
			isAllocationLocked,
			setIsAllocationLocked
		},
		children
	});
}
function useWorkspace() {
	const context = (0, import_react.useContext)(WorkspaceContext);
	if (context === void 0) throw new Error("useWorkspace must be used within a WorkspaceProvider");
	return context;
}
//#endregion
export { useWorkspace as n, WorkspaceProvider as t };
