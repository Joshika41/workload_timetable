from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session
from typing import List, Dict, Any
from app.database.connection import get_db
from app.models.domain import User, RoleEnum, FacultyProfile, PolicyConfig
from app.auth.dependencies import require_role, get_current_user
from app.services.workload_service import WorkloadService
from app.services.pdf_service import PDFService
from app.auth.workspace_auth import verify_workspace_access
from app.core.workspace import WorkspaceContext
import json

router = APIRouter()
workload_service = WorkloadService()
pdf_service = PDFService()

@router.get("/faculty")
def get_faculty_workload(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Faculty-centric workload from FINALIZED allocations."""
    return workload_service.get_faculty_workload(db, current_user.department_id, workspace_id)

@router.get("/class-matrix")
def get_class_matrix(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Section-centric class matrix from FINALIZED allocations."""
    return workload_service.get_class_matrix(db, workspace_id)

@router.get("/my-subjects")
def get_my_subjects(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.FACULTY.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Faculty member's finalized subject assignments."""
    if not current_user.faculty_profile:
        return []
    return workload_service.get_faculty_subjects(db, current_user.faculty_profile.id, workspace_id)

@router.get("/export.pdf")
def export_workload_pdf(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Export finalized workload to PDF."""
    pdf_bytes = pdf_service.generate_workload_pdf(db, workspace_id, current_user.department_id)
    return Response(content=pdf_bytes, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=workload_{workspace_id}.pdf"})

@router.get("/settings/caps")
def get_workload_caps(
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value]))
):
    """Get hour caps from PolicyConfig."""
    caps = db.query(PolicyConfig).filter(PolicyConfig.scope == "WORKLOAD_CAPS").all()
    result = {}
    for cap in caps:
        result[cap.key] = float(cap.value)
    if not result: # Defaults
        result = {"max_professor": 12, "max_associate": 14, "max_assistant": 16, "incharge_reduction": 2}
    return result

@router.post("/settings/caps")
def update_workload_caps(
    caps_data: Dict[str, Any],
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value]))
):
    """Update hour caps in PolicyConfig."""
    for key, value in caps_data.items():
        cap = db.query(PolicyConfig).filter(PolicyConfig.scope == "WORKLOAD_CAPS", PolicyConfig.key == key).first()
        if cap:
            cap.value = str(value)
        else:
            new_cap = PolicyConfig(key=key, scope="WORKLOAD_CAPS", value=str(value))
            db.add(new_cap)
    return {"message": "Caps updated successfully"}

@router.post("/finalize")
def finalize_workload(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Snapshot current workload and move workspace state to FINALIZED."""
    # Assuming workload_service has a method or we do it here. Let's do it in the router for simplicity.
    from app.models.domain import AcademicWorkspace, WorkspaceWorkflowStateEnum, WorkloadVersion
    from app.services.workload_service import WorkloadService
    
    ws = db.query(AcademicWorkspace).filter(AcademicWorkspace.id == workspace_id).first()
    if ws.workflow_state == WorkspaceWorkflowStateEnum.FINALIZED:
        return {"message": "Already finalized"}
        
    # Generate snapshot
    snapshot_data = workload_service.get_faculty_workload(db, current_user.department_id, workspace_id)
    
    # Save snapshot version
    version = ws.version + 1 if ws.version else 1
    snapshot = WorkloadVersion(
        workspace_id=workspace_id,
        version_no=version,
        snapshot_json=json.dumps(snapshot_data),
        reason="HOD Finalization"
    )
    db.add(snapshot)
    
    # Update workspace state
    ws.workflow_state = WorkspaceWorkflowStateEnum.FINALIZED
    ws.version = version
    db.commit()
    return {"message": "Workload finalized successfully", "version": version}

@router.post("/reopen")
def reopen_workload(
    workspace_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role([RoleEnum.HOD.value, RoleEnum.ERP_COORDINATOR.value])),
    workspace: WorkspaceContext = Depends(verify_workspace_access)
):
    """Reopen a finalized workload, returning to ALLOCATION state."""
    from app.models.domain import AcademicWorkspace, WorkspaceWorkflowStateEnum
    
    ws = db.query(AcademicWorkspace).filter(AcademicWorkspace.id == workspace_id).first()
    if ws.workflow_state != WorkspaceWorkflowStateEnum.FINALIZED:
        return {"message": "Workspace is not finalized"}
        
    ws.workflow_state = WorkspaceWorkflowStateEnum.ALLOCATION
    db.commit()
    return {"message": "Workload reopened successfully"}
