import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from '@/api/client';
import { authApi } from '@/api/index';
import { toast } from 'sonner';

export interface ERPContext {
  departmentId: number;
  departmentName: string;
  programmeId: number;
  programmeName: string;
  programmeType: string; // UG or PG
  semesterType: 'ODD' | 'EVEN';
  academicYear: string;
}

export interface ERPSession {
  token: string;
  role: 'HOD' | 'FACULTY' | 'ERP_COORDINATOR' | 'MASTER_ADMIN';
  name: string;
  userId: number;
  facultyProfileId: number | null;
  context: ERPContext;
}

interface AuthContextType {
  session: ERPSession | null;
  isLoading: boolean;
  demoLogin: (params: {
    role: string;
    departmentId: number;
    departmentName: string;
    programmeId: number;
    programmeName: string;
    programmeType: string;
    semesterType: 'ODD' | 'EVEN';
    facultyId?: number;
  }) => Promise<void>;
  logOut: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Legacy compat - old code may check these
export type { AuthContextType };

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<ERPSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    const stored = localStorage.getItem('erp_session');
    if (token && stored) {
      try {
        const s = JSON.parse(stored) as ERPSession;
        setSession(s);
        apiClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      } catch {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('erp_session');
      }
    }
    setIsLoading(false);
  }, []);

  const demoLogin = async (params: {
    role: string;
    departmentId: number;
    departmentName: string;
    programmeId: number;
    programmeName: string;
    programmeType: string;
    semesterType: 'ODD' | 'EVEN';
    facultyId?: number;
  }) => {
    try {
      const response = await authApi.demoLogin({
        role: params.role,
        department_id: params.departmentId,
        programme_id: params.programmeId,
        semester_type: params.semesterType,
        faculty_id: params.facultyId,
      });

      const newSession: ERPSession = {
        token: response.access_token,
        role: response.role,
        name: response.name || `Demo ${params.role}`,
        userId: response.user_id,
        facultyProfileId: response.faculty_profile_id || null,
        context: {
          departmentId: params.departmentId,
          departmentName: params.departmentName,
          programmeId: params.programmeId,
          programmeName: params.programmeName,
          programmeType: params.programmeType,
          semesterType: params.semesterType,
          academicYear: '2026-27',
        },
      };

      setSession(newSession);
      localStorage.setItem('auth_token', response.access_token);
      localStorage.setItem('erp_session', JSON.stringify(newSession));
      apiClient.defaults.headers.common['Authorization'] = `Bearer ${response.access_token}`;

      toast.success(`Welcome, ${newSession.name}!`);

      if (response.role === 'HOD' || response.role === 'ERP_COORDINATOR') {
        navigate('/hod');
      } else {
        navigate('/faculty');
      }
    } catch (err: any) {
      const msg = err.response?.data?.detail || 'Login failed. Please try again.';
      toast.error(msg);
      throw err;
    }
  };

  const logOut = () => {
    setSession(null);
    localStorage.removeItem('auth_token');
    localStorage.removeItem('erp_session');
    delete apiClient.defaults.headers.common['Authorization'];
    navigate('/');
    toast.info('Logged out successfully.');
  };

  return (
    <AuthContext.Provider value={{ session, isLoading, demoLogin, logOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

// Legacy compat aliases
export const useSession = useAuth;
