import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { $ as ArrowLeft, J as Briefcase, M as Download, Y as BookOpen, d as Search, g as Plus, h as Printer, j as Eye, n as Users, o as Trash2 } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as WorkloadShell, r as DialogDescription, t as Dialog } from "./WorkloadShell-D3nMknTh.mjs";
import { t as WorkloadStatusBadge } from "./WorkloadStatusBadge-BmjEjhsL.mjs";
import { n as exportFacultyWorkloadToExcel } from "./excel-export-BRKgErUs.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.workload-BBlYsiCt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminWorkloadSheetsPage() {
	const { allWorkloads, allocations, facultyList, campusWorkList, addCampusWork, removeCampusWork, updateFacultyDefaultHours } = useWorkloadData();
	const [activeSheetTab, setActiveSheetTab] = (0, import_react.useState)("faculty-ledger");
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [programmeFilter, setProgrammeFilter] = (0, import_react.useState)("ALL");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("ALL");
	const [isCampusWorkModalOpen, setIsCampusWorkModalOpen] = (0, import_react.useState)(false);
	const [campusFacultyId, setCampusFacultyId] = (0, import_react.useState)(facultyList[0]?.id || "FAC001");
	const [campusHours, setCampusHours] = (0, import_react.useState)(4);
	const [campusDescription, setCampusDescription] = (0, import_react.useState)("Department Administration");
	const [selectedFacultyId, setSelectedFacultyId] = (0, import_react.useState)(null);
	const selectedWorkload = allWorkloads.find((w) => w.facultyId === selectedFacultyId);
	const [editingTargetHours, setEditingTargetHours] = (0, import_react.useState)(null);
	const filteredWorkloads = allWorkloads.filter((w) => {
		const matchesSearch = w.facultyName.toLowerCase().includes(searchTerm.toLowerCase()) || w.facultyId.toLowerCase().includes(searchTerm.toLowerCase()) || w.designation.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesProg = programmeFilter === "ALL" || w.programme === programmeFilter;
		const matchesStatus = statusFilter === "ALL" || w.status === statusFilter;
		return matchesSearch && matchesProg && matchesStatus;
	});
	const handleExportFaculty = () => {
		exportFacultyWorkloadToExcel(allWorkloads);
		toast.success("Faculty Workload Excel sheet exported successfully!");
	};
	const handlePrint = () => {
		window.print();
	};
	const handleSaveCampusWork = () => {
		if (!campusFacultyId || campusHours <= 0 || !campusDescription.trim()) {
			toast.error("Please enter valid campus work hours and description");
			return;
		}
		addCampusWork({
			facultyId: campusFacultyId,
			hours: campusHours,
			description: campusDescription.trim()
		});
		const fac = facultyList.find((f) => f.id === campusFacultyId);
		toast.success(`Added ${campusHours}h campus work for ${fac?.name}`);
		setIsCampusWorkModalOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "admin",
		title: "Faculty Workload Ledger & Reports",
		subtitle: "Complete institutional workload ledger including teaching allocations, campus work, and live reconciliation",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "ghost",
					onClick: () => window.history.back(),
					className: "h-8 gap-1 text-xs text-slate-500 hover:text-slate-800 border border-slate-200 bg-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Back" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setIsCampusWorkModalOpen(true),
					className: "h-8 gap-1.5 text-xs bg-teal-700 hover:bg-teal-800 text-white font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Add Campus Work" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: handlePrint,
					className: "h-8 gap-1 text-xs border-slate-300 bg-white hover:bg-slate-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-3.5 text-slate-700" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden sm:inline",
						children: "Print / PDF"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: handleExportFaculty,
					className: "h-8 gap-1.5 text-xs bg-[#002147] text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-3.5 text-teal-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Export Workload (.xlsx)" })]
				})
			]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveSheetTab("faculty-ledger"),
						className: `px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 ${activeSheetTab === "faculty-ledger" ? "bg-[#002147] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }), "Faculty Workload Ledger"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveSheetTab("official-sheet"),
						className: `px-3 py-1.5 rounded-md text-xs font-bold transition-all flex items-center gap-1.5 ${activeSheetTab === "official-sheet" ? "bg-[#002147] text-white shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-3.5" }), "Official Workload Statement"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 w-full sm:w-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative flex-1 sm:w-48",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "Search faculty name...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "h-8 pl-7 text-xs bg-slate-50"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: programmeFilter,
							onChange: (e) => setProgrammeFilter(e.target.value),
							className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ALL",
									children: "All Programmes"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "MCA",
									children: "MCA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "MCA GEN AI",
									children: "MCA GEN AI"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: statusFilter,
							onChange: (e) => setStatusFilter(e.target.value),
							className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ALL",
									children: "All Statuses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "UNDERLOADED",
									children: "Underloaded"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "BALANCED",
									children: "Balanced"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "OVERLOADED",
									children: "Overloaded"
								})
							]
						})
					]
				})]
			}),
			activeSheetTab === "faculty-ledger" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-bold text-slate-800 uppercase tracking-wider",
						children: "Faculty Workload Master Ledger"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-slate-500",
						children: ["Formula: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-blue-900",
							children: "Total Credited = Teaching Hours + Campus Work Hours"
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-mono text-slate-500 font-bold",
						children: [filteredWorkloads.length, " Faculty Records"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border-collapse min-w-[1000px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center w-12",
									children: "S.No"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5",
									children: "Faculty Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5",
									children: "Designation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Target Hours"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Teaching Hours"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Campus Work"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Total Credited"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Remaining"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Excess"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Utilization %"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-center",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3.5 py-2.5 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-slate-200",
							children: filteredWorkloads.map((w, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								onClick: () => setSelectedFacultyId(w.facultyId),
								className: "hover:bg-blue-50/40 transition-colors cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center font-bold text-slate-700 font-mono",
										children: idx + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 font-bold text-slate-900",
										children: [w.facultyName, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "block text-[10px] text-slate-500 font-mono font-normal",
											children: [
												w.facultyId,
												" · ",
												w.programme
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-slate-600",
										children: w.designation
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-bold text-slate-700",
										children: [w.defaultHours, "h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-semibold text-blue-800",
										children: [w.teachingHours, "h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-semibold text-teal-700",
										children: w.campusWorkHours > 0 ? `${w.campusWorkHours}h` : "-"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-black text-slate-900 bg-slate-50",
										children: [w.allocatedHours, "h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-bold text-amber-700",
										children: [w.remainingHours, "h"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-bold text-rose-700",
										children: w.overloadHours > 0 ? `+${w.overloadHours}h` : "0h"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3.5 py-2.5 text-center font-mono font-bold text-slate-800",
										children: [w.utilizationPercentage, "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
											status: w.status,
											size: "sm"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3.5 py-2.5 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "ghost",
											onClick: (e) => {
												e.stopPropagation();
												setSelectedFacultyId(w.facultyId);
											},
											className: "h-7 px-2.5 text-xs text-blue-700 hover:bg-blue-100",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3.5 mr-1" }), " View Breakdown"]
										})
									})
								]
							}, w.facultyId))
						})]
					})
				})]
			}),
			activeSheetTab === "official-sheet" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden p-6 space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-1 border-b pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-bold text-sm text-slate-800 tracking-wider uppercase",
							children: "SRM INSTITUTE OF SCIENCE AND TECHNOLOGY"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-base text-[#002147]",
							children: "DEPARTMENT OF COMPUTER APPLICATIONS — MCA & MCA GEN AI"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 font-medium",
							children: "FACULTY-WISE TEACHING WORKLOAD STATEMENT · ODD SEMESTER 2026-2027"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-xs text-left border border-slate-300 border-collapse min-w-[900px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-slate-100 text-[11px] font-bold text-slate-800 border-b border-slate-300 uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2 text-center w-12",
									children: "S.No"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2",
									children: "Staff Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2",
									children: "Subject Code"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2",
									children: "Course Name"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2",
									children: "Class / Sec"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2 text-center",
									children: "Theory"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2 text-center",
									children: "Practical"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "border border-slate-300 px-3 py-2 text-center",
									children: "Credited"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filteredWorkloads.map((faculty, fIdx) => {
							const subjectRows = faculty.allocatedSubjects;
							const rowCount = Math.max(1, subjectRows.length);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "border-b-2 border-slate-300",
								children: [subjectRows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "border border-slate-300 px-3 py-2 text-center font-bold text-slate-700",
										children: fIdx + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "border border-slate-300 px-3 py-2 font-bold text-slate-900",
										children: faculty.facultyName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										colSpan: 6,
										className: "border border-slate-300 px-3 py-2 text-center text-slate-400 italic",
										children: "No teaching courses assigned"
									})
								] }) : subjectRows.map((sub, sIdx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-slate-50",
									children: [
										sIdx === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											rowSpan: rowCount,
											className: "border border-slate-300 px-3 py-2 text-center font-bold text-slate-700 align-top bg-slate-50/50",
											children: fIdx + 1
										}),
										sIdx === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											rowSpan: rowCount,
											className: "border border-slate-300 px-3 py-2 font-bold text-slate-900 align-top bg-slate-50/50",
											children: [faculty.facultyName, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block text-[10px] text-slate-500 font-normal",
												children: faculty.designation
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 font-mono font-bold text-blue-700",
											children: sub.courseCode
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 font-semibold text-slate-800",
											children: sub.courseTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 font-medium text-slate-700",
											children: sub.section
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono",
											children: sub.theoryHours
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono",
											children: sub.practicalHours
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono font-bold text-slate-900 bg-slate-50",
											children: sub.totalHours
										})
									]
								}, sIdx)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "bg-slate-100 font-bold text-slate-900 text-[11px]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											colSpan: 5,
											className: "border border-slate-300 px-3 py-2 text-right uppercase",
											children: [
												"TOTAL FOR ",
												faculty.facultyName,
												" (TARGET: ",
												faculty.defaultHours,
												"H)"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono",
											children: faculty.theoryHours
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono",
											children: faculty.practicalHours
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "border border-slate-300 px-3 py-2 text-center font-mono font-black text-blue-900 bg-blue-100",
											children: [faculty.allocatedHours, " hrs"]
										})
									]
								})]
							}, faculty.facultyId);
						}) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: !!selectedFacultyId,
				onOpenChange: (open) => !open && setSelectedFacultyId(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-base font-extrabold text-slate-900",
							children: selectedWorkload?.facultyName
						}), selectedWorkload && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, { status: selectedWorkload.status })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
						selectedWorkload?.designation,
						" · ",
						selectedWorkload?.programme,
						" · ID: ",
						selectedWorkload?.facultyId
					] })] }), selectedWorkload && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-4 gap-2 bg-slate-50 p-3 rounded-lg border border-slate-200 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Target Workload"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-slate-800",
										children: [selectedWorkload.defaultHours, " hrs"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Teaching Hours"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-blue-700",
										children: [selectedWorkload.teachingHours, " hrs"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Campus Work"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-teal-700",
										children: [selectedWorkload.campusWorkHours, " hrs"]
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] uppercase font-bold text-slate-400",
										children: "Total Credited"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-lg font-black text-slate-900",
										children: [selectedWorkload.allocatedHours, " hrs"]
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-bold uppercase tracking-wider text-slate-600 text-[11px]",
									children: "TEACHING ALLOCATION"
								}), selectedWorkload.allocatedSubjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "p-3 bg-slate-50 border rounded text-slate-400 text-center italic",
									children: "No teaching subjects assigned."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100",
									children: selectedWorkload.allocatedSubjects.map((sub, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 flex items-center justify-between hover:bg-slate-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded text-[10px] mr-2",
												children: sub.courseCode
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-slate-900",
												children: sub.courseTitle
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[11px] text-slate-500 mt-0.5",
												children: [
													"Section: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sub.section }),
													" · Role: ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: sub.role })
												]
											})
										] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-bold text-slate-900 text-xs",
												children: [
													sub.theoryHours,
													"h (T) + ",
													sub.practicalHours,
													"h (P)"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-slate-500 font-bold",
												children: [
													"Total: ",
													sub.totalHours,
													" hrs"
												]
											})]
										})]
									}, i))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 pt-2 border-t",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "font-bold uppercase tracking-wider text-teal-800 text-[11px]",
										children: "CAMPUS WORK RESPONSIBILITIES"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => {
											setCampusFacultyId(selectedWorkload.facultyId);
											setIsCampusWorkModalOpen(true);
										},
										className: "h-6 px-2 text-[11px] border-teal-300 text-teal-800 bg-teal-50",
										children: "+ Add Campus Work"
									})]
								}), selectedWorkload.campusWorkEntries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "p-3 bg-slate-50 border rounded text-slate-400 text-center italic",
									children: "No administrative or campus work duties assigned."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "border border-slate-200 rounded-lg overflow-hidden divide-y divide-slate-100",
									children: selectedWorkload.campusWorkEntries.map((cw) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-2.5 flex items-center justify-between bg-teal-50/30",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-bold text-slate-900",
											children: cw.description
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] text-teal-700",
											children: "Institutional / Department Duty"
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-extrabold text-teal-900",
												children: [cw.hours, " hrs"]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => {
													removeCampusWork(cw.id);
													toast.success("Campus work entry removed");
												},
												className: "p-1 text-slate-400 hover:text-rose-600 rounded",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
											})]
										})]
									}, cw.id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 bg-slate-900 text-white rounded-lg flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Target: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [selectedWorkload.defaultHours, "h"] }),
									" · Credited: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [selectedWorkload.allocatedHours, "h"] })
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-teal-300",
									children: selectedWorkload.remainingHours > 0 ? `${selectedWorkload.remainingHours}h UNDERLOADED` : selectedWorkload.overloadHours > 0 ? `+${selectedWorkload.overloadHours}h OVERLOADED` : "✓ RECONCILED & BALANCED"
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isCampusWorkModalOpen,
				onOpenChange: setIsCampusWorkModalOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "sm:max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "flex items-center gap-2 text-teal-800",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-5 text-teal-600" }), " Add Campus Work Responsibility"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Campus work hours contribute to total credited workload (e.g. HOD duties, committee work, examination work)." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-700 mb-1",
								children: "Select Faculty Member"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: campusFacultyId,
								onChange: (e) => setCampusFacultyId(e.target.value),
								className: "w-full h-8 rounded border border-slate-200 bg-white px-2 text-xs font-semibold",
								children: facultyList.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: f.id,
									children: [
										f.name,
										" (",
										f.designation,
										")"
									]
								}, f.id))
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-700 mb-1",
								children: "Campus Work Hours"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: campusHours,
								onChange: (e) => setCampusHours(Number(e.target.value)),
								className: "h-8 text-xs font-mono font-bold"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "block text-[11px] font-bold text-slate-700 mb-1",
								children: "Campus Work Description / Remark"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: campusDescription,
								onChange: (e) => setCampusDescription(e.target.value),
								placeholder: "e.g., Department Administration, Placement Officer",
								className: "h-8 text-xs"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "pt-3 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => setIsCampusWorkModalOpen(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: handleSaveCampusWork,
									className: "bg-teal-700 hover:bg-teal-800 text-white font-bold",
									children: "Save Campus Work"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { AdminWorkloadSheetsPage as component };
