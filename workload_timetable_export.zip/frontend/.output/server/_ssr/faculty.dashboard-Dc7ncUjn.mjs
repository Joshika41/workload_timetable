import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { E as Info, R as CircleCheck, X as ArrowUp, Y as BookOpen, c as SlidersHorizontal, d as Search, et as ArrowDown, g as Plus, k as GraduationCap, o as Trash2, s as Sparkles, u as Send } from "../_libs/lucide-react.mjs";
import { o as WorkloadShell, s as apiClient } from "./WorkloadShell-D3nMknTh.mjs";
import { t as WorkloadStatusBadge } from "./WorkloadStatusBadge-BmjEjhsL.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
import { t as COURSE_CATEGORIES } from "./workload-types-BTjWZ-Y7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faculty.dashboard-Dc7ncUjn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var preferenceApi = {
	getFacultyPreferences: async () => {
		return (await apiClient.get("/faculty/preferences")).data;
	},
	submitPreferences: async (data) => {
		return (await apiClient.post("/faculty/preferences", data)).data;
	},
	getAllPreferences: async () => {
		return (await apiClient.get("/coordinator/preferences")).data;
	},
	decidePreference: async (itemId, data) => {
		return (await apiClient.patch(`/coordinator/preferences/${itemId}`, data)).data;
	}
};
function FacultyDashboardPage() {
	const { facultyList, currentFacultyId, setCurrentFacultyId, currentFaculty, currentFacultyWorkload, currentFacultyPreferences, courseList, submitFacultyPreferences } = useWorkloadData();
	const [activeTab, setActiveTab] = (0, import_react.useState)(currentFacultyPreferences?.status === "SUBMITTED" ? "overview" : "preferences");
	const [searchTerm, setSearchTerm] = (0, import_react.useState)("");
	const [selectedCategoryFilter, setSelectedCategoryFilter] = (0, import_react.useState)("ALL");
	const [cart, setCart] = (0, import_react.useState)([]);
	const [prefStatus, setPrefStatus] = (0, import_react.useState)("PENDING");
	(0, import_react.useEffect)(() => {
		preferenceApi.getFacultyPreferences().then((res) => {
			if (res && res.length > 0) {
				const sub = res[0];
				setPrefStatus(sub.status);
				if (sub.status === "SUBMITTED") setActiveTab("overview");
				setCart(sub.items.map((i) => ({
					courseCode: i.course_code,
					rank: i.preference_rank
				})));
			}
		}).catch(console.error);
	}, []);
	const faculty = currentFaculty;
	const workload = currentFacultyWorkload;
	const availableCourses = courseList.filter((c) => {
		const matchesProgramme = c.programme === (faculty?.programme || "MCA");
		const matchesSearch = c.code.toLowerCase().includes(searchTerm.toLowerCase()) || c.title.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesCat = selectedCategoryFilter === "ALL" || c.category === selectedCategoryFilter;
		return matchesProgramme && matchesSearch && matchesCat;
	});
	const categoriesList = [
		"C",
		"D",
		"G",
		"S",
		"P",
		"AE"
	];
	const handleAddPreference = (courseCode) => {
		if (cart.some((item) => item.courseCode === courseCode)) {
			toast.info("Subject is already in your preferences list");
			return;
		}
		if (cart.length >= 5) {
			toast.warning("You can select a maximum of 5 ranked preferences");
			return;
		}
		const newRank = cart.length + 1;
		setCart((prev) => [...prev, {
			courseCode,
			rank: newRank
		}]);
		toast.success(`Added ${courseCode} as Preference #${newRank}`);
	};
	const handleRemovePreference = (courseCode) => {
		setCart((prev) => {
			return prev.filter((item) => item.courseCode !== courseCode).map((item, idx) => ({
				...item,
				rank: idx + 1
			}));
		});
	};
	const handleMoveRank = (index, direction) => {
		if (direction === "up" && index === 0) return;
		if (direction === "down" && index === cart.length - 1) return;
		const targetIndex = direction === "up" ? index - 1 : index + 1;
		const itemA = cart[index];
		const itemB = cart[targetIndex];
		if (!itemA || !itemB) return;
		const newCart = [...cart];
		newCart[index] = itemB;
		newCart[targetIndex] = itemA;
		const reordered = newCart.map((item, idx) => ({
			...item,
			rank: idx + 1
		}));
		setCart(reordered);
	};
	const handleSubmitPreferences = async () => {
		if (cart.length === 0) {
			toast.error("Please select at least 1 subject preference before submitting.");
			return;
		}
		try {
			const items = cart.map((c) => ({
				course_code: c.courseCode,
				preference_rank: c.rank
			}));
			await preferenceApi.submitPreferences({
				academic_workspace_id: 1,
				items
			});
			toast.success("Subject preferences submitted successfully to HOD!");
			setPrefStatus("SUBMITTED");
			setActiveTab("overview");
		} catch (e) {
			toast.error("Failed to submit preferences");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WorkloadShell, {
		role: "faculty",
		title: "Faculty Portal",
		subtitle: `Academic Year 2026-2027 · ${faculty?.programme || "MCA"} Department`,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: activeTab === "preferences" ? "default" : "outline",
				onClick: () => setActiveTab("preferences"),
				className: `text-xs h-8 ${activeTab === "preferences" ? "bg-[#002147] text-white font-bold" : "bg-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-3.5 mr-1.5 text-teal-400" }), "Subject Preference Form (1 to 5)"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: activeTab === "overview" ? "default" : "outline",
				onClick: () => setActiveTab("overview"),
				className: `text-xs h-8 ${activeTab === "overview" ? "bg-[#002147] text-white font-bold" : "bg-white"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5 mr-1.5" }), "My Allotted Workload & Classes"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-[#002147] text-white p-6 shadow-md border border-blue-900/60 relative overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "px-2 py-0.5 text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded uppercase tracking-wider",
									children: "Faculty Workspace · Willingness Collection"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-blue-200",
									children: ["ID: ", faculty?.id]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-2xl font-bold tracking-tight text-white",
								children: ["Welcome, ", faculty?.name]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-blue-200/90 pt-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Designation:" }),
										" ",
										faculty?.designation
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Programme:" }),
										" ",
										faculty?.programme
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Academic Year:" }), " 2026-2027"] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Semester:" }), " Odd Semester"] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-blue-200 font-semibold",
									children: "Switch Faculty View:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: currentFacultyId,
									onChange: (e) => setCurrentFacultyId(e.target.value),
									className: "h-7 rounded border border-blue-400/50 bg-blue-950 text-white text-xs px-2 font-medium",
									children: facultyList.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: f.id,
										className: "bg-slate-900 text-white",
										children: [
											f.name,
											" (",
											f.designation,
											" · ",
											f.defaultWorkloadHours,
											"h)"
										]
									}, f.id))
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg border border-white/10 shrink-0 text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase font-bold text-teal-300",
							children: "Preference Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, {
								status: prefStatus,
								size: "default"
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-500",
								children: "Default Hours"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-slate-900 mt-1",
								children: workload?.defaultHours || 18
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-400 mt-0.5",
								children: "Institutional Standard"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-blue-700",
								children: "Allocated Hours"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-blue-700 mt-1",
								children: workload?.allocatedHours || 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-[11px] text-slate-400 mt-0.5",
								children: [
									workload?.theoryHours || 0,
									"h Theory + ",
									workload?.practicalHours || 0,
									"h Lab"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-amber-700",
								children: "Remaining Hours"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-3xl font-black text-amber-600 mt-1",
								children: workload?.remainingHours || 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-400 mt-0.5",
								children: "Underload buffer"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col justify-between",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-bold uppercase tracking-wider text-slate-500",
								children: "Workload Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "my-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkloadStatusBadge, { status: workload?.status || "UNDERLOADED" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-400",
								children: workload?.status === "UNDERLOADED" ? "4 hours below default capacity" : workload?.status === "BALANCED" ? "Meets capacity requirements" : "Overload assigned"
							})
						]
					})
				]
			}),
			activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 bg-white p-5 shadow-sm space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-b pb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4 text-teal-600" }), "My Preferences"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 mt-0.5",
							children: "Your submitted subject preferences ranked in order of priority (1 to 5)."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setActiveTab("preferences"),
							className: "text-xs h-7 gap-1 text-[#002147] border-blue-300 bg-blue-50/50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Edit Preferences" })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-2 sm:grid-cols-2 lg:grid-cols-4",
						children: cart.map((pref, idx) => {
							const course = courseList.find((c) => c.code === pref.courseCode);
							const catInfo = course ? COURSE_CATEGORIES[course.category] : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3.5 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-blue-300 transition-all flex flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-6 rounded-full bg-[#002147] text-white font-bold text-xs flex items-center justify-center",
											children: pref.rank
										}), catInfo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `px-2 py-0.5 text-[10px] font-bold rounded ${catInfo.badgeColor}`,
											children: catInfo.name
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs font-bold text-blue-700",
										children: pref.courseCode
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-semibold text-xs text-slate-900 mt-1 leading-snug",
										children: course?.title || pref.courseCode
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 pt-2 border-t border-slate-200 text-[11px] text-slate-500 flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"L: ",
										course?.theoryHours_L || 3,
										" P: ",
										course?.practicalHours_P || 2
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-slate-700",
										children: ["Credits: ", course?.credits_C || 4]
									})]
								})]
							}, pref.courseCode);
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4 text-[#002147]" }), "My Allocated Subjects"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 mt-0.5",
							children: "Official subjects allocated by the Head of Department for this academic session."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold px-2.5 py-1 rounded bg-teal-50 text-teal-800 border border-teal-200",
							children: [workload?.allocatedCoursesCount || 0, " Assigned Courses"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-xs text-left border-collapse",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-[11px] font-bold text-slate-600 bg-slate-100 uppercase border-b border-slate-200",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Subject Code"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Subject Name"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Section"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-center",
										children: "Students"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-center",
										children: "Role"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-center",
										children: "Theory"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-center",
										children: "Practical"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-center",
										children: "Total Hours"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
								className: "divide-y divide-slate-200",
								children: !workload?.allocatedSubjects || workload.allocatedSubjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 8,
									className: "py-8 text-center text-slate-500",
									children: "No subjects currently allocated by HOD."
								}) }) : workload.allocatedSubjects.map((sub, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "hover:bg-slate-50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-mono font-bold text-blue-700",
											children: sub.courseCode
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-semibold text-slate-900",
											children: sub.courseTitle
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 font-medium text-slate-700",
											children: sub.section
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center text-slate-600",
											children: sub.studentCount
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border",
												children: sub.role
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-semibold text-slate-800",
											children: [sub.theoryHours, " hrs"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-3 text-center font-mono font-semibold text-slate-800",
											children: [sub.practicalHours, " hrs"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-3 text-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "px-2 py-0.5 rounded font-mono font-bold text-blue-900 bg-blue-50 border border-blue-200",
												children: [sub.totalHours, " hrs"]
											})
										})
									]
								}, i))
							})]
						})
					})]
				})]
			}),
			activeTab === "preferences" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-bold text-slate-900 uppercase tracking-wider",
							children: "Available Syllabus Curriculum"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500",
							children: "Select subjects according to your teaching expertise from SRM 2025 Syllabus."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 w-full sm:w-auto",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex-1 sm:w-48",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 size-3 text-slate-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Search subject...",
									value: searchTerm,
									onChange: (e) => setSearchTerm(e.target.value),
									className: "h-8 pl-7 text-xs bg-slate-50 rounded-md"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: selectedCategoryFilter,
								onChange: (e) => setSelectedCategoryFilter(e.target.value),
								className: "h-8 rounded-md border border-slate-200 bg-slate-50 px-2 text-xs text-slate-700",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "ALL",
										children: "All Categories"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "C",
										children: "Professional Core (C)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "D",
										children: "Discipline Elective (D)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "G",
										children: "Generic Elective (G)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "S",
										children: "Skill Enhancement (S)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "AE",
										children: "Ability Enhancement (AE)"
									})
								]
							})]
						})]
					}), categoriesList.map((catKey) => {
						const catInfo = COURSE_CATEGORIES[catKey];
						const coursesInCat = availableCourses.filter((c) => c.category === catKey);
						if (coursesInCat.length === 0) return null;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `rounded-xl border ${catInfo.borderLight} bg-white shadow-sm overflow-hidden`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `px-4 py-2.5 ${catInfo.bgLight} border-b ${catInfo.borderLight} flex items-center justify-between`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `px-2 py-0.5 text-xs font-bold rounded ${catInfo.badgeColor}`,
										children: catKey
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: `text-xs font-bold uppercase tracking-wider ${catInfo.textColor}`,
										children: catInfo.name
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[11px] font-medium text-slate-500",
									children: [coursesInCat.length, " subjects"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "p-4 grid gap-3 sm:grid-cols-2",
								children: coursesInCat.map((course) => {
									const isAdded = cart.some((p) => p.courseCode === course.code);
									const currentRank = cart.find((p) => p.courseCode === course.code)?.rank;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `p-3.5 rounded-lg border transition-all flex flex-col justify-between ${isAdded ? "border-teal-400 bg-teal-50/40 ring-1 ring-teal-400" : "border-slate-200 bg-slate-50/50 hover:border-slate-300"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs font-bold text-blue-700 bg-white px-2 py-0.5 rounded border border-slate-200 shadow-2xs",
												children: course.code
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-[11px] font-bold text-slate-500 font-mono",
												children: ["Sem ", course.semester]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "font-bold text-xs text-slate-900 mt-2 leading-snug",
											children: course.title
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 pt-2.5 border-t border-slate-200 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 text-[11px] font-mono text-slate-600",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["L ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: course.theoryHours_L })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["T ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: course.tutorialHours_T })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["P ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: course.practicalHours_P })] }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["C ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: course.credits_C })] })
												]
											}), isAdded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "px-2 py-1 text-[11px] font-bold rounded bg-teal-600 text-white flex items-center gap-1",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "size-3" }),
													"Rank #",
													currentRank
												]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												size: "sm",
												onClick: () => handleAddPreference(course.code),
												className: "h-7 px-2.5 text-xs bg-[#002147] hover:bg-[#001833] text-white",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3 mr-1" }), " Add Preference"]
											})]
										})]
									}, course.code);
								})
							})]
						}, catKey);
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-slate-200 bg-white p-4 shadow-sm sticky top-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-b pb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm font-bold text-slate-900 uppercase tracking-wider",
									children: "Preference Ranking"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-slate-500 mt-0.5",
									children: "Order from 1 (Highest) to 5."
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "px-2 py-0.5 text-xs font-bold rounded-full bg-blue-100 text-blue-800",
									children: [cart.length, " / 5 Selected"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "py-3 space-y-2 max-h-96 overflow-y-auto",
								children: cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-6 text-center text-slate-400 bg-slate-50 rounded-lg border border-dashed",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-6 mx-auto mb-1 opacity-50" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs",
											children: "No subjects selected."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[11px] text-slate-400 mt-0.5",
											children: "Click \"[ Add Preference ]\" on courses to rank them."
										})
									]
								}) : cart.map((item, idx) => {
									const course = courseList.find((c) => c.code === item.courseCode);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-lg border border-slate-200 bg-slate-50/80 flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "size-6 rounded-full bg-[#002147] text-white font-bold text-xs flex items-center justify-center shrink-0",
												children: item.rank
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-mono text-xs font-bold text-blue-700",
												children: item.courseCode
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-semibold text-slate-900 truncate w-36 sm:w-44",
												title: course?.title,
												children: course?.title || item.courseCode
											})] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleMoveRank(idx, "up"),
													disabled: idx === 0,
													className: "p-1 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30",
													title: "Move Up",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleMoveRank(idx, "down"),
													disabled: idx === cart.length - 1,
													className: "p-1 rounded hover:bg-slate-200 text-slate-600 disabled:opacity-30",
													title: "Move Down",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3.5" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => handleRemovePreference(item.courseCode),
													className: "p-1 rounded hover:bg-red-100 text-red-600",
													title: "Remove",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
												})
											]
										})]
									}, item.courseCode);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "p-3 rounded-lg bg-blue-50 border border-blue-200 text-[11px] text-blue-800 leading-relaxed mb-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Note:" }), " Preferences submitted indicate willingness and expertise. Final class & lab allocations are confirmed by the Head of Department."]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: handleSubmitPreferences,
								disabled: cart.length === 0,
								className: "w-full bg-[#002147] hover:bg-[#001833] text-white gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4 text-teal-300" }), "Submit Preferences to HOD"]
							})
						]
					})
				})]
			})
		]
	});
}
//#endregion
export { FacultyDashboardPage as component };
