import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { academicApi, preferencesApi } from '@/api/index';
import { toast } from 'sonner';

interface Subject {
  id: number;
  course_code: string;
  course_name: string;
  category: string;
  theory_hours: number;
  practical_hours: number;
  credits: number;
  total_hours: number;
}

interface WorkspaceInfo {
  workspace_id: string;
  semester: number;
  workflow_state: string;
  is_finalized: boolean;
  subject_count: number;
}

export default function FacultyHome() {
  const { session } = useAuth();
  const [workspaces, setWorkspaces] = useState<WorkspaceInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedWs, setExpandedWs] = useState<string | null>(null);
  const [subjectsMap, setSubjectsMap] = useState<Record<string, Subject[]>>({});
  const [selectedMap, setSelectedMap] = useState<Record<string, number[]>>({});
  const [submittedMap, setSubmittedMap] = useState<Record<string, any>>({});
  const [isSubmitting, setIsSubmitting] = useState<string | null>(null);

  const ctx = session?.context;

  const loadWorkspaces = useCallback(async () => {
    if (!ctx) return;
    setIsLoading(true);
    try {
      const data = await academicApi.getWorkspacesByContext(ctx.programmeId, ctx.semesterType);
      setWorkspaces(data);
    } catch {
      toast.error('Failed to load semester workspaces');
    } finally {
      setIsLoading(false);
    }
  }, [ctx?.programmeId, ctx?.semesterType]);

  useEffect(() => { loadWorkspaces(); }, [loadWorkspaces]);

  const handleExpand = async (ws: WorkspaceInfo) => {
    const wsId = ws.workspace_id;
    if (expandedWs === wsId) { setExpandedWs(null); return; }
    setExpandedWs(wsId);

    if (!subjectsMap[wsId]) {
      try {
        const [subs, myPrefs] = await Promise.all([
          academicApi.getSubjects(wsId),
          preferencesApi.getMyPreferences(wsId).catch(() => []),
        ]);
        setSubjectsMap(p => ({ ...p, [wsId]: subs }));
        if (myPrefs && myPrefs.length > 0) {
          const pref = myPrefs[0];
          setSubmittedMap(p => ({ ...p, [wsId]: pref }));
          const preSelectedIds = (pref.items || []).map((i: any) => i.subject_id);
          setSelectedMap(p => ({ ...p, [wsId]: preSelectedIds }));
        }
      } catch {
        toast.error('Failed to load subjects for this semester');
      }
    }
  };

  const toggleSubject = (wsId: string, subId: number) => {
    const current = selectedMap[wsId] || [];
    if (current.includes(subId)) {
      setSelectedMap(p => ({ ...p, [wsId]: current.filter(id => id !== subId) }));
    } else {
      setSelectedMap(p => ({ ...p, [wsId]: [...current, subId] }));
    }
  };

  const handleSubmit = async (wsId: string) => {
    const selected = selectedMap[wsId] || [];
    if (selected.length === 0) { toast.error('Please select at least one subject.'); return; }

    setIsSubmitting(wsId);
    try {
      await preferencesApi.submitPreferences(wsId, selected.map((id, idx) => ({ subject_id: id, rank: idx + 1 })));
      toast.success('Preferences submitted successfully! ✅');
      // Reload submission status
      const myPrefs = await preferencesApi.getMyPreferences(wsId).catch(() => []);
      if (myPrefs && myPrefs.length > 0) {
        setSubmittedMap(p => ({ ...p, [wsId]: myPrefs[0] }));
      }
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Failed to submit preferences');
    } finally {
      setIsSubmitting(null);
    }
  };

  const getCategoryColor = (cat: string) => {
    const map: Record<string, string> = {
      CORE: 'chip-core', ELECTIVE: 'chip-elective', DISCIPLINE_ELECTIVE: 'chip-elective',
      MINOR: 'chip-lab', MULTIDISCIPLINARY: 'chip-submitted', LAB: 'chip-lab',
      PROJECT: 'chip-not-started',
    };
    return map[cat?.toUpperCase()] || 'chip-not-started';
  };

  if (!ctx) return null;

  return (
    <div className="animate-fade-in">
      {/* Welcome Banner */}
      <div className="welcome-banner" style={{ marginBottom: '28px' }}>
        <p style={{ fontSize: '12px', color: 'rgba(255,255,255,0.5)', marginBottom: '4px', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
          Faculty Portal
        </p>
        <h1 className="welcome-title">Welcome, {session?.name}!</h1>
        <p className="welcome-subtitle">
          {ctx.programmeName} · {ctx.programmeType} · {ctx.semesterType} Semester · AY {ctx.academicYear}
        </p>
        <div className="welcome-meta">
          <span className="welcome-chip">🏛️ {ctx.departmentName}</span>
          <span className="welcome-chip">
            {ctx.semesterType === 'ODD'
              ? (ctx.programmeType === 'PG' ? 'Odd Sem: 1, 3' : 'Odd Sem: 1, 3, 5, 7')
              : (ctx.programmeType === 'PG' ? 'Even Sem: 2, 4' : 'Even Sem: 2, 4, 6, 8')}
          </span>
        </div>
      </div>

      <div className="page-header">
        <div>
          <h2 className="page-title">Subject Preferences</h2>
          <p className="page-subtitle">Select your preferred subjects for each semester and submit them to your HOD. You can edit and resubmit until the HOD finalizes.</p>
        </div>
      </div>

      {isLoading ? (
        Array.from({ length: 3 }).map((_, i) => <div key={i} className="skeleton" style={{ height: 80, marginBottom: 10, borderRadius: 14 }} />)
      ) : workspaces.length === 0 ? (
        <div className="empty-state card card-body">
          <div style={{ fontSize: '40px', marginBottom: '12px' }}>📭</div>
          <h3 className="empty-state-title">No Semester Workspaces</h3>
          <p className="empty-state-desc">No {ctx.semesterType.toLowerCase()} semester workspaces found for {ctx.programmeName}. Please check with your HOD or ERP administrator.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {workspaces.map(ws => {
            const isExpanded = expandedWs === ws.workspace_id;
            const subjects = subjectsMap[ws.workspace_id] || [];
            const selected = selectedMap[ws.workspace_id] || [];
            const submitted = submittedMap[ws.workspace_id];
            const isFinalized = ws.workflow_state === 'FINALIZED';

            return (
              <div key={ws.workspace_id} className="card" style={{ overflow: 'hidden' }}>
                {/* Card Header */}
                <div
                  onClick={() => handleExpand(ws)}
                  style={{ padding: '18px 22px', display: 'flex', alignItems: 'center', gap: '16px', cursor: 'pointer', background: isExpanded ? '#F0F7FF' : 'white' }}
                >
                  <div style={{ width: 52, height: 52, borderRadius: '14px', background: '#EFF6FF', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <span style={{ fontSize: '11px', fontWeight: 700, color: '#94A3B8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>SEM</span>
                    <span style={{ fontSize: '22px', fontWeight: 900, color: '#002147', lineHeight: 1 }}>{ws.semester}</span>
                  </div>

                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 800, color: '#0F172A', fontSize: '15px' }}>Semester {ws.semester}</div>
                    <div style={{ fontSize: '12px', color: '#64748B', marginTop: '2px' }}>
                      {ws.subject_count} subjects published
                      {submitted ? ` · ${(submitted.items || []).length} preferences submitted` : ''}
                    </div>
                    <div style={{ display: 'flex', gap: '6px', marginTop: '6px' }}>
                      {isFinalized
                        ? <span className="chip chip-finalized">🔒 Finalized — Read Only</span>
                        : submitted
                        ? <span className="chip chip-submitted">📩 Preferences Submitted</span>
                        : <span className="chip chip-pending">⏳ Preferences Pending</span>}
                    </div>
                  </div>

                  <span style={{ fontSize: '20px', color: '#CBD5E1' }}>{isExpanded ? '▲' : '▼'}</span>
                </div>

                {/* Expanded Subject List */}
                {isExpanded && (
                  <div style={{ borderTop: '1px solid #E2E8F0', padding: '20px 22px' }} className="animate-slide-up">
                    {isFinalized && (
                      <div style={{ padding: '12px 16px', background: '#ECFDF5', borderRadius: '10px', border: '1px solid #A7F3D0', marginBottom: '16px', fontSize: '13px', color: '#065F46', fontWeight: 600 }}>
                        🔒 This semester has been finalized by the HOD. Preferences are locked. View your allocated subjects in "My Subjects".
                      </div>
                    )}

                    {subjects.length === 0 ? (
                      <div style={{ textAlign: 'center', padding: '32px', color: '#94A3B8' }}>
                        <div style={{ fontSize: '32px', marginBottom: '8px' }}>📚</div>
                        <p style={{ fontWeight: 600 }}>Subjects not yet published for this semester.</p>
                      </div>
                    ) : (
                      <>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                          <span style={{ fontSize: '13px', fontWeight: 700, color: '#64748B' }}>
                            {subjects.length} subjects · {selected.length} selected
                          </span>
                          {!isFinalized && (
                            <div style={{ display: 'flex', gap: '8px' }}>
                              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedMap(p => ({ ...p, [ws.workspace_id]: [] }))}>
                                Clear All
                              </button>
                              <button className="btn btn-ghost btn-sm" onClick={() => setSelectedMap(p => ({ ...p, [ws.workspace_id]: subjects.map(s => s.id) }))}>
                                Select All
                              </button>
                            </div>
                          )}
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '10px', marginBottom: '16px' }}>
                          {subjects.map(sub => {
                            const isSelected = selected.includes(sub.id);
                            const submittedItem = submitted?.items?.find((i: any) => i.subject_id === sub.id);
                            const decision = submittedItem?.decision;

                            return (
                              <label key={sub.id}
                                style={{
                                  display: 'flex', gap: '12px', padding: '14px', borderRadius: '12px', cursor: isFinalized ? 'default' : 'pointer',
                                  border: `1.5px solid ${isSelected ? '#002147' : '#E2E8F0'}`,
                                  background: isSelected ? '#EFF6FF' : 'white',
                                  transition: 'all 0.15s',
                                }}
                              >
                                {!isFinalized && (
                                  <input type="checkbox" checked={isSelected} onChange={() => toggleSubject(ws.workspace_id, sub.id)}
                                    style={{ width: 16, height: 16, accentColor: '#002147', flexShrink: 0, marginTop: '2px' }} />
                                )}
                                <div style={{ flex: 1, minWidth: 0 }}>
                                  <div style={{ fontWeight: 700, fontSize: '13px', color: '#0F172A', marginBottom: '3px' }}>
                                    {sub.course_name}
                                  </div>
                                  <div style={{ fontSize: '11px', color: '#64748B', marginBottom: '6px' }}>
                                    {sub.course_code} · {sub.credits || '-'} Credits
                                  </div>
                                  <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                                    <span className={`chip ${getCategoryColor(sub.category)}`}>{sub.category}</span>
                                    <span className="chip chip-not-started">{sub.theory_hours}T + {sub.practical_hours}P</span>
                                    {decision && (
                                      <span className={`chip ${decision === 'APPROVED' ? 'chip-allocated' : decision === 'DENIED' ? 'chip-denied' : 'chip-pending'}`}>
                                        {decision}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </label>
                            );
                          })}
                        </div>

                        {!isFinalized && (
                          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', paddingTop: '14px', borderTop: '1px solid #F1F5F9' }}>
                            <span style={{ fontSize: '13px', color: '#94A3B8', alignSelf: 'center' }}>
                              {selected.length} subject{selected.length !== 1 ? 's' : ''} selected
                            </span>
                            <button
                              className="btn btn-primary"
                              onClick={() => handleSubmit(ws.workspace_id)}
                              disabled={isSubmitting === ws.workspace_id || selected.length === 0}
                            >
                              {isSubmitting === ws.workspace_id ? 'Submitting...' : submitted ? '📝 Update Preferences' : '📤 Submit Preferences'}
                            </button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
