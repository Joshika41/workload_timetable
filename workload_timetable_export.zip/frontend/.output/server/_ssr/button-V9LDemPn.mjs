import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as axios } from "../_libs/axios+[...].mjs";
import { t as jwtDecode } from "../_libs/jwt-decode.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-V9LDemPn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var api = axios.create({ baseURL: "" });
api.interceptors.request.use((config) => {
	const token = localStorage.getItem("auth_token");
	if (token && config.headers) config.headers.Authorization = `Bearer ${token}`;
	return config;
});
api.interceptors.response.use((response) => response, (error) => {
	if (error.response) {
		if (error.response.status === 401) {
			localStorage.removeItem("auth_token");
			localStorage.removeItem("srm-erp-session");
			if (window.location.pathname !== "/") {
				toast.error("Session Expired. Please log in again to protect your data.");
				window.location.href = "/";
			}
		}
		if (error.response.data && error.response.data.detail) {
			if (Array.isArray(error.response.data.detail)) error.message = error.response.data.detail.map((e) => e.msg).join(", ");
			else if (typeof error.response.data.detail === "string") error.message = error.response.data.detail;
		}
	}
	return Promise.reject(error);
});
var STORAGE_KEY = "srm-erp-session";
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [session, setSession] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [departmentLabs, setDepartmentLabs] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		try {
			const raw = window.localStorage.getItem(STORAGE_KEY);
			if (raw) setSession(JSON.parse(raw));
		} catch {}
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!session) return;
		const checkExpiry = () => {
			try {
				const token = window.localStorage.getItem("auth_token");
				if (!token) return;
				const parts = token.split(".");
				if (parts.length > 1 && parts[1]) {
					const timeRemaining = JSON.parse(atob(parts[1])).exp * 1e3 - Date.now();
					if (timeRemaining > 0 && timeRemaining < 3e5) toast.warning("Your session will expire soon. Please save your work.", { id: "jwt-warn" });
				}
			} catch (e) {}
		};
		const interval = setInterval(checkExpiry, 6e4);
		return () => clearInterval(interval);
	}, [session]);
	const value = (0, import_react.useMemo)(() => ({
		departmentLabs,
		session,
		ready,
		signIn: async (email, password, role) => {
			try {
				const formData = new URLSearchParams();
				formData.append("username", email);
				formData.append("password", password);
				const res = await api.post("/api/auth/login", formData.toString(), { headers: { "Content-Type": "application/x-www-form-urlencoded" } });
				const token = res.data.access_token;
				const payload = jwtDecode(token);
				const backendRole = payload.role.toLowerCase();
				if (backendRole !== role.toLowerCase() && backendRole !== "master_admin" && backendRole !== "hod") return {
					ok: false,
					error: `These credentials are not valid for the ${role} portal.`
				};
				const mappedRole = backendRole === "master_admin" || backendRole === "hod" ? "admin" : backendRole;
				const next = {
					username: email,
					name: res.data.name || email.split("@")[0],
					role: mappedRole,
					faculty_id: payload.sub,
					department: res.data.department_id?.toString()
				};
				setSession(next);
				window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
				window.localStorage.setItem("auth_token", token);
				return { ok: true };
			} catch (error) {
				return {
					ok: false,
					error: error.response?.data?.detail || "Invalid email or password."
				};
			}
		},
		signOut: () => {
			setSession(null);
			window.localStorage.removeItem(STORAGE_KEY);
			window.localStorage.removeItem("auth_token");
		},
		fetchDepartments: async () => {
			try {
				if (session?.role === "admin") {
					const res = await api.get("/api/admin/departments");
					if (Array.isArray(res.data)) {
						const labsMap = {};
						res.data.forEach((d) => {
							labsMap[d.name] = d.has_labs || false;
						});
						setDepartmentLabs(labsMap);
					} else setDepartmentLabs(res.data);
				}
			} catch {}
		},
		toggleHasLabs: async (dept, has_labs) => {
			try {
				await api.put(`/api/admin/departments/${dept}`, { has_labs });
				setDepartmentLabs((prev) => ({
					...prev,
					[dept]: has_labs
				}));
			} catch (e) {
				console.error(e);
				alert(e.response?.data?.detail || "Failed to update department settings.");
			}
		},
		setDepartment: (department) => {
			setSession((prev) => {
				if (!prev) return prev;
				const next = {
					...prev,
					department
				};
				window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
				return next;
			});
		}
	}), [
		session,
		ready,
		departmentLabs
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within AuthProvider");
	return ctx;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
export { useAuth as a, cn as i, Button as n, api as r, AuthProvider as t };
