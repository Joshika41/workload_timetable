import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as useAuth, i as cn, n as Button } from "./button-V9LDemPn.mjs";
import { t as useWorkloadData } from "./workload-store-BdC8H8Qo.mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Y as BookOpen, Z as ArrowRight, k as GraduationCap, l as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as Input } from "./input-CytN75ZS.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CEiI5yIs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
function RoleSelection() {
	const navigate = useNavigate();
	const { facultyList, setCurrentFacultyId } = useWorkloadData();
	const { signIn } = useAuth();
	const [activeRole, setActiveRole] = (0, import_react.useState)(null);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("password123");
	const handleQuickLoginHOD = async () => {
		const res = await signIn(email, password, "admin");
		if (res.ok) navigate({ to: "/admin" });
		else alert(res.error);
	};
	const handleQuickLoginFaculty = async (e) => {
		const res = await signIn(email, password, "faculty");
		if (res.ok) navigate({ to: "/faculty/dashboard" });
		else alert(res.error);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#002147] flex flex-col justify-between text-white relative overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "px-6 py-5 flex items-center justify-between border-b border-blue-900/60 z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "size-10 rounded-lg bg-teal-400/20 text-teal-300 border border-teal-400/40 flex items-center justify-center font-bold",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-6" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-bold text-sm tracking-wider uppercase",
						children: "SRM Institute of Science and Technology"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-blue-200",
						children: "Department of Computer Applications · MCA & MCA GEN AI"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "px-2.5 py-1 text-xs font-bold rounded bg-teal-500/20 text-teal-300 border border-teal-400/30",
					children: "Academic Year 2026-2027"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 flex flex-col items-center justify-center px-4 py-12 max-w-5xl mx-auto w-full z-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center space-y-3 mb-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "px-3 py-1 text-xs font-bold rounded-full bg-white/10 text-teal-300 border border-white/10 tracking-wider uppercase",
							children: "Official University System"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-3xl sm:text-4xl font-extrabold tracking-tight text-white",
							children: "Faculty Preference & Workload Management"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm sm:text-base text-blue-200/80 max-w-2xl mx-auto",
							children: "Automating subject willingness collection, departmental faculty allocation, and instant workload calculations under the 2025 SRM MCA Syllabus."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full sm:grid-cols-2 gap-6 max-w-3xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-white text-slate-900 p-6 shadow-xl border border-slate-200 flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:-translate-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center mb-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-bold text-slate-900",
								children: "Head of Department (HOD)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 mt-2 leading-relaxed",
								children: "Review faculty subject preferences, configure course & section allocations, balance theory/lab teaching hours, and export official workload sheets."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 pt-4 border-t border-slate-100 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px] uppercase font-bold text-slate-500",
										children: "Email Address:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										placeholder: "hod@srm.edu",
										className: "h-8 text-xs font-semibold rounded border border-slate-200"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px] uppercase font-bold text-slate-500",
										children: "Password:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										placeholder: "••••••••",
										className: "h-8 text-xs font-semibold rounded border border-slate-200"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: handleQuickLoginHOD,
									className: "w-full bg-[#002147] hover:bg-[#001833] text-white font-bold text-xs h-10 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sign In as HOD" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 text-teal-300" })]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-white text-slate-900 p-6 shadow-xl border border-slate-200 flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:-translate-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "size-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center mb-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-6" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-bold text-slate-900",
								children: "Faculty Member Portal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-slate-500 mt-2 leading-relaxed",
								children: "Browse syllabus courses by category (Core, Elective, Skill, etc.), submit ranked subject preferences (1 to 5), and review your personal teaching allocation."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 pt-4 border-t border-slate-100 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px] uppercase font-bold text-slate-500",
										children: "Email Address:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "email",
										value: email,
										onChange: (e) => setEmail(e.target.value),
										placeholder: "name@srm.edu",
										className: "h-8 text-xs font-semibold rounded border border-slate-200"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										className: "text-[10px] uppercase font-bold text-slate-500",
										children: "Password:"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "password",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										placeholder: "••••••••",
										className: "h-8 text-xs font-semibold rounded border border-slate-200"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => handleQuickLoginFaculty(email),
									className: "w-full bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs h-10 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sign In" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
								})
							]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "px-6 py-4 text-center text-xs text-blue-200/60 border-t border-blue-900/40 z-10",
				children: [
					"© ",
					(/* @__PURE__ */ new Date()).getFullYear(),
					" SRM Institute of Science and Technology · Faculty Preference & Workload ERP"
				]
			})
		]
	});
}
//#endregion
export { RoleSelection as component };
