globalThis.__nitro_main__ = import.meta.url;
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx+unenv.mjs";
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-09-14T19:33:48.094Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-09-14T19:33:48.096Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/admin.audit-6J9X5fX9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b22-J3lXjd+KBySDs01a+AbrIGflcZk\"",
		"mtime": "2026-09-21T04:47:12.463Z",
		"size": 6946,
		"path": "../public/assets/admin.audit-6J9X5fX9.js"
	},
	"/assets/admin.allocation-BwP3lMWf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"527f-lXkK9vrjMV2Xc2PjK2LlbDhRIFM\"",
		"mtime": "2026-09-21T04:47:12.461Z",
		"size": 21119,
		"path": "../public/assets/admin.allocation-BwP3lMWf.js"
	},
	"/assets/admin.index-__HOVrOh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f1a-1ym+/7sKfEWEphP2nKc8pTVudsk\"",
		"mtime": "2026-09-21T04:47:12.463Z",
		"size": 20250,
		"path": "../public/assets/admin.index-__HOVrOh.js"
	},
	"/assets/admin.faculty-DscEyOue.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a86-ea9SNJJD2aImcjQJUsOSKSkbtHU\"",
		"mtime": "2026-09-21T04:47:12.463Z",
		"size": 14982,
		"path": "../public/assets/admin.faculty-DscEyOue.js"
	},
	"/assets/admin.preferences-BgqdIP9j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2982-u0/KTJTmHBT3UAusFf5VXujD4Dg\"",
		"mtime": "2026-09-21T04:47:12.465Z",
		"size": 10626,
		"path": "../public/assets/admin.preferences-BgqdIP9j.js"
	},
	"/assets/admin.setup-kzliCgtd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c13-q2ziWV0dyFLbt1CjYURss7gYhmc\"",
		"mtime": "2026-09-21T04:47:12.465Z",
		"size": 15379,
		"path": "../public/assets/admin.setup-kzliCgtd.js"
	},
	"/assets/admin.workload--7yglz1w.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ec2-kAy8up50SCpbyktJjRzoBTIVh/Q\"",
		"mtime": "2026-09-21T04:47:12.493Z",
		"size": 20162,
		"path": "../public/assets/admin.workload--7yglz1w.js"
	},
	"/assets/arrow-left-CiuxCXcY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-MiBEgx/A0ubMWJupA4EryWrRdOQ\"",
		"mtime": "2026-09-21T04:47:12.496Z",
		"size": 155,
		"path": "../public/assets/arrow-left-CiuxCXcY.js"
	},
	"/assets/button-CBtzkYNI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e6e6-yfXNgmlA/wLHFpc6T48+Vrzr14Q\"",
		"mtime": "2026-09-21T04:47:12.496Z",
		"size": 124646,
		"path": "../public/assets/button-CBtzkYNI.js"
	},
	"/assets/clock-lyUEcHCY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9f-qNsrvqOs5kU1WvSBua55LuZFR9U\"",
		"mtime": "2026-09-21T04:47:12.496Z",
		"size": 159,
		"path": "../public/assets/clock-lyUEcHCY.js"
	},
	"/assets/dean.index-DY9HrZZs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d7c-PfwdgmbCVQk61pvPYwHe1Juoqq8\"",
		"mtime": "2026-09-21T04:47:12.496Z",
		"size": 3452,
		"path": "../public/assets/dean.index-DY9HrZZs.js"
	},
	"/assets/dean.timetables-Cqd5tfeU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8fc-vOQXYEPpSAfz+SWE4PWsixCY5cs\"",
		"mtime": "2026-09-21T04:47:12.498Z",
		"size": 2300,
		"path": "../public/assets/dean.timetables-Cqd5tfeU.js"
	},
	"/assets/dist-BfK_8mEH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5613-v7zls36t8xnVza4AGb3KJm1V7qU\"",
		"mtime": "2026-09-21T04:47:12.498Z",
		"size": 22035,
		"path": "../public/assets/dist-BfK_8mEH.js"
	},
	"/assets/eye-WXzu2m69.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-A+pYqcsTbbOJLI/0X6NdKAFDdDw\"",
		"mtime": "2026-09-21T04:47:12.499Z",
		"size": 246,
		"path": "../public/assets/eye-WXzu2m69.js"
	},
	"/assets/excel-export-BHehY5DQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"45a26-UiY0o8PzBmZH88eaeozZjcyrv1M\"",
		"mtime": "2026-09-21T04:47:12.498Z",
		"size": 285222,
		"path": "../public/assets/excel-export-BHehY5DQ.js"
	},
	"/assets/faculty.dashboard-D0eESK6U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5098-XQHomFxyqVfpjZR+Ng03oSyL/n4\"",
		"mtime": "2026-09-21T04:47:12.499Z",
		"size": 20632,
		"path": "../public/assets/faculty.dashboard-D0eESK6U.js"
	},
	"/assets/faculty.timetable-_0psoZmO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"aa5-YFki/scMzhq8RAju9678KnQ9OEI\"",
		"mtime": "2026-09-21T04:47:12.499Z",
		"size": 2725,
		"path": "../public/assets/faculty.timetable-_0psoZmO.js"
	},
	"/assets/faculty.index-YuA77UDp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e1-lpJMgshpjhc6bWjZ6tjUZdJO+Us\"",
		"mtime": "2026-09-21T04:47:12.499Z",
		"size": 225,
		"path": "../public/assets/faculty.index-YuA77UDp.js"
	},
	"/assets/file-spreadsheet-CvfURi7Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a2-uUGuPRmwoM2IKrITJMygE1UJgAU\"",
		"mtime": "2026-09-21T04:47:12.503Z",
		"size": 418,
		"path": "../public/assets/file-spreadsheet-CvfURi7Y.js"
	},
	"/assets/graduation-cap-r3cHAjJa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-hfm3cRDYWdu1xOqG+jZW46wsjos\"",
		"mtime": "2026-09-21T04:47:12.503Z",
		"size": 322,
		"path": "../public/assets/graduation-cap-r3cHAjJa.js"
	},
	"/assets/index-Cp8oBMXl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4eb1f-PLuRSyzlUcpbHxJQ32Qf0Sdf/2s\"",
		"mtime": "2026-09-21T04:47:12.455Z",
		"size": 322335,
		"path": "../public/assets/index-Cp8oBMXl.js"
	},
	"/assets/input-DRvSsMoU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"25e-ivkjWFoeex0FFzL+P9+w4wXf8fw\"",
		"mtime": "2026-09-21T04:47:12.511Z",
		"size": 606,
		"path": "../public/assets/input-DRvSsMoU.js"
	},
	"/assets/admin.timetables-DlmNEDDA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e5229-iaAPlpI3mIGreTT/1HSkeWtrg5M\"",
		"mtime": "2026-09-21T04:47:12.465Z",
		"size": 938537,
		"path": "../public/assets/admin.timetables-DlmNEDDA.js"
	},
	"/assets/link-CY6S0354.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b1d-NIWp9pTXiYfZrGMzZy16stCUssw\"",
		"mtime": "2026-09-21T04:47:12.511Z",
		"size": 23325,
		"path": "../public/assets/link-CY6S0354.js"
	},
	"/assets/plus-CwhMPfYQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f-vaisjfyZg7iUUp6S0Xh0vUXWJPk\"",
		"mtime": "2026-09-21T04:47:12.512Z",
		"size": 143,
		"path": "../public/assets/plus-CwhMPfYQ.js"
	},
	"/assets/portal-nav-DWH8XEqU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1af5-pJ3/BHO0ynsAi6zgR6n5CvtX5kY\"",
		"mtime": "2026-09-21T04:47:12.512Z",
		"size": 6901,
		"path": "../public/assets/portal-nav-DWH8XEqU.js"
	},
	"/assets/react-SIfiwpqq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ff9-FGVdof4/lFGmrdRsB9EIvuwBlYc\"",
		"mtime": "2026-09-21T04:47:12.512Z",
		"size": 8185,
		"path": "../public/assets/react-SIfiwpqq.js"
	},
	"/assets/search-CoRx-a96.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a4-WsqcX7NCCMymxOWqPCX/JqP2YuU\"",
		"mtime": "2026-09-21T04:47:12.514Z",
		"size": 164,
		"path": "../public/assets/search-CoRx-a96.js"
	},
	"/assets/routes-OxOVgJGL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bc3-nhVYXYeEBzb5gjnB4XepI/1Vkcs\"",
		"mtime": "2026-09-21T04:47:12.512Z",
		"size": 7107,
		"path": "../public/assets/routes-OxOVgJGL.js"
	},
	"/assets/TimetableGrid-BGPIQld0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"766-U7JyouDai4Dy28IDNslxLOoafJQ\"",
		"mtime": "2026-09-21T04:47:12.455Z",
		"size": 1894,
		"path": "../public/assets/TimetableGrid-BGPIQld0.js"
	},
	"/assets/trash-2-BZH7FTDs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-MAupwxPPiZGOUUflyQe32NouZJE\"",
		"mtime": "2026-09-21T04:47:12.514Z",
		"size": 318,
		"path": "../public/assets/trash-2-BZH7FTDs.js"
	},
	"/assets/useNavigate-CWacDeMi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3-i8MwZA/mnPgL5jZY4+mNz1FgJF4\"",
		"mtime": "2026-09-21T04:47:12.529Z",
		"size": 243,
		"path": "../public/assets/useNavigate-CWacDeMi.js"
	},
	"/assets/workload-types-Bp4Jozc4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3db-67GwWa95xJwqCzL6n6EaTjRNboM\"",
		"mtime": "2026-09-21T04:47:12.533Z",
		"size": 987,
		"path": "../public/assets/workload-types-Bp4Jozc4.js"
	},
	"/assets/useQuery-CmdOaZNd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f8c-Kc8ulk90xGmOljIScsvmsbgVJ6o\"",
		"mtime": "2026-09-21T04:47:12.529Z",
		"size": 8076,
		"path": "../public/assets/useQuery-CmdOaZNd.js"
	},
	"/assets/styles-C4zMMjji.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"19b37-KelAudyZ0c+SVRGcsbF4PYZOgsk\"",
		"mtime": "2026-09-21T04:47:12.535Z",
		"size": 105271,
		"path": "../public/assets/styles-C4zMMjji.css"
	},
	"/assets/x-CZhX95FD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"418-3x4ENua4fF1Sbu8nm0p50qxS1fg\"",
		"mtime": "2026-09-21T04:47:12.533Z",
		"size": 1048,
		"path": "../public/assets/x-CZhX95FD.js"
	},
	"/assets/WorkloadStatusBadge-CF5sWcdA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d6a-wykdetFQ8Kp+j8CycbGfFcHd5Bw\"",
		"mtime": "2026-09-21T04:47:12.461Z",
		"size": 3434,
		"path": "../public/assets/WorkloadStatusBadge-CF5sWcdA.js"
	},
	"/templates/cohorts_template.csv": {
		"type": "text/csv; charset=utf-8",
		"etag": "\"2c-CuIvfjPToPjEH0l066c7SeGC/g0\"",
		"mtime": "2026-09-14T19:33:48.096Z",
		"size": 44,
		"path": "../public/templates/cohorts_template.csv"
	},
	"/templates/cohorts_template.xlsx": {
		"type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		"etag": "\"1318-/Go7qubQvkGyQrwLvp2sGP5A9Hc\"",
		"mtime": "2026-09-14T19:33:48.098Z",
		"size": 4888,
		"path": "../public/templates/cohorts_template.xlsx"
	},
	"/templates/faculty_template.csv": {
		"type": "text/csv; charset=utf-8",
		"etag": "\"7e-RoPLwAgr4/iIhhSL+1GzZmGwIqU\"",
		"mtime": "2026-09-14T19:33:48.098Z",
		"size": 126,
		"path": "../public/templates/faculty_template.csv"
	},
	"/templates/syllabus_template.xlsx": {
		"type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		"etag": "\"1358-0fd5wHQDcmLnnFT5KtiYwaYrdYs\"",
		"mtime": "2026-09-14T19:33:48.100Z",
		"size": 4952,
		"path": "../public/templates/syllabus_template.xlsx"
	},
	"/assets/WorkloadShell-DCp76Uzi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a4fc-5IBTMSjhB2vUnsk8q0SAeFYGvQ4\"",
		"mtime": "2026-09-21T04:47:12.461Z",
		"size": 107772,
		"path": "../public/assets/WorkloadShell-DCp76Uzi.js"
	},
	"/templates/faculty_template.xlsx": {
		"type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
		"etag": "\"1352-Eb49pDxTHqRCGZ00/eA4e49RLik\"",
		"mtime": "2026-09-14T19:33:48.098Z",
		"size": 4946,
		"path": "../public/templates/faculty_template.xlsx"
	},
	"/templates/syllabus_template.csv": {
		"type": "text/csv; charset=utf-8",
		"etag": "\"7a-lzmj9QqCLTNbajoOZbOrC4GfELg\"",
		"mtime": "2026-09-14T19:33:48.100Z",
		"size": 122,
		"path": "../public/templates/syllabus_template.csv"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_91WZKz = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_91WZKz
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
